"""Runner packs for generic task-runner-based test invocation.

These packs activate at low confidence (0.3) as fallbacks when no
language-specific pack matches but Makefile/justfile contains test targets.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

from coderecon.testing.models import ParsedTestSuite, TestTarget
from coderecon.testing.runner_pack import (
    MarkerRule,
    OutputStrategy,
    RunnerCapabilities,
    RunnerPack,
    runner_registry,
)

if TYPE_CHECKING:
    from coderecon.testing.runtime import RuntimeExecutionContext

log = structlog.get_logger(__name__)

_FALLBACK_CONFIDENCE = 0.3


@runner_registry.register
class MakefileTestPack(RunnerPack):
    """Fallback pack that invokes `make test` when a Makefile defines a test target."""

    pack_id = "generic.makefile_test"
    language = "generic"
    runner_name = "make test"
    markers = (MarkerRule("Makefile", confidence="low"),)
    output_strategy = OutputStrategy(format="text", file_based=False)
    capabilities = RunnerCapabilities(
        supported_kinds=["workspace"],
        supports_pattern_filter=False,
        supports_tag_filter=False,
        supports_parallel=False,
        supports_junit_output=False,
    )

    def detect(self, workspace_root: Path) -> float:
        makefile = workspace_root / "Makefile"
        if not makefile.exists():
            return 0.0
        try:
            content = makefile.read_text(errors="replace")
            if re.search(r"^test\s*:", content, re.MULTILINE):
                return _FALLBACK_CONFIDENCE
        except OSError:
            pass
        return 0.0

    async def discover(self, workspace_root: Path) -> list[TestTarget]:
        """Returns a single workspace-level test target."""
        if self.detect(workspace_root) > 0:
            return [
                TestTarget(
                    target_id="workspace:make-test",
                    selector="test",
                    kind="workspace",
                    language="generic",
                    runner_pack_id=self.pack_id,
                    workspace_root=str(workspace_root),
                )
            ]
        return []

    def build_command(
        self,
        target: TestTarget,
        *,
        output_path: Path,
        pattern: str | None = None,
        tags: list[str] | None = None,
        exec_ctx: RuntimeExecutionContext | None = None,
    ) -> list[str]:
        return ["make", "test"]

    def parse_output(self, output_path: Path, stdout: str) -> ParsedTestSuite:
        # Task-runner output is opaque; report pass/fail based on exit code
        # (exit code handling is done in _exec_and_parse)
        return ParsedTestSuite(name="make test", passed=0, total=0)


@runner_registry.register
class JustfileTestPack(RunnerPack):
    """Fallback pack that invokes `just test` when a justfile defines a test recipe."""

    pack_id = "generic.justfile_test"
    language = "generic"
    runner_name = "just test"
    markers = (MarkerRule("justfile", confidence="low"),)
    output_strategy = OutputStrategy(format="text", file_based=False)
    capabilities = RunnerCapabilities(
        supported_kinds=["workspace"],
        supports_pattern_filter=False,
        supports_tag_filter=False,
        supports_parallel=False,
        supports_junit_output=False,
    )

    def detect(self, workspace_root: Path) -> float:
        justfile = workspace_root / "justfile"
        if not justfile.exists():
            return 0.0
        try:
            content = justfile.read_text(errors="replace")
            if re.search(r"^test\s*:", content, re.MULTILINE):
                return _FALLBACK_CONFIDENCE
        except OSError:
            pass
        return 0.0

    async def discover(self, workspace_root: Path) -> list[TestTarget]:
        """Returns a single workspace-level test target."""
        if self.detect(workspace_root) > 0:
            return [
                TestTarget(
                    target_id="workspace:just-test",
                    selector="test",
                    kind="workspace",
                    language="generic",
                    runner_pack_id=self.pack_id,
                    workspace_root=str(workspace_root),
                )
            ]
        return []

    def build_command(
        self,
        target: TestTarget,
        *,
        output_path: Path,
        pattern: str | None = None,
        tags: list[str] | None = None,
        exec_ctx: RuntimeExecutionContext | None = None,
    ) -> list[str]:
        return ["just", "test"]

    def parse_output(self, output_path: Path, stdout: str) -> ParsedTestSuite:
        return ParsedTestSuite(name="just test", passed=0, total=0)
