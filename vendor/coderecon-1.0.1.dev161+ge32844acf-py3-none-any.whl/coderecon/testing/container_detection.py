"""Container environment detection and execution for test workspaces.

Detects whether a project uses containerized testing (Docker, devcontainer)
and provides an execution strategy that runs tests inside containers when
the host lacks the required toolchain.
"""

from __future__ import annotations

import asyncio
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import structlog

log = structlog.get_logger(__name__)


@dataclass
class ContainerSignal:
    """Indicator that a project uses containerized testing."""

    marker: str  # File that triggered detection
    test_service: str | None  # Docker Compose service name if identifiable
    confidence: Literal["high", "medium", "low"]


@dataclass
class ContainerConfig:
    """Configuration for running tests inside a container."""

    compose_file: Path
    service: str
    build_first: bool = False


@dataclass
class ContainerDetectionResult:
    """Result of container detection for a workspace."""

    signals: list[ContainerSignal] = field(default_factory=list)
    config: ContainerConfig | None = None
    docker_available: bool = False

    @property
    def is_container_only(self) -> bool:
        """True if high-confidence container signals exist."""
        return any(s.confidence == "high" for s in self.signals)


def detect_container_testing(repo_root: Path) -> ContainerDetectionResult:
    """Detect if the project uses containerized testing.

    Checks for Docker Compose files with test services, Dockerfiles
    named for testing, devcontainer configurations, and task files
    that invoke Docker for testing.
    """
    signals: list[ContainerSignal] = []
    config: ContainerConfig | None = None
    docker_available = shutil.which("docker") is not None

    # Check Docker Compose files for test services
    compose_names = [
        "docker-compose.yml",
        "docker-compose.yaml",
        "compose.yml",
        "compose.yaml",
    ]
    for compose_name in compose_names:
        compose_file = repo_root / compose_name
        if compose_file.exists():
            service = _find_test_service(compose_file)
            if service:
                signals.append(ContainerSignal(
                    marker=compose_name,
                    test_service=service,
                    confidence="high",
                ))
                if not config:
                    config = ContainerConfig(
                        compose_file=compose_file,
                        service=service,
                    )

    # Check for test-specific Dockerfiles
    for dockerfile_name in ["Dockerfile.test", "Dockerfile.ci", "test.Dockerfile"]:
        if (repo_root / dockerfile_name).exists():
            signals.append(ContainerSignal(
                marker=dockerfile_name,
                test_service=None,
                confidence="high",
            ))

    # Check for devcontainer
    devcontainer = repo_root / ".devcontainer" / "devcontainer.json"
    if devcontainer.exists():
        signals.append(ContainerSignal(
            marker=".devcontainer/devcontainer.json",
            test_service=None,
            confidence="medium",
        ))

    # Check Makefile/justfile for Docker-based test targets
    for task_file in ["Makefile", "justfile"]:
        task_path = repo_root / task_file
        if task_path.exists():
            try:
                content = task_path.read_text(errors="replace")
                if _task_file_uses_docker_for_tests(content, task_file):
                    signals.append(ContainerSignal(
                        marker=task_file,
                        test_service=None,
                        confidence="medium",
                    ))
            except OSError:
                pass

    return ContainerDetectionResult(
        signals=signals,
        config=config,
        docker_available=docker_available,
    )


def _find_test_service(compose_file: Path) -> str | None:
    """Find a test-related service in a Docker Compose file."""
    try:
        import yaml
        data = yaml.safe_load(compose_file.read_text())
        if not isinstance(data, dict):
            return None
        services = data.get("services", {})
        if not isinstance(services, dict):
            return None
        for name, svc_config in services.items():
            if not isinstance(svc_config, dict):
                continue
            # Service name contains "test"
            if "test" in name.lower():
                return name
            # Command contains test runner invocations
            cmd = svc_config.get("command", "")
            if isinstance(cmd, str) and re.search(
                r"\b(pytest|jest|vitest|go\s+test|cargo\s+test|dotnet\s+test|rspec|phpunit)\b",
                cmd,
            ):
                return name
            if isinstance(cmd, list):
                cmd_str = " ".join(str(c) for c in cmd)
                if re.search(
                    r"\b(pytest|jest|vitest|go\s+test|cargo\s+test|dotnet\s+test|rspec|phpunit)\b",
                    cmd_str,
                ):
                    return name
    except (OSError, ImportError, ValueError):
        log.debug("compose_parse_failed", path=str(compose_file), exc_info=True)
    return None


def _task_file_uses_docker_for_tests(content: str, task_file: str) -> bool:
    """Check if a Makefile/justfile test target uses Docker."""
    if task_file == "Makefile":
        # Look for test target that invokes docker
        match = re.search(
            r"^test[^:]*:.*?\n((?:\t.+\n)*)",
            content,
            re.MULTILINE,
        )
        if match:
            recipe = match.group(1)
            return "docker" in recipe.lower()
    elif task_file == "justfile":
        # justfile uses recipe syntax without tabs
        match = re.search(
            r"^test[^:]*:.*?\n((?:[ ].+\n)*)",
            content,
            re.MULTILINE,
        )
        if match:
            recipe = match.group(1)
            return "docker" in recipe.lower()
    return False


async def run_in_container(
    config: ContainerConfig,
    cmd: list[str],
    *,
    cwd: Path,
    env: dict[str, str],
    timeout_sec: int,
    artifact_dir: Path,
) -> tuple[int, str, str]:
    """Execute a test command inside a Docker Compose service.

    Bind-mounts the artifact_dir into the container so coverage/test
    artifacts are accessible from the host after execution.

    Returns (exit_code, stdout, stderr).
    """
    container_artifact_dir = "/tmp/coderecon-artifacts"

    compose_cmd = [
        "docker", "compose",
        "-f", str(config.compose_file),
        "run", "--rm",
        "--no-deps",
        "-v", f"{artifact_dir}:{container_artifact_dir}",
        "-e", f"CODERECON_ARTIFACT_DIR={container_artifact_dir}",
        "-e", "CI=true",
        "-e", "CODERECON_EXECUTION=1",
    ]

    # Pass through relevant environment variables
    passthrough_keys = [
        k for k in env
        if k.startswith("CODERECON_") or k in (
            "CI", "NO_COLOR", "FORCE_COLOR",
            "COVERAGE_FILE", "COVERAGE_DIR", "GOCOVERDIR",
        )
    ]
    for key in passthrough_keys:
        compose_cmd.extend(["-e", f"{key}={env[key]}"])

    if config.build_first:
        # Build the service image first
        build_cmd = [
            "docker", "compose", "-f", str(config.compose_file),
            "build", config.service,
        ]
        build_proc = await asyncio.create_subprocess_exec(
            *build_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
        )
        await build_proc.communicate()

    compose_cmd.append(config.service)
    compose_cmd.extend(cmd)

    proc = await asyncio.create_subprocess_exec(
        *compose_cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=cwd,
    )

    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(), timeout=timeout_sec
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        return (-1, "", f"Container execution timed out after {timeout_sec}s")

    return (
        proc.returncode or 0,
        stdout_bytes.decode(errors="replace"),
        stderr_bytes.decode(errors="replace"),
    )
