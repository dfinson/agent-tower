"""Decoder for coverage.py's numbits format.

The numbits format is a compact binary encoding of a set of line numbers,
used in coverage.py's SQLite database (line_bits table). Each byte encodes
8 consecutive line numbers as a bitmask, with a variable-length run encoding.

This is a clean-room implementation based on the documented format:
- Bytes are processed sequentially
- Each byte represents 8 line numbers (bit 0 = first, bit 7 = eighth)
- Line numbers start at 1 (byte 0, bit 0 = line 1)
"""

from __future__ import annotations


def numbits_to_nums(numbits: bytes) -> list[int]:
    """Decode a numbits blob into a sorted list of line numbers.

    Args:
        numbits: Raw bytes from coverage.py's line_bits.numbits column.

    Returns:
        Sorted list of 1-based line numbers that were covered.
    """
    result: list[int] = []
    for byte_idx, byte_val in enumerate(numbits):
        if byte_val == 0:
            continue
        base = byte_idx * 8 + 1  # line numbers are 1-based
        for bit in range(8):
            if byte_val & (1 << bit):
                result.append(base + bit)
    return result
