"""Parser for PHPUnit per-test XML coverage output.

When PHPUnit runs with --coverage-xml=dir/, it produces:
    dir/index.xml          — summary
    dir/<namespace>/<file>.xml — per-file coverage with test attribution

Each file XML has structure:
    <phpunit>
      <file href="src/Foo.php">
        <line num="10" type="stmt" count="2">
          <covered by="Tests\\FooTest::testBasic"/>
          <covered by="Tests\\FooTest::testAdvanced"/>
        </line>
        ...
      </file>
    </phpunit>

This gives us direct per-test → per-line attribution.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

import structlog

from coderecon.testing.coverage.models import CoverageReport, FileCoverage

log = structlog.get_logger(__name__)


def _normalize_phpunit_test_id(raw: str) -> str:
    """Normalize PHPUnit test_id to canonical format.

    Input:  "Tests\\Namespace\\FooTest::testBasic"
    Output: "Tests/Namespace/FooTest.php::FooTest.testBasic"

    Canonical: {file_path}::{ClassName.methodName}
    """
    if "::" not in raw:
        # No method separator — use as-is (shouldn't happen)
        return raw.replace("\\", "/")
    fqcn, method = raw.rsplit("::", 1)
    # Convert namespace to path: Tests\Namespace\FooTest → Tests/Namespace/FooTest.php
    file_path = fqcn.replace("\\", "/") + ".php"
    # Lexical path: ClassName.method
    class_name = fqcn.rsplit("\\", 1)[-1]
    lexical_path = f"{class_name}.{method}"
    return f"{file_path}::{lexical_path}"


def parse_phpunit_per_test(
    coverage_dir: Path,
    *,
    base_path: Path | None = None,
) -> dict[str, CoverageReport]:
    """Parse PHPUnit --coverage-xml output into per-test CoverageReports.

    Args:
        coverage_dir: Directory containing PHPUnit XML coverage output.
        base_path: If set, file paths are made relative to this.

    Returns:
        Mapping of test_id → CoverageReport. Empty dict if no data found.
    """
    if not coverage_dir.is_dir():
        log.debug("phpunit_per_test.dir_not_found", path=str(coverage_dir))
        return {}

    # Find all XML files (excluding index.xml)
    xml_files = [
        f for f in coverage_dir.rglob("*.xml")
        if f.name != "index.xml"
    ]

    if not xml_files:
        return {}

    # per_test_lines[test_id][file_path][line_no] = hit_count
    per_test_lines: dict[str, dict[str, dict[int, int]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(int))
    )

    for xml_file in xml_files:
        try:
            tree = ET.parse(xml_file)  # noqa: S314
        except ET.ParseError:
            log.debug("phpunit_per_test.parse_error", file=str(xml_file), exc_info=True)
            continue

        root = tree.getroot()

        for file_elem in root.iter("file"):
            file_path = file_elem.get("href") or file_elem.get("name", "")
            if not file_path:
                continue

            if base_path:
                try:
                    file_path = str(Path(file_path).relative_to(base_path))
                except ValueError:
                    pass

            for line_elem in file_elem.iter("line"):
                line_no_str = line_elem.get("num")
                if not line_no_str:
                    continue
                try:
                    line_no = int(line_no_str)
                except ValueError:
                    continue

                # Each <covered by="..."/> child attributes the line to a test
                for covered_elem in line_elem.iter("covered"):
                    test_id = covered_elem.get("by", "")
                    if test_id:
                        # Normalize PHP namespace separators
                        test_id = test_id.replace("\\\\", "\\")
                        test_id = _normalize_phpunit_test_id(test_id)
                        per_test_lines[test_id][file_path][line_no] += 1

    # Convert to CoverageReport objects
    result: dict[str, CoverageReport] = {}
    for test_id, files_data in per_test_lines.items():
        files: dict[str, FileCoverage] = {}
        for file_path, lines in files_data.items():
            files[file_path] = FileCoverage(path=file_path, lines=lines)
        result[test_id] = CoverageReport(source_format="phpunit_per_test", files=files)

    return result
