"""Parser for JaCoCo per-test .exec files.

When JaCoCo is configured with a JUnit5 listener that resets and dumps
execution data after each test method, it produces a directory of .exec
files named by test identifier:

    per-test/
        com.example.FooTest#testBasic.exec
        com.example.FooTest#testAdvanced.exec
        ...

Each .exec file is a standard JaCoCo binary execution data file that
can be parsed to determine which classes/methods were covered by that
specific test.

JaCoCo .exec format:
    - Magic: 0x01C0C0B1 (big-endian)
    - Blocks of: HEADER | SESSION_INFO | EXECUTION_DATA
    - EXECUTION_DATA: tag=0x01, class_id (long), class_name (utf),
      probes (boolean[])

We parse the exec files to extract class-level probe data, then
cross-reference with source file mappings to produce line-level coverage.
For the initial implementation, we extract class names as the coverage
unit (finer granularity requires the .class files to map probes→lines).
"""

from __future__ import annotations

import struct
from collections import defaultdict
from pathlib import Path

import structlog

from coderecon.testing.coverage.models import CoverageReport, FileCoverage

log = structlog.get_logger(__name__)

# JaCoCo exec file constants
_MAGIC = 0x01C0C0B1
_BLOCK_HEADER = 0x01
_BLOCK_SESSIONINFO = 0x10
_BLOCK_EXECUTIONDATA = 0x11


def _normalize_jacoco_test_id(raw: str) -> str:
    """Normalize JaCoCo test_id to canonical format.

    Input:  "com.example.FooTest#testBasic"
    Output: "src/test/java/com/example/FooTest.java::FooTest.testBasic"

    Canonical: {file_path}::{ClassName.methodName}
    """
    if "#" in raw:
        fqcn, method = raw.rsplit("#", 1)
    else:
        # No method — treat as class-level
        fqcn = raw
        method = ""

    # Convert package.ClassName → src/test/java/package/ClassName.java
    file_path = "src/test/java/" + fqcn.replace(".", "/") + ".java"
    # Lexical path: ClassName.method
    class_name = fqcn.rsplit(".", 1)[-1]
    lexical_path = f"{class_name}.{method}" if method else class_name
    return f"{file_path}::{lexical_path}"


def parse_jacoco_per_test(
    per_test_dir: Path,
    *,
    base_path: Path | None = None,
    class_to_source: dict[str, str] | None = None,
) -> dict[str, CoverageReport]:
    """Parse a directory of per-test JaCoCo .exec files.

    Args:
        per_test_dir: Directory containing per-test .exec files.
        base_path: If set, file paths are made relative to this.
        class_to_source: Optional mapping of fully-qualified class name
            to source file path. If not provided, class names are converted
            to file paths using package→directory convention.

    Returns:
        Mapping of test_id → CoverageReport. Each report contains the
        classes (as files) that had probe hits during that test.
        Empty dict if directory missing or no valid exec files found.
    """
    if not per_test_dir.is_dir():
        log.debug("jacoco_per_test.dir_not_found", path=str(per_test_dir))
        return {}

    exec_files = list(per_test_dir.glob("*.exec"))
    if not exec_files:
        return {}

    result: dict[str, CoverageReport] = {}

    for exec_file in exec_files:
        # Test ID from filename: "com.example.FooTest#testBasic.exec" → normalized
        test_id = _normalize_jacoco_test_id(exec_file.stem)

        try:
            probe_data = _parse_exec_file(exec_file)
        except (OSError, struct.error, ValueError):
            log.debug("jacoco_per_test.parse_error", file=str(exec_file), exc_info=True)
            continue

        if not probe_data:
            continue

        # Convert class probe data to file-level coverage
        files: dict[str, FileCoverage] = {}
        for class_name, probes in probe_data.items():
            # Convert class name to source path
            file_path = _class_to_path(class_name, class_to_source, base_path)
            if not file_path:
                continue

            # JaCoCo probes don't directly give line numbers without .class analysis.
            # We record probe indices as synthetic line numbers (1-based).
            # The ingestion layer will match these against def line ranges from
            # the actual indexed source — so we provide a "file was hit" signal.
            # For accurate line mapping, a JaCoCo XML report should be used instead.
            lines: dict[int, int] = {}
            for probe_idx, hit in enumerate(probes):
                if hit:
                    # Use probe index + 1 as synthetic line indicator
                    lines[probe_idx + 1] = 1

            if lines:
                if file_path in files:
                    # Merge with existing (multiple classes in same file)
                    for line_no, hits in lines.items():
                        files[file_path].lines[line_no] = (
                            files[file_path].lines.get(line_no, 0) + hits
                        )
                else:
                    files[file_path] = FileCoverage(path=file_path, lines=lines)

        if files:
            result[test_id] = CoverageReport(source_format="jacoco_per_test", files=files)

    return result


def _class_to_path(
    class_name: str,
    class_to_source: dict[str, str] | None,
    base_path: Path | None,
) -> str | None:
    """Convert a JVM class name to a source file path."""
    if class_to_source and class_name in class_to_source:
        path = class_to_source[class_name]
    else:
        # Convention: com/example/Foo$Inner → src/main/java/com/example/Foo.java
        # Strip inner classes
        outer_class = class_name.split("$")[0]
        # JaCoCo uses / as separator
        path = outer_class.replace("/", "/") + ".java"
        # Try common source roots
        for prefix in ("src/main/java/", "src/main/kotlin/", ""):
            candidate = prefix + path
            if base_path and (base_path / candidate).exists():
                path = candidate
                break
        else:
            path = "src/main/java/" + path

    if base_path:
        try:
            path = str(Path(path).relative_to(base_path))
        except ValueError:
            pass

    return path


def _parse_exec_file(exec_path: Path) -> dict[str, list[bool]]:
    """Parse a JaCoCo .exec binary file.

    Returns:
        Mapping of class_name → list of probe booleans.
    """
    data = exec_path.read_bytes()
    if len(data) < 5:
        return {}

    pos = 0

    # Verify magic number
    magic = struct.unpack_from(">I", data, pos)[0]
    pos += 4
    if magic != _MAGIC:
        log.debug("jacoco_per_test.bad_magic", file=str(exec_path), magic=hex(magic))
        return {}

    # Read version
    _version = struct.unpack_from(">H", data, pos)[0]
    pos += 2

    result: dict[str, list[bool]] = {}

    while pos < len(data):
        if pos >= len(data):
            break

        block_type = data[pos]
        pos += 1

        if block_type == _BLOCK_SESSIONINFO:
            # Session info: id (utf), start (long), dump (long)
            str_len = struct.unpack_from(">H", data, pos)[0]
            pos += 2 + str_len + 8 + 8  # skip id string + timestamps

        elif block_type == _BLOCK_EXECUTIONDATA:
            # Execution data: class_id (long), class_name (utf), probes (boolean[])
            _class_id = struct.unpack_from(">q", data, pos)[0]
            pos += 8

            # Read UTF string (modified UTF-8 in JaCoCo)
            str_len = struct.unpack_from(">H", data, pos)[0]
            pos += 2
            class_name = data[pos:pos + str_len].decode("utf-8", errors="replace")
            pos += str_len

            # Read probes: length (varint via short) + boolean array
            probe_count = struct.unpack_from(">H", data, pos)[0]
            pos += 2

            probes: list[bool] = []
            for _ in range(probe_count):
                if pos < len(data):
                    probes.append(data[pos] != 0)
                    pos += 1
                else:
                    probes.append(False)

            if any(probes):
                result[class_name] = probes

        else:
            # Unknown block type — can't continue safely
            break

    return result
