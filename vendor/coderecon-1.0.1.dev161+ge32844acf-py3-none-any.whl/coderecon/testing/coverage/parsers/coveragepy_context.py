"""Parser for coverage.py SQLite database with per-test context.

When pytest-cov runs with --cov-context=test, the .coverage SQLite DB
contains a `context` table that maps each covered arc (line pair) to
the test that was running when it was hit.

Schema (coverage.py 7.x):
    file:    id INTEGER, path TEXT
    context: id INTEGER, context TEXT
    arc:     file_id INTEGER, context_id INTEGER, fromno INTEGER, tono INTEGER

Context strings are formatted as:
    "tests/cli/test_run.py::test_basic|run"
    "tests/cli/test_run.py::TestClass.test_method|setup"

The |suffix indicates the test phase (run, setup, teardown).
We strip the suffix to get the canonical test identifier.
"""

from __future__ import annotations

import sqlite3
from collections import defaultdict
from pathlib import Path

import structlog

from coderecon.testing.coverage.models import CoverageReport, FileCoverage

log = structlog.get_logger(__name__)


def parse_coveragepy_context(
    db_path: Path,
    *,
    base_path: Path | None = None,
) -> dict[str, CoverageReport]:
    """Parse a .coverage SQLite DB into per-test CoverageReports.

    Args:
        db_path: Path to the .coverage SQLite database.
        base_path: If set, file paths are made relative to this.

    Returns:
        Mapping of test_id → CoverageReport containing only the lines
        hit during that test. Empty dict if DB is missing or malformed.
    """
    if not db_path.exists():
        log.debug("coveragepy_context.db_not_found", path=str(db_path))
        return {}

    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except sqlite3.Error:
        log.debug("coveragepy_context.open_failed", path=str(db_path), exc_info=True)
        return {}

    try:
        return _parse_db(conn, base_path)
    except sqlite3.Error:
        log.debug("coveragepy_context.parse_failed", path=str(db_path), exc_info=True)
        return {}
    finally:
        conn.close()


def _normalize_pytest_context(raw: str) -> str:
    """Normalize pytest context to canonical test_id format.

    Input:  "tests/foo.py::TestClass::test_method"  (pytest node id)
    Output: "tests/foo.py::TestClass.test_method"   (path::dotted.lexical_path)

    The canonical format uses a single :: separator between file path and
    a dotted lexical path — matching def_facts.lexical_path convention.
    """
    parts = raw.split("::")
    if len(parts) < 2:
        return raw
    file_path = parts[0]
    lexical_path = ".".join(parts[1:])
    return f"{file_path}::{lexical_path}"


def _parse_db(
    conn: sqlite3.Connection,
    base_path: Path | None,
) -> dict[str, CoverageReport]:
    """Internal: read arc table joined with context and file tables."""
    # Verify tables exist
    tables = {
        row[0]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    required = {"file", "context", "arc"}
    if not required.issubset(tables):
        # Older coverage.py or non-context DB — may have line_bits instead of arc
        if "line_bits" in tables and "context" in tables:
            return _parse_line_bits_db(conn, base_path)
        log.debug(
            "coveragepy_context.missing_tables",
            have=tables,
            need=required,
        )
        return {}

    # Load file ID → path mapping
    file_map: dict[int, str] = {}
    for file_id, path in conn.execute("SELECT id, path FROM file").fetchall():
        if base_path:
            try:
                path = str(Path(path).relative_to(base_path))
            except ValueError:
                pass
        file_map[file_id] = path

    # Load context ID → canonical test_id mapping (strip |phase suffix)
    context_map: dict[int, str] = {}
    for ctx_id, ctx_str in conn.execute("SELECT id, context FROM context").fetchall():
        if not ctx_str:
            continue
        # Strip phase suffix: "path::test|run" → "path::test"
        test_id = ctx_str.rsplit("|", 1)[0] if "|" in ctx_str else ctx_str
        if not test_id:
            continue
        context_map[ctx_id] = _normalize_pytest_context(test_id)

    if not context_map:
        return {}

    # Build per-test, per-file line hits from arc table
    # Arc (fromno, tono): tono is the line executed. fromno < 0 means entry,
    # tono < 0 means exit. We only care about positive tono values (actual lines).
    per_test_lines: dict[str, dict[str, dict[int, int]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(int))
    )

    cursor = conn.execute("SELECT file_id, context_id, tono FROM arc WHERE tono > 0")
    for file_id, context_id, tono in cursor:
        file_path = file_map.get(file_id)
        test_id = context_map.get(context_id)
        if file_path and test_id:
            per_test_lines[test_id][file_path][tono] += 1

    # Convert to CoverageReport objects
    result: dict[str, CoverageReport] = {}
    for test_id, files_data in per_test_lines.items():
        files: dict[str, FileCoverage] = {}
        for file_path, lines in files_data.items():
            files[file_path] = FileCoverage(path=file_path, lines=lines)
        result[test_id] = CoverageReport(source_format="coveragepy_context", files=files)

    return result


def _parse_line_bits_db(
    conn: sqlite3.Connection,
    base_path: Path | None,
) -> dict[str, CoverageReport]:
    """Parse coverage.py DBs that use line_bits table (coverage.py 7.x+).

    Schema:
        line_bits: file_id INTEGER, context_id INTEGER, numbits BLOB
    The numbits blob encodes a set of line numbers using coverage.py's
    internal numbits format.
    """
    from coderecon.testing.coverage.parsers._numbits import numbits_to_nums

    # Load file ID → path mapping
    file_map: dict[int, str] = {}
    for file_id, path in conn.execute("SELECT id, path FROM file").fetchall():
        if base_path:
            try:
                path = str(Path(path).relative_to(base_path))
            except ValueError:
                pass
        file_map[file_id] = path

    # Load context ID → canonical test_id
    context_map: dict[int, str] = {}
    for ctx_id, ctx_str in conn.execute("SELECT id, context FROM context").fetchall():
        if not ctx_str:
            continue
        test_id = ctx_str.rsplit("|", 1)[0] if "|" in ctx_str else ctx_str
        if not test_id:
            continue
        context_map[ctx_id] = _normalize_pytest_context(test_id)

    if not context_map:
        return {}

    # Build per-test line data from line_bits
    per_test_lines: dict[str, dict[str, dict[int, int]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(int))
    )

    cursor = conn.execute("SELECT file_id, context_id, numbits FROM line_bits")
    for file_id, context_id, numbits_blob in cursor:
        file_path = file_map.get(file_id)
        test_id = context_map.get(context_id)
        if file_path and test_id and numbits_blob:
            line_numbers = numbits_to_nums(numbits_blob)
            for line_no in line_numbers:
                per_test_lines[test_id][file_path][line_no] += 1

    result: dict[str, CoverageReport] = {}
    for test_id, files_data in per_test_lines.items():
        files: dict[str, FileCoverage] = {}
        for file_path, lines in files_data.items():
            files[file_path] = FileCoverage(path=file_path, lines=lines)
        result[test_id] = CoverageReport(source_format="coveragepy_context", files=files)

    return result
