"""Parser for SimpleCov per-test .resultset.json output.

When SimpleCov is configured with per-test command names (via
SIMPLECOV_PER_TEST=1 environment variable), .resultset.json contains
entries keyed by test identifier:

{
  "RSpec:spec/models/user_spec.rb:UserSpec#test_valid": {
    "coverage": {
      "app/models/user.rb": {
        "lines": [null, 1, 1, 0, null, 1, ...]
      }
    }
  },
  ...
}

Each entry's "lines" array is indexed by 0-based line number.
null = not instrumentable, integer = hit count.
"""

from __future__ import annotations

import json
from pathlib import Path

import structlog

from coderecon.testing.coverage.models import CoverageReport, FileCoverage

log = structlog.get_logger(__name__)


def _normalize_simplecov_test_id(raw: str) -> str:
    """Normalize SimpleCov test_id to canonical format.

    Input formats:
        "RSpec:spec/models/user_spec.rb:UserSpec#test_valid"
        "spec/models/user_spec.rb:UserSpec#test_valid"
        "Minitest:test/models/user_test.rb:UserTest#test_valid"

    Output: "{file_path}::{Class.method}"
    """
    # Strip framework prefix if present (RSpec:, Minitest:, etc.)
    work = raw
    if ":" in work:
        parts = work.split(":", 2)
        # If first part looks like a framework name (no slashes), strip it
        if "/" not in parts[0] and len(parts) >= 2:
            work = ":".join(parts[1:])

    # Split file path from test identifier
    # Format after stripping prefix: "spec/models/user_spec.rb:UserSpec#test_valid"
    if ":" in work:
        file_path, test_part = work.split(":", 1)
    else:
        return raw  # Can't normalize, return as-is

    # Normalize test_part: "UserSpec#test_valid" → "UserSpec.test_valid"
    lexical_path = test_part.replace("#", ".")
    return f"{file_path}::{lexical_path}"


def parse_simplecov_per_test(
    resultset_path: Path,
    *,
    base_path: Path | None = None,
) -> dict[str, CoverageReport]:
    """Parse SimpleCov .resultset.json into per-test CoverageReports.

    Args:
        resultset_path: Path to .resultset.json file.
        base_path: If set, file paths are made relative to this.

    Returns:
        Mapping of test_id → CoverageReport. Empty dict if no data found.
    """
    if not resultset_path.exists():
        log.debug("simplecov_per_test.file_not_found", path=str(resultset_path))
        return {}

    try:
        data = json.loads(resultset_path.read_text())
    except (json.JSONDecodeError, OSError):
        log.debug("simplecov_per_test.parse_error", path=str(resultset_path), exc_info=True)
        return {}

    if not isinstance(data, dict):
        return {}

    result: dict[str, CoverageReport] = {}

    for raw_test_id, test_data in data.items():
        if not isinstance(test_data, dict):
            continue

        coverage_data = test_data.get("coverage")
        if not isinstance(coverage_data, dict):
            continue

        files: dict[str, FileCoverage] = {}

        for file_path, file_data in coverage_data.items():
            # SimpleCov has two formats:
            # Old: {"lines": [null, 1, 0, ...]}
            # New: [null, 1, 0, ...] directly
            if isinstance(file_data, dict):
                lines_array = file_data.get("lines")
            elif isinstance(file_data, list):
                lines_array = file_data
            else:
                continue

            if not isinstance(lines_array, list):
                continue

            # Convert 0-indexed array to 1-indexed line→hits dict
            lines: dict[int, int] = {}
            for idx, hits in enumerate(lines_array):
                if hits is not None:
                    lines[idx + 1] = hits  # 1-based line numbers

            if not lines:
                continue

            resolved_path = file_path
            if base_path:
                try:
                    resolved_path = str(Path(file_path).relative_to(base_path))
                except ValueError:
                    pass

            files[resolved_path] = FileCoverage(path=resolved_path, lines=lines)

        if files:
            test_id = _normalize_simplecov_test_id(raw_test_id)
            result[test_id] = CoverageReport(source_format="simplecov_per_test", files=files)

    return result
