"""Version manager mismatch detection.

Compares resolved runtime versions against project-declared versions
(from .python-version, .nvmrc, .tool-versions, rust-toolchain.toml, etc.)
to detect silent wrong-version test execution at index time.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import structlog

log = structlog.get_logger(__name__)


@dataclass
class VersionMismatch:
    """A detected version mismatch between project declaration and resolved runtime."""

    tool: str  # "python", "node", "ruby", "rust", "java"
    declared: str  # "3.11" (from .python-version)
    resolved: str  # "3.9.7" (from shutil.which)
    source_file: str  # ".python-version"
    severity: Literal["warning", "error"]  # error if major version differs


def check_version_mismatch(
    language: str,
    resolved_version: str | None,
    context_root: Path,
    repo_root: Path | None = None,
) -> VersionMismatch | None:
    """Compare resolved runtime version against project version declarations.

    Returns a VersionMismatch if the resolved version doesn't satisfy the
    project's declared version constraint. Returns None if no mismatch or
    no version file found.
    """
    if not resolved_version:
        return None

    check_roots = [context_root]
    if repo_root and repo_root != context_root:
        check_roots.append(repo_root)

    version_files = _VERSION_FILES.get(language, [])
    for filename, parser in version_files:
        for root in check_roots:
            version_file = root / filename
            if version_file.exists():
                try:
                    declared = parser(version_file.read_text())
                except (OSError, ValueError):
                    continue
                if declared and not _version_satisfies(resolved_version, declared):
                    return VersionMismatch(
                        tool=language,
                        declared=declared,
                        resolved=resolved_version,
                        source_file=filename,
                        severity="error" if _major_differs(resolved_version, declared) else "warning",
                    )
    return None


def _version_satisfies(resolved: str, declared: str) -> bool:
    """Check if resolved version satisfies declared version constraint.

    Handles prefix matching: declared "3.11" satisfied by "3.11.4".
    """
    resolved_clean = resolved.lstrip("v").strip()
    declared_clean = declared.lstrip("v").strip()

    # Handle >= or ~ or ^ constraints by extracting base version
    if declared_clean.startswith((">=", "~", "^")):
        declared_clean = re.sub(r"^[>=~^]+\s*", "", declared_clean)

    # Prefix match: "3.11" matches "3.11.4"
    resolved_parts = resolved_clean.split(".")
    declared_parts = declared_clean.split(".")

    # Compare only as many parts as declared specifies
    for i, decl_part in enumerate(declared_parts):
        if i >= len(resolved_parts):
            return False
        # Handle wildcard
        if decl_part == "*" or decl_part == "x":
            continue
        try:
            if int(resolved_parts[i]) != int(decl_part):
                return False
        except ValueError:
            # Non-numeric part (e.g., "rc1"), do string comparison
            if resolved_parts[i] != decl_part:
                return False
    return True


def _major_differs(resolved: str, declared: str) -> bool:
    """Check if major version differs between resolved and declared."""
    try:
        resolved_major = int(resolved.lstrip("v").split(".")[0])
        declared_clean = re.sub(r"^[>=~^]+\s*", "", declared.lstrip("v"))
        declared_major = int(declared_clean.split(".")[0])
        return resolved_major != declared_major
    except (ValueError, IndexError):
        return False


def _parse_plain_version(content: str) -> str | None:
    """Parse a plain version file (single version on first line)."""
    line = content.strip().splitlines()[0].strip() if content.strip() else None
    if not line:
        return None
    # Strip common prefixes
    line = line.lstrip("v")
    # Validate it looks like a version
    if re.match(r"\d+(\.\d+)*", line):
        return line
    return None


def _parse_tool_versions(content: str, tool: str) -> str | None:
    """Parse .tool-versions (asdf/mise format) for a specific tool."""
    for line in content.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) >= 2 and parts[0] == tool:
            version = parts[1].lstrip("v")
            if re.match(r"\d+(\.\d+)*", version):
                return version
    return None


def _parse_rust_toolchain(content: str) -> str | None:
    """Parse rust-toolchain.toml for channel version."""
    # Look for channel = "1.75" or channel = "stable"
    match = re.search(r'channel\s*=\s*"([^"]+)"', content)
    if match:
        channel = match.group(1)
        # Only return if it's a version number, not "stable"/"nightly"
        if re.match(r"\d+(\.\d+)*", channel):
            return channel
    return None


# Map language -> list of (filename, parser_fn)
# Order matters: first match wins
_VERSION_FILES: dict[str, list[tuple[str, object]]] = {
    "python": [
        (".python-version", _parse_plain_version),
        (".tool-versions", lambda c: _parse_tool_versions(c, "python")),
    ],
    "javascript": [
        (".nvmrc", _parse_plain_version),
        (".node-version", _parse_plain_version),
        (".tool-versions", lambda c: _parse_tool_versions(c, "nodejs")),
    ],
    "typescript": [
        (".nvmrc", _parse_plain_version),
        (".node-version", _parse_plain_version),
        (".tool-versions", lambda c: _parse_tool_versions(c, "nodejs")),
    ],
    "ruby": [
        (".ruby-version", _parse_plain_version),
        (".tool-versions", lambda c: _parse_tool_versions(c, "ruby")),
    ],
    "rust": [
        ("rust-toolchain.toml", _parse_rust_toolchain),
        ("rust-toolchain", _parse_plain_version),
    ],
    "java": [
        (".sdkmanrc", lambda c: _parse_tool_versions(c, "java")),
        (".tool-versions", lambda c: _parse_tool_versions(c, "java")),
    ],
    "go": [
        (".tool-versions", lambda c: _parse_tool_versions(c, "golang")),
    ],
}
