"""Coverage emitters for test runner packs.

Coverage is treated as an invocation artifact - each test run that enables
coverage produces files in its artifact directory that agents consume directly.

Design principles:
- No merge: Each invocation writes its own coverage artifact
- No conversion: Native formats preserved, agent reads directly
- Three-state capability: unsupported | available | missing_prereq
- Explicit support: Only packs with tested emitters claim coverage support
- Per-test context: Where supported, emitters produce per-test coverage
  artifacts that map individual test identifiers to covered source lines.
"""

from __future__ import annotations

import shutil
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)

class CoverageCapability(Enum):
    """Three-state coverage capability."""

    UNSUPPORTED = "unsupported"  # Pack does not support coverage
    AVAILABLE = "available"  # Coverage ready to use
    MISSING_PREREQ = "missing_prereq"  # Could work but prereq missing


class PerTestStrategy(Enum):
    """Per-test coverage isolation strategy.

    NATIVE_BATCH: Single test invocation, framework provides per-test
        line-hit attribution (e.g., pytest-cov --cov-context=test).
    PER_FILE_BATCH: Executor already runs per-target; each target's
        aggregate artifact is attributed to that target (file-level).
    UNSUPPORTED: No per-test mechanism; aggregate artifact attributed
        to the invocation target (file-level, same as PER_FILE_BATCH
        in practice but less accurate if targets are batched).
    """

    NATIVE_BATCH = "native_batch"
    PER_FILE_BATCH = "per_file_batch"
    UNSUPPORTED = "unsupported"


@dataclass
class PackRuntime:
    """Runtime context for a runner pack."""

    workspace_root: Path
    runner_available: bool  # Is the test runner installed?
    coverage_tools: dict[str, bool] = field(default_factory=dict)  # tool -> available

@dataclass
class CoverageArtifact:
    """Coverage artifact metadata."""

    format: str  # e.g., "lcov", "istanbul", "jacoco"
    path: Path  # Path to coverage file/directory
    pack_id: str  # Which pack produced this
    invocation_id: str  # Links to test invocation
    per_test_db_path: Path | None = None  # Path to per-test context DB (if NATIVE_BATCH)

class CoverageEmitter(ABC):
    """Abstract base for coverage emission.

    Each pack that supports coverage implements an emitter that:
    1. Detects whether coverage is possible (capability)
    2. Provides command-line modifications to enable coverage
    3. Describes where to find the coverage artifact
    4. (Optional) Provides per-test coverage context
    """

    @property
    @abstractmethod
    def format_id(self) -> str:
        """Coverage format identifier (e.g., 'lcov', 'istanbul')."""
        ...

    @property
    def prereq_name(self) -> str:
        """Human-readable name of the prerequisite tool for coverage.

        Used in diagnostics when coverage is MISSING_PREREQ.
        """
        return "coverage tool"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        """How this emitter provides per-test coverage isolation."""
        return PerTestStrategy.UNSUPPORTED

    @abstractmethod
    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        """Detect whether coverage is available."""
        ...

    @abstractmethod
    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,
    ) -> list[str]:
        """Modify test command to enable coverage.

        Args:
            cmd: Base test command.
            output_dir: Directory for coverage artifacts.
            source_dirs: Optional list of source directories to scope coverage.
                        When provided, generates targeted ``--cov=<dir>`` args
                        instead of ``--cov=.``.
        """
        ...

    def modify_command_per_test(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,
    ) -> list[str]:
        """Modify command for per-test context collection.

        Only meaningful when per_test_strategy != UNSUPPORTED.
        Default: delegates to modify_command (PER_FILE_BATCH needs no extra flags).
        """
        return self.modify_command(cmd, output_dir, source_dirs)

    def per_test_artifact_path(self, output_dir: Path) -> Path | None:
        """Path to per-test context artifact (if NATIVE_BATCH).

        Returns None for strategies that don't produce a separate
        per-test artifact (PER_FILE_BATCH / UNSUPPORTED use the
        standard artifact attributed to the target).
        """
        return None

    @abstractmethod
    def artifact_path(self, output_dir: Path) -> Path:
        """Path where coverage artifact will be written."""
        ...

# Python - pytest-cov (lcov output + per-test context via .coverage DB)

class PytestCovEmitter(CoverageEmitter):
    """Coverage via pytest-cov with lcov output and per-test context."""

    @property
    def format_id(self) -> str:
        return "lcov"

    @property
    def prereq_name(self) -> str:
        return "pytest-cov"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.NATIVE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        if not runtime.coverage_tools.get("pytest-cov", False):
            return CoverageCapability.MISSING_PREREQ
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        result = [*cmd, f"--cov-report=lcov:{cov_path}/lcov.info"]
        if source_dirs:
            for d in source_dirs:
                result.append(f"--cov={d}")
        else:
            result.append("--cov=.")
        return result

    def modify_command_per_test(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        # --cov-context=test: pytest-cov records which test was running for each arc
        # Produces a .coverage SQLite DB with context table mapping test→lines
        result = [
            *cmd,
            f"--cov-report=lcov:{cov_path}/lcov.info",
            "--cov-context=test",
        ]
        if source_dirs:
            for d in source_dirs:
                result.append(f"--cov={d}")
        else:
            result.append("--cov=.")
        return result

    def per_test_artifact_path(self, output_dir: Path) -> Path | None:
        return output_dir / "coverage" / ".coverage"

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage" / "lcov.info"

# JavaScript - Jest/Vitest (istanbul/lcov)

class JestCoverageEmitter(CoverageEmitter):
    """Coverage via Jest's built-in coverage (istanbul format)."""

    @property
    def format_id(self) -> str:
        return "istanbul"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.PER_FILE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        return [
            *cmd,
            "--coverage",
            f"--coverageDirectory={cov_path}",
            "--coverageReporters=json",
            "--coverageReporters=lcov",
        ]

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage"

class VitestCoverageEmitter(CoverageEmitter):
    """Coverage via Vitest's built-in coverage (v8/istanbul)."""

    @property
    def format_id(self) -> str:
        return "istanbul"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.PER_FILE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        return [
            *cmd,
            "--coverage",
            f"--coverage.reportsDirectory={cov_path}",
            "--coverage.reporter=json",
            "--coverage.reporter=lcov",
        ]

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage"

# Go - go test -coverprofile

class GoCoverageEmitter(CoverageEmitter):
    """Coverage via go test -coverprofile (per-package isolation)."""

    @property
    def format_id(self) -> str:
        return "gocov"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.PER_FILE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage" / "coverage.out"
        cov_path.parent.mkdir(parents=True, exist_ok=True)
        return [*cmd, f"-coverprofile={cov_path}", "-coverpkg=./..."]

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage" / "coverage.out"

# Rust - cargo-llvm-cov (lcov output)

class CargoLlvmCovEmitter(CoverageEmitter):
    """Coverage via cargo-llvm-cov with lcov output (per-binary isolation via nextest)."""

    @property
    def format_id(self) -> str:
        return "lcov"

    @property
    def prereq_name(self) -> str:
        return "cargo-llvm-cov"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.PER_FILE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        if not shutil.which("cargo-llvm-cov"):
            return CoverageCapability.MISSING_PREREQ
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage" / "lcov.info"
        cov_path.parent.mkdir(parents=True, exist_ok=True)
        new_cmd = ["cargo", "llvm-cov", "--lcov", f"--output-path={cov_path}"]
        if len(cmd) > 2:
            new_cmd.extend(cmd[2:])
        return new_cmd

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage" / "lcov.info"

# Java - JaCoCo (via Maven/Gradle)

class MavenJacocoEmitter(CoverageEmitter):
    """Coverage via JaCoCo Maven plugin with per-test exec isolation."""

    @property
    def format_id(self) -> str:
        return "jacoco"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.NATIVE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        cov_path.mkdir(parents=True, exist_ok=True)
        # Redirect JaCoCo exec data and report output to our artifact dir
        return [
            *cmd,
            f"-Djacoco.destFile={cov_path}/jacoco.exec",
            f"-Djacoco.outputDirectory={cov_path}",
            "jacoco:report",
        ]

    def modify_command_per_test(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        per_test_dir = cov_path / "per-test"
        per_test_dir.mkdir(parents=True, exist_ok=True)
        # JaCoCo agent with output=tcpserver + JUnit5 listener that dumps per-test .exec files
        return [
            *cmd,
            f"-Djacoco.destFile={cov_path}/jacoco.exec",
            f"-Djacoco.outputDirectory={cov_path}",
            f"-Djacoco.perTestDir={per_test_dir}",
            "-Djacoco.perTest=true",
            "jacoco:report",
        ]

    def per_test_artifact_path(self, output_dir: Path) -> Path | None:
        return output_dir / "coverage" / "per-test"

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage"

class GradleJacocoEmitter(CoverageEmitter):
    """Coverage via JaCoCo Gradle plugin with per-test exec isolation."""

    @property
    def format_id(self) -> str:
        return "jacoco"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.NATIVE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        cov_path.mkdir(parents=True, exist_ok=True)
        return [
            *cmd,
            "jacocoTestReport",
            f"-Pjacoco.reportsDir={cov_path}",
        ]

    def modify_command_per_test(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        per_test_dir = cov_path / "per-test"
        per_test_dir.mkdir(parents=True, exist_ok=True)
        return [
            *cmd,
            "jacocoTestReport",
            f"-Pjacoco.reportsDir={cov_path}",
            f"-Pjacoco.perTestDir={per_test_dir}",
            "-Pjacoco.perTest=true",
        ]

    def per_test_artifact_path(self, output_dir: Path) -> Path | None:
        return output_dir / "coverage" / "per-test"

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage"

# .NET - coverlet (cobertura output)

class DotnetCoverletEmitter(CoverageEmitter):
    """Coverage via coverlet for .NET."""

    @property
    def format_id(self) -> str:
        return "cobertura"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.PER_FILE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        return [
            *cmd,
            "--collect:XPlat Code Coverage",
            f"--results-directory:{cov_path}",
        ]

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage"

# Ruby - SimpleCov

class SimpleCovEmitter(CoverageEmitter):
    """Coverage via SimpleCov for Ruby with per-test grouping."""

    @property
    def format_id(self) -> str:
        return "simplecov"

    @property
    def prereq_name(self) -> str:
        return "simplecov"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.NATIVE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        if not runtime.coverage_tools.get("simplecov", False):
            return CoverageCapability.MISSING_PREREQ
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        return [f"COVERAGE_DIR={cov_path}", *cmd]

    def modify_command_per_test(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        # SIMPLECOV_PER_TEST=1 triggers per-test grouping in SimpleCov config
        return [f"COVERAGE_DIR={cov_path}", "SIMPLECOV_PER_TEST=1", *cmd]

    def per_test_artifact_path(self, output_dir: Path) -> Path | None:
        return output_dir / "coverage" / ".resultset.json"

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage"

# PHP - PHPUnit coverage

class PHPUnitCoverageEmitter(CoverageEmitter):
    """Coverage via PHPUnit with per-test XML output."""

    @property
    def format_id(self) -> str:
        return "clover"

    @property
    def prereq_name(self) -> str:
        return "xdebug or pcov"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.NATIVE_BATCH

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        if not runtime.coverage_tools.get("xdebug", False) and not runtime.coverage_tools.get(
            "pcov", False
        ):
            return CoverageCapability.MISSING_PREREQ
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage" / "clover.xml"
        return [*cmd, f"--coverage-clover={cov_path}"]

    def modify_command_per_test(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage" / "per-test"
        # --coverage-xml produces per-test line attribution natively
        return [*cmd, f"--coverage-xml={cov_path}"]

    def per_test_artifact_path(self, output_dir: Path) -> Path | None:
        return output_dir / "coverage" / "per-test"

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage" / "clover.xml"

# Dart/Flutter

class DartCoverageEmitter(CoverageEmitter):
    """Coverage via dart test --coverage (no per-test isolation)."""

    @property
    def format_id(self) -> str:
        return "dart"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.UNSUPPORTED

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        return [*cmd, f"--coverage={cov_path}"]

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage"

# C++ - gcov/lcov via cmake --coverage

class CTestGcovEmitter(CoverageEmitter):
    """Coverage via cmake --coverage (gcov) with lcov collection (no per-test isolation)."""

    @property
    def format_id(self) -> str:
        return "lcov"

    @property
    def prereq_name(self) -> str:
        return "lcov"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.UNSUPPORTED

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        if not shutil.which("lcov"):
            return CoverageCapability.MISSING_PREREQ
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage" / "lcov.info"
        cov_path.parent.mkdir(parents=True, exist_ok=True)
        # CTest commands are bash -c "cmake -B ... && cmake --build ... && ctest ..."
        # Inject --coverage into cmake build and collect lcov after test run
        if cmd[0] == "bash" and cmd[1] == "-c":
            script = cmd[2]
            # Add coverage flags to cmake configure
            script = script.replace(
                "-DCMAKE_BUILD_TYPE=Release",
                "-DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_FLAGS=--coverage -DCMAKE_CXX_FLAGS=--coverage",
            )
            # Append lcov collection after ctest
            script += (
                f" && lcov --capture --directory . --output-file {cov_path}"
                f" --ignore-errors mismatch,empty,unused --quiet"
            )
            return ["bash", "-c", script]
        # Fallback: append lcov args
        return cmd

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage" / "lcov.info"

# Swift - swift test --enable-code-coverage (llvm-cov)

class SwiftCoverageEmitter(CoverageEmitter):
    """Coverage via swift test --enable-code-coverage (no per-test isolation)."""

    @property
    def format_id(self) -> str:
        return "llvm-cov"

    @property
    def per_test_strategy(self) -> PerTestStrategy:
        return PerTestStrategy.UNSUPPORTED

    def capability(self, runtime: PackRuntime) -> CoverageCapability:
        if not runtime.runner_available:
            return CoverageCapability.UNSUPPORTED
        return CoverageCapability.AVAILABLE

    def modify_command(
        self,
        cmd: list[str],
        output_dir: Path,
        source_dirs: list[str] | None = None,  # noqa: ARG002
    ) -> list[str]:
        cov_path = output_dir / "coverage"
        cov_path.mkdir(parents=True, exist_ok=True)
        # Add --enable-code-coverage and export after test run
        # swift test --enable-code-coverage produces .build/debug/codecov/*.profdata
        # Then llvm-cov export converts to lcov format
        if "swift" in cmd and "test" in cmd:
            new_cmd = [*cmd, "--enable-code-coverage"]
            # Wrap to also export coverage to a portable format
            script = (
                f"{' '.join(new_cmd)} && "
                f"BIN=$(swift build --show-bin-path) && "
                f"llvm-cov export -instr-profile .build/debug/codecov/default.profdata"
                f" $BIN/*.xctest -format=lcov > {cov_path}/lcov.info 2>/dev/null || true"
            )
            return ["bash", "-c", script]
        return [*cmd, "--enable-code-coverage"]

    def artifact_path(self, output_dir: Path) -> Path:
        return output_dir / "coverage" / "lcov.info"

# Emitter Registry

# Map pack_id -> emitter class
EMITTER_REGISTRY: dict[str, type[CoverageEmitter]] = {
    "python.pytest": PytestCovEmitter,
    "js.jest": JestCoverageEmitter,
    "js.vitest": VitestCoverageEmitter,
    "go.gotest": GoCoverageEmitter,
    "rust.nextest": CargoLlvmCovEmitter,
    "rust.cargo_test": CargoLlvmCovEmitter,
    "java.maven": MavenJacocoEmitter,
    "java.gradle": GradleJacocoEmitter,
    "csharp.dotnet": DotnetCoverletEmitter,
    "cpp.ctest": CTestGcovEmitter,
    "swift.swiftpm": SwiftCoverageEmitter,
    "ruby.rspec": SimpleCovEmitter,
    "ruby.minitest": SimpleCovEmitter,
    "php.phpunit": PHPUnitCoverageEmitter,
    "dart.dart_test": DartCoverageEmitter,
    "dart.flutter_test": DartCoverageEmitter,
}

# Packs that explicitly do not support coverage
NO_COVERAGE_PACKS: frozenset[str] = frozenset(
    {
        "kotlin.gradle",  # Use Java JaCoCo
        "scala.sbt",  # Use Java JaCoCo
        "bash.bats",  # No coverage support
        "powershell.pester",  # Coverage via different mechanism
        "lua.busted",  # No standard coverage
    }
)

def get_emitter(pack_id: str) -> CoverageEmitter | None:
    """Get coverage emitter for a pack."""
    emitter_class = EMITTER_REGISTRY.get(pack_id)
    if emitter_class is None:
        return None
    return emitter_class()

def supports_coverage(pack_id: str) -> bool:
    """Check if a pack has coverage support."""
    return pack_id in EMITTER_REGISTRY
