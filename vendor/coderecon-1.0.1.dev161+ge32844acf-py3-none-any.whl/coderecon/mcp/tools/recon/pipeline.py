"""Recon pipeline — context retrieval + tool registration.

Two ranking paths:
  - **Model path** (when LightGBM models present): gate → file ranker →
    def ranker → cutoff.
  - **Heuristic path** (fallback): RRF fusion → file prune → elbow cutoff.

Also registers the ``recon``, ``recon_map``, and optionally
``recon_raw_signals`` MCP tools.
"""

from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog
from fastmcp import Context
from pydantic import Field

from coderecon.config.constants import MS_PER_SEC

if TYPE_CHECKING:
    from fastmcp import FastMCP

    from coderecon.index.db import Database
    from coderecon.mcp.context import AppContext

log = structlog.get_logger(__name__)

from coderecon.mcp.tools.recon.pipeline_scoring import (  # noqa: E402
    _build_ce_documents,  # noqa: F401  # re-exported for tests
    _read_signature,
    _read_snippet,
    _score_cross_encoder,
)


def _build_query_metrics(diagnostics: dict, scored: list[tuple[dict, float]], seeds: list | None, pins: list | None) -> dict:
    """Build aggregate query metrics from diagnostics."""
    total = diagnostics.get("candidate_count", 0)
    metrics = {
        "total_candidates_scored": total,
        "retriever_coverage": {
            "term_match": diagnostics.get("term_hits", 0),
            "lexical": diagnostics.get("lex_hits", 0),
            "graph": diagnostics.get("graph_hits", 0),
            "symbol": diagnostics.get("symbol_hits", 0),
        },
    }
    if scored:
        scores = [s for _, s in scored]
        metrics["top_score"] = scores[0] if scores else 0
        metrics["score_p50"] = scores[len(scores) // 2] if scores else 0
        # Find largest score drop
        if len(scores) > 1:
            gaps = [scores[i] - scores[i + 1] for i in range(len(scores) - 1)]
            max_gap_idx = max(range(len(gaps)), key=lambda i: gaps[i])
            metrics["score_drop_at"] = max_gap_idx + 1
        else:
            metrics["score_drop_at"] = 1
    if seeds:
        seed_set = set(seeds)
        seed_hits = sum(1 for c, _ in scored if c.get("name") in seed_set)
        metrics["seed_hit_rate"] = round(seed_hits / len(seeds), 2)
    if pins:
        pin_paths = set(pins)
        pin_hits = len(pin_paths & {c.get("path") for c, _ in scored})
        metrics["pin_hit_rate"] = round(pin_hits / len(pins), 2)
    return metrics

def _build_hints(metrics: dict, gate_label: str) -> list[str]:
    """Generate actionable hints from query metrics."""
    hints: list[str] = []
    cov = metrics.get("retriever_coverage", {})
    if cov.get("lexical", 0) == 0:
        hints.append(
            "Lexical retriever returned 0 hits — your query has no literal code strings. "
            "Include error messages, log strings, or comments for better coverage."
        )
    if cov.get("term_match", 0) == 0:
        hints.append(
            "No term matches — none of your query words matched symbol names. "
            "Try including exact function/class names."
        )
    if cov.get("symbol", 0) == 0 and cov.get("graph", 0) == 0:
        hints.append(
            "No seeds or graph hits. Consider calling recon_map first to discover "
            "key symbols, then pass them as seeds."
        )
    drop = metrics.get("score_drop_at")
    if drop and drop <= 5:
        hints.append(
            f"Sharp score drop at position {drop} — top {drop} results are strongly "
            f"relevant, the rest is speculative."
        )
    seed_rate = metrics.get("seed_hit_rate")
    if seed_rate is not None and seed_rate < 0.5:
        hints.append(
            f"Only {int(seed_rate * 100)}% of seeds resolved — some seed names may not "
            f"exist in this repo. Check symbol names against recon_map."
        )
    return hints

def _models_available() -> bool:
    """Return True if all four ranking models are present on disk."""
    data_dir = Path(__file__).resolve().parents[3] / "ranking" / "data"
    return all(
        (data_dir / name).exists()
        for name in ("gate.lgbm", "file_ranker.lgbm", "ranker.lgbm", "cutoff.lgbm")
    )

async def recon_pipeline(
    app_ctx: AppContext,
    task: str,
    seeds: list[str] | None = None,
    pins: list[str] | None = None,
) -> dict[str, Any]:
    """Run the full recon pipeline: retrieve → rank → cut → snippets.
    If LightGBM models are present: gate → file_ranker → ranker → cutoff.
    Otherwise: RRF fusion → file prune → elbow cutoff (model-free).
    """
    from coderecon.mcp.tools.recon.raw_signals import raw_signals_pipeline
    t0 = time.monotonic()
    repo_root = app_ctx.coordinator.repo_root
    # 1. Get raw signals (includes CE scoring + RRF fusion)
    raw = await raw_signals_pipeline(app_ctx, task, seeds=seeds, pins=pins)
    candidates = raw.get("candidates", [])
    query_features = raw.get("query_features", {})
    repo_features = raw.get("repo_features", {})
    diagnostics = raw.get("diagnostics", {})
    if _models_available():
        return _pipeline_model(
            candidates, query_features, repo_features, diagnostics,
            repo_root=repo_root, seeds=seeds, pins=pins, t0=t0,
            task=task, db=app_ctx.coordinator.db,
        )
    log.info("ranking.heuristic_mode", reason="models_unavailable")
    return _pipeline_heuristic(
        candidates, diagnostics,
        repo_root=repo_root, seeds=seeds, pins=pins, t0=t0,
        db=app_ctx.coordinator.db,
    )

def _pipeline_model(
    candidates: list[dict[str, Any]],
    query_features: dict[str, Any],
    repo_features: dict[str, Any],
    diagnostics: dict[str, Any],
    *,
    repo_root: Path,
    seeds: list[str] | None,
    pins: list[str] | None,
    t0: float,
    task: str,
    db: Database,
) -> dict[str, Any]:
    """Model path: gate → file ranker → def ranker → cutoff."""
    from coderecon.ranking.cutoff import load_cutoff
    from coderecon.ranking.features import (
        extract_cutoff_features,
        extract_file_ranker_features,
        extract_gate_features,
        extract_ranker_features,
    )
    from coderecon.ranking.file_ranker import load_file_ranker
    from coderecon.ranking.gate import load_gate
    from coderecon.ranking.models import GateLabel
    from coderecon.ranking.ranker import load_ranker
    # Gate
    gate = load_gate()
    gate_features = extract_gate_features(candidates, query_features, repo_features)
    gate_label = gate.classify(gate_features)
    if gate_label != GateLabel.OK:
        elapsed = round((time.monotonic() - t0) * MS_PER_SEC)
        metrics = {
            "scored": len(candidates),
            "term": diagnostics.get("term_hits", 0),
            "lex": diagnostics.get("lex_hits", 0),
            "graph": diagnostics.get("graph_hits", 0),
            "sym": diagnostics.get("symbol_hits", 0),
            "ms": elapsed,
        }
        hints = _build_hints(
            _build_query_metrics(diagnostics, [], seeds, pins),
            gate_label.value,
        )[:3]
        return {
            "gate": gate_label.value,
            "results": [],
            "n": 0,
            "metrics": metrics,
            "hints": hints,
        }
    # CE scoring already done in raw_signals_pipeline; proceed to file ranking
    # File Ranking (Stage 1) — prune to top files
    file_ranker = load_file_ranker()
    file_features, file_to_candidates = extract_file_ranker_features(
        candidates, query_features,
    )
    file_scores = file_ranker.score(file_features)
    scored_files = sorted(
        zip(file_features, file_scores, strict=True), key=lambda x: -x[1],
    )
    # TODO: Replace with elbow/gap-based cutoff on file_scores. Hardcoded 20
    # silently drops files that could contain relevant defs — caps recall.
    max_files = min(20, len(scored_files))
    top_file_paths = {ff["_path"] for ff, _ in scored_files[:max_files]}
    for c in candidates:
        if c.get("symbol_source") in ("pin", "agent_seed"):
            top_file_paths.add(c.get("path", ""))
    filtered_candidates = [c for c in candidates if c.get("path", "") in top_file_paths]
    # Cross-encoder scoring (adds ce_score to each candidate)
    filtered_candidates = _score_cross_encoder(filtered_candidates, task, db)
    # Def Ranking (Stage 2)
    ranker = load_ranker()
    ranker_features = extract_ranker_features(filtered_candidates, query_features)
    scores = ranker.score(ranker_features)
    scored = sorted(zip(filtered_candidates, scores, strict=True), key=lambda x: -x[1])
    # Cutoff
    cutoff = load_cutoff()
    ranked_for_cutoff = [{**c, "ranker_score": s} for c, s in scored]
    cutoff_features = extract_cutoff_features(
        ranked_for_cutoff, query_features, repo_features,
    )
    predicted_n = cutoff.predict(cutoff_features)
    # Build output
    return _build_output(
        scored, predicted_n,
        candidates=candidates, diagnostics=diagnostics,
        repo_root=repo_root, seeds=seeds, pins=pins,
        gate_label=gate_label.value, t0=t0,
        extra_metrics={"files_scored": len(file_features), "files_kept": len(top_file_paths),
                       "defs_ranked": len(filtered_candidates)},
    )

def _promote_via_coverage(
    pruned: list[dict[str, Any]],
    predicted_n: int,
    db: "Database | None",
) -> int:
    """If test defs made the elbow cut, promote their covered source defs.

    Looks at test defs in the top-N, queries test_coverage_facts for the
    source def_uids they cover, and if those source defs exist in `pruned`
    (survived file-prune but fell below the elbow), swaps them into the cut.

    Modifies `pruned` in-place (reorders) and returns the new predicted_n.
    """
    if db is None:
        return predicted_n

    top_n = pruned[:predicted_n]
    # Collect canonical test_ids from candidates in the cut.
    # Canonical format: "{file_path}::{dotted.lexical.path}"
    # This matches what parsers store after normalization at ingestion.
    test_ids: list[str] = []
    for c in top_n:
        if not (c.get("is_test") or c.get("path", "").startswith("tests/")):
            continue
        path = c.get("path", "")
        lp = c.get("lexical_path", "")
        if path and lp:
            test_ids.append(f"{path}::{lp}")
        if path and path not in test_ids:
            # Also include bare path for file-level attribution (PER_FILE_BATCH)
            test_ids.append(path)

    if not test_ids:
        return predicted_n

    # Deduplicate
    seen: set[str] = set()
    unique_ids: list[str] = []
    for tid in test_ids:
        if tid not in seen:
            seen.add(tid)
            unique_ids.append(tid)

    # Query coverage: test_id IN (...) → target_def_uids
    from sqlalchemy import text as sa_text
    placeholders = ",".join([f":p{i}" for i in range(len(unique_ids))])
    query = sa_text(
        f"SELECT DISTINCT target_def_uid FROM test_coverage_facts "
        f"WHERE test_id IN ({placeholders}) AND stale = 0"
    )
    params = {f"p{i}": tid for i, tid in enumerate(unique_ids)}
    with db.session() as session:
        rows = session.execute(query, params).fetchall()
    covered_uids = {row[0] for row in rows}

    if not covered_uids:
        return predicted_n

    # Find source defs in pruned (below the cut) that are covered
    below_cut = pruned[predicted_n:]
    already_in = {c["def_uid"] for c in top_n}
    to_promote = []
    for c in below_cut:
        uid = c.get("def_uid", "")
        if uid in covered_uids and uid not in already_in and not c.get("is_test"):
            to_promote.append(c)

    if not to_promote:
        return predicted_n

    # Reorder: insert promoted defs right after the current cut point
    for c in to_promote:
        pruned.remove(c)
    for i, c in enumerate(to_promote):
        pruned.insert(predicted_n + i, c)

    log.info(
        "ranking.coverage_promotion",
        tests_in_cut=len(unique_ids),
        promoted=len(to_promote),
    )
    return predicted_n + len(to_promote)


def _pipeline_heuristic(
    candidates: list[dict[str, Any]],
    diagnostics: dict[str, Any],
    *,
    repo_root: Path,
    seeds: list[str] | None,
    pins: list[str] | None,
    t0: float,
    db: "Database | None" = None,
) -> dict[str, Any]:
    """Heuristic path: RRF → file prune → rank by rrf_score → elbow."""
    from coderecon.ranking.elbow import elbow_cut
    from coderecon.ranking.rrf import rrf_file_prune, rrf_fuse_full

    # Stage 1: RRF fusion on all candidates (uses ce_score_tiny + structural signals)
    fused = rrf_fuse_full(candidates)

    # Stage 2: File-level prune (mirrors file_ranker in ML path)
    pinned_paths = set(pins) if pins else set()
    pruned = rrf_file_prune(fused, pinned_paths=pinned_paths)

    # Stage 3: Rank by rrf_score, elbow cutoff
    pruned.sort(key=lambda c: c["rrf_score"], reverse=True)
    rrf_scores = [c["rrf_score"] for c in pruned]
    # Knee window derived from the RRF k parameter: k controls the rank
    # decay radius (how quickly lower ranks lose influence). The knee of
    # the fused score curve lies within the first ~k/2 positions because
    # contributions from rank > k are negligible (1/(k+r) < 1/2k).
    from coderecon.ranking.rrf import RRF_K
    predicted_n = elbow_cut(rrf_scores, knee_window=RRF_K // 2)

    # Stage 4: Coverage promotion — if a test def made the cut,
    # auto-promote the source defs it covers (if they're in pruned).
    predicted_n = _promote_via_coverage(pruned, predicted_n, db)

    # Build (candidate, score) pairs for output builder
    scored = [(c, c["rrf_score"]) for c in pruned]
    return _build_output(
        scored, predicted_n,
        candidates=candidates, diagnostics=diagnostics,
        repo_root=repo_root, seeds=seeds, pins=pins,
        gate_label="OK", t0=t0,
        extra_metrics={"strategy": "rrf_full", "rank_lists": 17},
    )

def _build_output(
    scored: list[tuple[dict[str, Any], float]],
    predicted_n: int,
    *,
    candidates: list[dict[str, Any]],
    diagnostics: dict[str, Any],
    repo_root: Path,
    seeds: list[str] | None,
    pins: list[str] | None,
    gate_label: str,
    t0: float,
    extra_metrics: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the final output dict shared by both pipeline paths."""
    top_n = scored[:predicted_n]
    full_snippet_count = max(1, predicted_n // 2)
    result_candidates = []
    for idx, (c, s) in enumerate(top_n):
        loc = f"{c['kind']} {c['name']} {c['path']}:{c['start_line']}-{c['end_line']}"
        entry: dict[str, Any] = {
            "loc": loc,
            "score": round(s, 4),
        }
        if idx < full_snippet_count:
            snippet = _read_snippet(repo_root, c["path"], c["start_line"], c["end_line"])
            entry["snippet"] = snippet or ""
        else:
            sig = _read_signature(repo_root, c["path"], c["start_line"], c["end_line"])
            entry["sig"] = sig or ""
        result_candidates.append(entry)
    elapsed = round((time.monotonic() - t0) * MS_PER_SEC)
    metrics: dict[str, Any] = {
        "scored": len(candidates),
        "term": diagnostics.get("term_hits", 0),
        "lex": diagnostics.get("lex_hits", 0),
        "graph": diagnostics.get("graph_hits", 0),
        "sym": diagnostics.get("symbol_hits", 0),
        "ms": elapsed,
    }
    if extra_metrics:
        metrics.update(extra_metrics)
    hints = _build_hints(
        _build_query_metrics(diagnostics, scored, seeds, pins),
        gate_label,
    )[:3]
    return {
        "gate": gate_label,
        "results": result_candidates,
        "n": predicted_n,
        "metrics": metrics,
        "hints": hints,
    }

def register_tools(mcp: FastMCP, app_ctx: AppContext, *, dev_mode: bool = False) -> None:
    """Register recon tools with FastMCP server."""
    # Register raw signals endpoint only in dev mode (ranking training)
    if dev_mode:
        from coderecon.mcp.tools.recon.raw_signals import register_raw_signals_tool
        register_raw_signals_tool(mcp, app_ctx)
    @mcp.tool(
        annotations={
            "title": "Recon: task-aware context retrieval",
            "readOnlyHint": True,
            "openWorldHint": False,
        },
    )
    async def recon(
        ctx: Context,  # noqa: ARG001
        task: str = Field(
            description=(
                "Natural language description of the task. "
                "Be specific: include symbol names, file paths, "
                "or domain terms when known."
            ),
        ),
        seeds: list[str] = Field(
            default_factory=list,
            description=(
                "Symbol names to seed retrieval with "
                "(e.g., ['IndexCoordinatorEngine', 'FactQueries'])."
            ),
        ),
        pins: list[str] = Field(
            default_factory=list,
            description=(
                "File paths to pin as relevant "
                "(e.g., ['src/core/base_model.py'])."
            ),
        ),
    ) -> dict[str, Any]:
        """Task-aware context retrieval — returns ranked semantic spans with code.
        Pipeline: retrieve → gate → rank → cutoff → snippet extraction.
        Top half of results include full code snippets. Bottom half
        include signature + docstring only. Includes query metrics
        and actionable hints for improving retrieval.
        """
        recon_id = uuid.uuid4().hex[:12]
        result = await recon_pipeline(
            app_ctx, task,
            seeds=seeds or None,
            pins=pins or None,
        )
        gate = result["gate"]
        results = result["results"]
        metrics = result.get("metrics", {})
        hints = result.get("hints", [])
        response: dict[str, Any] = {
            "recon_id": recon_id,
            "gate": gate,
            "results": results,
            "metrics": metrics,
        }
        if gate == "OK" and results:
            # Extract unique file paths from loc strings
            paths = []
            for r in results[:8]:
                loc = r.get("loc", "")
                # loc format: "kind name path:start-end"
                parts = loc.rsplit(":", 1)
                if parts:
                    path = parts[0].rsplit(" ", 1)[-1] if " " in parts[0] else parts[0]
                    if path not in paths:
                        paths.append(path)
            n_full = sum(1 for r in results if "snippet" in r)
            n_sig = sum(1 for r in results if "sig" in r)
            hint = (
                f"{len(results)} spans ({n_full} full, {n_sig} sig-only) "
                f"in {', '.join(paths)}."
            )
            if hints:
                hint += " " + " ".join(hints[:2])
            response["hint"] = hint
        elif gate != "OK":
            gate_msg = {
                "UNSAT": "Wrong assumptions about this repo.",
                "BROAD": "Too broad — decompose.",
                "AMBIG": "Ambiguous — specify subsystem.",
            }
            hint = gate_msg.get(gate, "Retry.")
            if hints:
                hint += " " + hints[0]
            response["hint"] = hint
        from coderecon.mcp.delivery import wrap_response
        return wrap_response(
            response,
            resource_kind="recon_result",
            session_id=ctx.session_id,
        )
