"""recon_scout — single orientation tool for codebase understanding.

Supersedes recon_map, recon_understand, graph_cycles, graph_communities.
One call gives an agent complete structural context.

    from coderecon.mcp.tools.scout import register_tools, recon_scout_core
"""

from __future__ import annotations

from coderecon.mcp.tools.scout.core import recon_scout_core, register_tools

__all__ = ["recon_scout_core", "register_tools"]
