"""Agentic hint generation for recon_scout.

Produces a one-sentence context summary and optional structural warning.
Warnings fire only when a real trap exists that intersects the agent's
likely change path.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class ScoutHint:
    """Computed hint from recon_scout analysis."""

    context: str
    warning: str | None = None


def compute_hint(
    *,
    scope: str | None,
    total_files: int,
    coverage: dict[str, Any] | None,
    cycles: list[dict[str, Any]] | None,
    communities: list[dict[str, Any]] | None,
    top_files: list[dict[str, Any]] | None,
    fan_in: int = 0,
    fan_out: int = 0,
) -> ScoutHint:
    """Generate context and optional warning from scout results.

    Args:
        scope: The scope path prefix (None = repo-wide).
        total_files: Total file count in scope.
        coverage: Coverage dict or None.
        cycles: List of cycle dicts or None.
        communities: List of community dicts or None.
        top_files: List of top file dicts or None.
        fan_in: External files importing from scope (zoom mode only).
        fan_out: Scope files importing from outside (zoom mode only).

    Returns:
        ScoutHint with context and optional warning.
    """
    # Build context sentence
    context_parts: list[str] = []

    context_parts.append(f"{total_files} files")

    if cycles:
        total_cycle_nodes = sum(c.get("size", 0) for c in cycles)
        context_parts.append(f"{len(cycles)} cycle(s) ({total_cycle_nodes} nodes)")

    if coverage:
        rate = coverage.get("rate", 0)
        if rate > 0:
            context_parts.append(f"{rate:.0%} coverage")
        else:
            context_parts.append("no test coverage")

    if communities:
        context_parts.append(f"{len(communities)} communities")

    if scope and fan_in > 0:
        context_parts.append(f"{fan_in} external importers")

    if scope and fan_out > 0:
        context_parts.append(f"{fan_out} external imports")

    context = ", ".join(context_parts)

    # Determine warning (only real traps)
    warning = _compute_warning(
        scope=scope,
        total_files=total_files,
        coverage=coverage,
        cycles=cycles,
        top_files=top_files,
        fan_in=fan_in,
    )

    return ScoutHint(context=context, warning=warning)


def _compute_warning(
    *,
    scope: str | None,
    total_files: int,
    coverage: dict[str, Any] | None,
    cycles: list[dict[str, Any]] | None,
    top_files: list[dict[str, Any]] | None,
    fan_in: int,
) -> str | None:
    """Emit a warning only when all three conditions hold:

    1. A structural trap exists
    2. It intersects the agent's likely change path
    3. Cost of not investigating > cost of one extra tool call

    Only one warning is emitted (highest severity).
    """
    # Trap 1: Circular dependency in scope
    if cycles:
        largest = max(cycles, key=lambda c: c.get("size", 0))
        nodes = largest.get("nodes", [])
        if len(nodes) >= 2:
            # Show first two nodes of the largest cycle
            a, b = nodes[0], nodes[1]
            suffix = f" and {len(nodes) - 2} others" if len(nodes) > 2 else ""
            return f"{a} ↔ {b}{suffix} form a cycle — changes to one may require changes to the others"

    # Trap 2: High fan-in on a scoped module (interface breakage risk)
    if scope and fan_in > total_files:
        # More external consumers than internal files = high-traffic interface
        return (
            f"scope is imported by {fan_in} files outside — "
            f"interface changes will break them silently"
        )

    # Trap 3: Zero test coverage
    if coverage and coverage.get("total", 0) > 0 and coverage.get("covered", 0) == 0:
        return "no tests cover this scope — checkpoint will pass regardless of correctness"

    return None
