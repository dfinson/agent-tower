"""Progressive tree compression for recon_scout.

Compresses a directory tree to fit within a byte budget through
progressively coarser rendering phases.  Every phase produces a valid,
complete tree — no hard truncation.

Thresholds derive from:
- budget: MCP protocol inline byte cap (external constraint)
- Population statistics: avg_density, median PageRank, actual_max_depth
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


@dataclass(slots=True)
class _TreeNode:
    """Internal trie node for building the output tree."""

    name: str
    children: dict[str, _TreeNode] = field(default_factory=dict)
    files: list[tuple[str, int | None]] = field(default_factory=list)  # (filename, line_count)
    total_lines: int = 0
    total_files: int = 0


def compress_tree(
    all_paths: list[tuple[str, int | None]],
    budget: int,
    *,
    file_pageranks: dict[str, float] | None = None,
) -> tuple[str, list[str] | None]:
    """Compress directory tree to fit within budget bytes.

    Args:
        all_paths: (relative_path, line_count) for every file in scope.
        budget: Maximum byte size for the rendered tree string.
        file_pageranks: Optional {path: pagerank_score} for pruning.

    Returns:
        (rendered_tree_string, zoom_targets_or_None)
        zoom_targets is a list of dir paths that were collapsed (only
        present when Phase 2+ was needed).
    """
    if not all_paths:
        return "(empty)", None

    root = _build_trie(all_paths)
    _propagate_counts(root)

    # Phase 1: Full hybrid tree
    output = _render_full(root)
    if len(output.encode()) <= budget:
        return output, None

    # Population statistics for subsequent phases
    dir_count = _count_dirs(root)
    total_files = len(all_paths)
    avg_density = total_files / dir_count if dir_count > 0 else total_files

    # Phase 2: Sibling aggregation — collapse dense dirs
    output, zoom_targets = _render_aggregated(root, avg_density)
    if len(output.encode()) <= budget:
        return output, zoom_targets if zoom_targets else None

    # Phase 3: PageRank-weighted pruning
    if file_pageranks:
        scores = list(file_pageranks.values())
        if scores:
            median_pr = statistics.median(scores)
            output, pruned_targets = _render_pruned(root, file_pageranks, median_pr)
            zoom_targets = list(set((zoom_targets or []) + pruned_targets))
            if len(output.encode()) <= budget:
                return output, zoom_targets if zoom_targets else None

    # Phase 4: Dirs-only with progressive depth reduction
    max_depth = _max_depth(root)
    for d in range(max_depth, 0, -1):
        output = _render_dirs_only(root, max_depth=d)
        if len(output.encode()) <= budget:
            return output, zoom_targets if zoom_targets else None

    # Phase 5: Top-level skeleton (guaranteed floor)
    output = _render_top_level(root)
    return output, zoom_targets if zoom_targets else None


def _build_trie(all_paths: list[tuple[str, int | None]]) -> _TreeNode:
    """Build a trie from flat path list."""
    root = _TreeNode(name=".")
    for path, lc in all_paths:
        parts = path.split("/")
        if len(parts) == 1:
            root.files.append((path, lc))
        else:
            node = root
            for p in parts[:-1]:
                if p not in node.children:
                    node.children[p] = _TreeNode(name=p)
                node = node.children[p]
            node.files.append((parts[-1], lc))
    return root


def _propagate_counts(node: _TreeNode) -> None:
    """Propagate total_files and total_lines up the tree."""
    node.total_files = len(node.files)
    node.total_lines = sum(lc or 0 for _, lc in node.files)
    for child in node.children.values():
        _propagate_counts(child)
        node.total_files += child.total_files
        node.total_lines += child.total_lines


def _count_dirs(node: _TreeNode) -> int:
    """Count non-leaf directories (dirs that have children or files)."""
    count = 1 if (node.children or node.files) else 0
    for child in node.children.values():
        count += _count_dirs(child)
    return count


def _max_depth(node: _TreeNode, current: int = 0) -> int:
    """Compute maximum tree depth."""
    if not node.children:
        return current
    return max(_max_depth(c, current + 1) for c in node.children.values())


def _collapse_chain(name: str, node: _TreeNode) -> tuple[str, _TreeNode]:
    """Collapse single-child chains: a/b/c/ → a/b/c/."""
    chain = [name]
    n = node
    while len(n.children) == 1 and not n.files:
        only_name = next(iter(n.children))
        chain.append(only_name)
        n = n.children[only_name]
    return "/".join(chain), n


# --- Phase 1: Full hybrid tree ---

def _render_full(root: _TreeNode) -> str:
    """Render complete tree with all files and line counts."""
    lines = ["# files without :N have unknown line count"]
    lines.extend(_render_node_full(root, indent=0, is_root=True))
    return "\n".join(lines)


def _render_node_full(node: _TreeNode, indent: int, is_root: bool = False) -> list[str]:
    """Recursively render a node with all its files."""
    result: list[str] = []
    prefix = "  " * indent

    for name in sorted(node.children):
        child = node.children[name]
        label, collapsed = _collapse_chain(name, child)
        dir_label = f"{prefix}{label}/"

        if collapsed.files:
            file_strs = _format_files(collapsed.files)
            result.append(f"{dir_label} {' | '.join(file_strs)}")
        else:
            result.append(dir_label)
        result.extend(_render_node_full(collapsed, indent + 1))

    # Root-level files
    if is_root and node.files:
        file_strs = _format_files(node.files)
        result.append(" | ".join(file_strs))

    return result


def _format_files(files: list[tuple[str, int | None]]) -> list[str]:
    """Format file list as name:linecount strings."""
    return [f"{name}:{lc}" if lc else name for name, lc in sorted(files)]


# --- Phase 2: Sibling aggregation ---

def _render_aggregated(
    root: _TreeNode, avg_density: float
) -> tuple[str, list[str]]:
    """Aggregate dirs with more files than avg_density."""
    import math

    show_count = max(1, math.ceil(avg_density))
    zoom_targets: list[str] = []
    lines = ["# files without :N have unknown line count"]
    lines.extend(
        _render_node_aggregated(root, indent=0, is_root=True, show_count=show_count,
                                 zoom_targets=zoom_targets, path_prefix="")
    )
    return "\n".join(lines), zoom_targets


def _render_node_aggregated(
    node: _TreeNode,
    indent: int,
    is_root: bool,
    show_count: int,
    zoom_targets: list[str],
    path_prefix: str,
) -> list[str]:
    """Render with sibling aggregation for dense dirs."""
    result: list[str] = []
    prefix = "  " * indent

    for name in sorted(node.children):
        child = node.children[name]
        label, collapsed = _collapse_chain(name, child)
        dir_path = f"{path_prefix}{label}" if path_prefix else label
        dir_label = f"{prefix}{label}/"

        if len(collapsed.files) > show_count:
            # Aggregate: show top files by line_count, summarize rest
            sorted_files = sorted(collapsed.files, key=lambda f: f[1] or 0, reverse=True)
            shown = sorted_files[:show_count]
            remaining = len(sorted_files) - show_count
            remaining_lines = sum(lc or 0 for _, lc in sorted_files[show_count:])

            file_strs = _format_files(shown)
            agg = f"… (+{remaining} more, {remaining_lines} lines)"
            result.append(f"{dir_label} {' | '.join(file_strs)} | {agg}")
            zoom_targets.append(dir_path + "/")
        elif collapsed.files:
            file_strs = _format_files(collapsed.files)
            result.append(f"{dir_label} {' | '.join(file_strs)}")
        else:
            result.append(dir_label)

        result.extend(
            _render_node_aggregated(
                collapsed, indent + 1, is_root=False, show_count=show_count,
                zoom_targets=zoom_targets, path_prefix=dir_path + "/",
            )
        )

    # Root-level files
    if is_root and node.files:
        if len(node.files) > show_count:
            sorted_files = sorted(node.files, key=lambda f: f[1] or 0, reverse=True)
            shown = sorted_files[:show_count]
            remaining = len(sorted_files) - show_count
            remaining_lines = sum(lc or 0 for _, lc in sorted_files[show_count:])
            file_strs = _format_files(shown)
            result.append(f"{' | '.join(file_strs)} | … (+{remaining} more, {remaining_lines} lines)")
        else:
            file_strs = _format_files(node.files)
            result.append(" | ".join(file_strs))

    return result


# --- Phase 3: PageRank-weighted pruning ---

def _render_pruned(
    root: _TreeNode,
    file_pageranks: dict[str, float],
    median_pr: float,
) -> tuple[str, list[str]]:
    """Collapse dirs where no file exceeds median PageRank."""
    zoom_targets: list[str] = []
    lines = ["# files without :N have unknown line count"]
    lines.extend(
        _render_node_pruned(root, indent=0, is_root=True, file_pageranks=file_pageranks,
                            median_pr=median_pr, zoom_targets=zoom_targets, path_prefix="")
    )
    return "\n".join(lines), zoom_targets


def _render_node_pruned(
    node: _TreeNode,
    indent: int,
    is_root: bool,
    file_pageranks: dict[str, float],
    median_pr: float,
    zoom_targets: list[str],
    path_prefix: str,
) -> list[str]:
    """Render with PageRank-based pruning."""
    result: list[str] = []
    prefix = "  " * indent

    for name in sorted(node.children):
        child = node.children[name]
        label, collapsed = _collapse_chain(name, child)
        dir_path = f"{path_prefix}{label}" if path_prefix else label

        # Check if any file in this subtree is above median PR
        has_important_file = _has_file_above_pr(collapsed, dir_path + "/", file_pageranks, median_pr)

        if not has_important_file and collapsed.total_files > 0:
            # Collapse entire dir to summary
            result.append(
                f"{prefix}{label}/ ({collapsed.total_files} files, {collapsed.total_lines} lines)"
            )
            zoom_targets.append(dir_path + "/")
        else:
            # Render normally but still prune individual files below median
            dir_label = f"{prefix}{label}/"
            if collapsed.files:
                important_files = [
                    (fname, lc) for fname, lc in collapsed.files
                    if file_pageranks.get(f"{dir_path}/{fname}", 0) >= median_pr
                ]
                other_count = len(collapsed.files) - len(important_files)
                other_lines = sum(
                    lc or 0 for fname, lc in collapsed.files
                    if file_pageranks.get(f"{dir_path}/{fname}", 0) < median_pr
                )
                if important_files:
                    file_strs = _format_files(important_files)
                    if other_count > 0:
                        result.append(
                            f"{dir_label} {' | '.join(file_strs)} | … (+{other_count}, {other_lines} lines)"
                        )
                    else:
                        result.append(f"{dir_label} {' | '.join(file_strs)}")
                elif other_count > 0:
                    result.append(f"{dir_label} ({other_count} files, {other_lines} lines)")
                else:
                    result.append(dir_label)
            else:
                result.append(dir_label)

            result.extend(
                _render_node_pruned(
                    collapsed, indent + 1, is_root=False, file_pageranks=file_pageranks,
                    median_pr=median_pr, zoom_targets=zoom_targets, path_prefix=dir_path + "/",
                )
            )

    # Root-level files
    if is_root and node.files:
        important = [(f, lc) for f, lc in node.files if file_pageranks.get(f, 0) >= median_pr]
        others = len(node.files) - len(important)
        if important:
            file_strs = _format_files(important)
            if others:
                result.append(f"{' | '.join(file_strs)} | … (+{others} more)")
            else:
                result.append(" | ".join(file_strs))
        elif others:
            result.append(f"({others} root files)")

    return result


def _has_file_above_pr(
    node: _TreeNode,
    path_prefix: str,
    file_pageranks: dict[str, float],
    median_pr: float,
) -> bool:
    """Check if any file in this subtree has PageRank above median."""
    for fname, _ in node.files:
        full_path = f"{path_prefix}{fname}"
        if file_pageranks.get(full_path, 0) >= median_pr:
            return True
    for name, child in node.children.items():
        if _has_file_above_pr(child, f"{path_prefix}{name}/", file_pageranks, median_pr):
            return True
    return False


# --- Phase 4: Dirs-only with depth reduction ---

def _render_dirs_only(root: _TreeNode, max_depth: int) -> str:
    """Render only directories with file counts, up to max_depth."""
    lines: list[str] = []
    _render_dirs_recursive(root, indent=0, current_depth=0, max_depth=max_depth, lines=lines)
    return "\n".join(lines)


def _render_dirs_recursive(
    node: _TreeNode, indent: int, current_depth: int, max_depth: int, lines: list[str]
) -> None:
    """Recursively render dirs only."""
    prefix = "  " * indent
    for name in sorted(node.children):
        child = node.children[name]
        label, collapsed = _collapse_chain(name, child)

        if current_depth >= max_depth:
            # Summarize everything below
            lines.append(f"{prefix}{label}/ ({collapsed.total_files} files, {collapsed.total_lines} lines)")
        else:
            lines.append(f"{prefix}{label}/ ({collapsed.total_files} files)")
            _render_dirs_recursive(
                collapsed, indent + 1, current_depth + 1, max_depth, lines
            )

    # Root-level file count
    if indent == 0 and node.files:
        total_root_lines = sum(lc or 0 for _, lc in node.files)
        lines.append(f"({len(node.files)} root files, {total_root_lines} lines)")


# --- Phase 5: Top-level skeleton ---

def _render_top_level(root: _TreeNode) -> str:
    """Render only top-level entries with aggregate stats."""
    lines: list[str] = []
    for name in sorted(root.children):
        child = root.children[name]
        lines.append(f"{name}/ ({child.total_files} files, {child.total_lines} lines)")
    if root.files:
        total_root_lines = sum(lc or 0 for _, lc in root.files)
        lines.append(f"({len(root.files)} root files, {total_root_lines} lines)")
    return "\n".join(lines)
