"""recon_scout core — orientation tool implementation.

Gathers structure, graph analysis, and health signals for a scope
(or repo-wide) and returns a complete briefing with progressive
tree compression and agentic hints.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import structlog
from fastmcp import Context
from pydantic import Field

from coderecon.config.constants import INLINE_CAP_BYTES

if TYPE_CHECKING:
    from fastmcp import FastMCP
    from sqlalchemy.engine import Engine

    from coderecon.mcp.context import AppContext

log = structlog.get_logger(__name__)


async def recon_scout_core(
    app_ctx: AppContext,
    *,
    scope: str | None = None,
) -> dict[str, Any]:
    """Full codebase orientation (transport-agnostic).

    Args:
        app_ctx: Application context with coordinator, db, etc.
        scope: Optional path prefix to zoom into a subtree.

    Returns:
        Complete scout response dict.
    """
    engine = app_ctx.coordinator.db.engine
    worktree_id = app_ctx.coordinator.get_worktree_id(app_ctx.worktree_name)

    # Gather all sections
    result: dict[str, Any] = {}

    # --- Structure (tree, languages, entry_points, test_layout) ---
    tree_text, zoom_targets, all_paths = await _gather_structure(app_ctx, worktree_id, scope, result)
    result["tree"] = tree_text
    if zoom_targets:
        result["zoom_targets"] = zoom_targets

    # --- Graph analysis (scoped) ---
    graph_sections, fan_in, fan_out = _gather_graph_analysis(engine, worktree_id, scope)
    result.update(graph_sections)

    # --- Health signals ---
    health = _gather_health(engine, worktree_id, scope)
    result.update(health)

    # --- Agentic hint ---
    from coderecon.mcp.tools.scout.hints import compute_hint

    hint = compute_hint(
        scope=scope,
        total_files=len(all_paths),
        coverage=result.get("coverage"),
        cycles=result.get("cycles"),
        communities=result.get("communities"),
        top_files=result.get("top_files"),
        fan_in=fan_in,
        fan_out=fan_out,
    )
    result["context"] = hint.context
    if hint.warning:
        result["warning"] = hint.warning

    from coderecon.mcp.delivery import wrap_response

    return wrap_response(result, resource_kind="scout")


async def _gather_structure(
    app_ctx: AppContext,
    worktree_id: int,
    scope: str | None,
    result: dict[str, Any],
) -> tuple[str, list[str] | None, list[tuple[str, int | None]]]:
    """Gather tree, languages, entry_points, test_layout.

    Populates languages/entry_points/test_layout directly into result dict.
    Returns (tree_text, zoom_targets, all_paths).
    """
    from coderecon.mcp.tools.scout.tree_compression import compress_tree

    include_globs = [f"{scope}/**"] if scope else None

    map_result = await app_ctx.coordinator.map_repo(
        include=["structure", "languages", "entry_points", "test_layout"],
        depth=99,  # No artificial depth limit — compression handles sizing
        limit=10000,  # No artificial limit — population is what it is
        include_globs=include_globs,
    )

    all_paths: list[tuple[str, int | None]] = []
    if map_result.structure and map_result.structure.all_paths:
        all_paths = map_result.structure.all_paths

    # Extract languages, entry_points, test_layout from same map call
    if map_result.languages:
        result["languages"] = [
            f"{lang.language} {lang.percentage:.1f}% ({lang.file_count} files)"
            for lang in map_result.languages
        ]

    if map_result.entry_points:
        result["entry_points"] = [
            {"path": ep.path, "name": ep.name, "kind": ep.kind}
            for ep in map_result.entry_points
        ]

    if map_result.test_layout:
        tl = map_result.test_layout
        result["test_layout"] = f"{tl.test_count} test files"

    # Get file PageRanks for compression (if available)
    file_pageranks: dict[str, float] | None = None
    try:
        from coderecon.index.analysis.code_graph import build_file_graph

        engine = app_ctx.coordinator.db.engine
        fg = build_file_graph(engine, worktree_id=worktree_id)
        if fg.number_of_nodes() > 0:
            import networkx as nx

            scores = nx.pagerank(fg, alpha=0.85, max_iter=100, tol=1e-06)
            if scope:
                file_pageranks = {p: s for p, s in scores.items() if p.startswith(scope)}
            else:
                file_pageranks = dict(scores)
    except (ImportError, OSError, ValueError):
        log.debug("scout.pagerank_for_compression.skipped", exc_info=True)

    # Budget for tree: total MCP budget minus space needed for other sections.
    # Other sections are population-bounded and fit predictably.
    # Use half of total budget as floor to guarantee tree gets reasonable space.
    non_tree_estimate = 5000
    tree_budget = max(INLINE_CAP_BYTES - non_tree_estimate, INLINE_CAP_BYTES // 2)

    tree_text, zoom_targets = compress_tree(
        all_paths, tree_budget, file_pageranks=file_pageranks,
    )

    return tree_text, zoom_targets, all_paths


def _gather_graph_analysis(
    engine: Engine,
    worktree_id: int,
    scope: str | None,
) -> tuple[dict[str, Any], int, int]:
    """Run graph analysis (optionally scoped).

    Returns (sections_dict, fan_in_count, fan_out_count).
    """
    import networkx as nx

    from coderecon.index.analysis.code_graph import (
        build_def_graph,
        build_file_graph,
        detect_communities,
        detect_cycles,
    )

    sections: dict[str, Any] = {}
    fan_in = 0
    fan_out = 0

    try:
        fg = build_file_graph(engine, worktree_id=worktree_id)

        if scope:
            # Scope the graph: keep only nodes within scope
            scope_nodes = {n for n in fg.nodes() if n.startswith(scope)}

            if scope_nodes:
                # Compute fan-in/fan-out before subgraphing
                for node in scope_nodes:
                    for pred in fg.predecessors(node):
                        if pred not in scope_nodes:
                            fan_in += 1
                    for succ in fg.successors(node):
                        if succ not in scope_nodes:
                            fan_out += 1

                fg_scoped = fg.subgraph(scope_nodes).copy()
            else:
                fg_scoped = nx.DiGraph()
        else:
            fg_scoped = fg

        if fg_scoped.number_of_nodes() > 0:
            # PageRank on scoped file graph
            file_pr = nx.pagerank(fg_scoped, alpha=0.85, max_iter=100, tol=1e-06)
            if file_pr:
                import statistics

                scores = list(file_pr.values())
                median = statistics.median(scores)
                top = [
                    (path, score) for path, score in file_pr.items()
                    if score >= median
                ]
                top.sort(key=lambda x: x[1], reverse=True)
                # Cap to top 10 — enough for orientation without bloating response
                sections["top_files"] = [
                    {"file": path, "pagerank": round(score, 6)}
                    for path, score in top[:10]
                ]

            # Cycles on scoped graph
            cycles = detect_cycles(fg_scoped)
            if cycles:
                sections["cycles"] = [
                    {"size": c.size, "nodes": sorted(c.nodes)}
                    for c in cycles
                ]

            # Communities on scoped graph
            communities = detect_communities(fg_scoped)
            if communities:
                sections["communities"] = [
                    {
                        "id": c.community_id,
                        "size": c.size,
                        "representative": c.representative,
                        "members": c.members[:20],
                    }
                    for c in communities[:10]
                ]
    except (ImportError, OSError, ValueError):
        log.warning("scout.file_graph.failed", exc_info=True)

    # Def-level PageRank (top symbols)
    try:
        dg = build_def_graph(engine, worktree_id=worktree_id)

        if scope:
            scope_def_nodes = {
                n for n in dg.nodes()
                if dg.nodes[n].get("file_path", "").startswith(scope)
            }
            dg_scoped = dg.subgraph(scope_def_nodes).copy() if scope_def_nodes else nx.DiGraph()
        else:
            dg_scoped = dg

        if dg_scoped.number_of_nodes() > 0:
            def_pr = nx.pagerank(dg_scoped, alpha=0.85, max_iter=100, tol=1e-06)
            if def_pr:
                import statistics

                scores = list(def_pr.values())
                median = statistics.median(scores)
                top = [
                    (node_id, score) for node_id, score in def_pr.items()
                    if score >= median
                ]
                top.sort(key=lambda x: x[1], reverse=True)
                # Cap to top 15 — enough for orientation without bloating response
                sections["top_symbols"] = [
                    {
                        "name": dg_scoped.nodes[nid].get("name", nid),
                        "file": dg_scoped.nodes[nid].get("file_path", ""),
                        "kind": dg_scoped.nodes[nid].get("kind", "unknown"),
                        "pagerank": round(score, 6),
                    }
                    for nid, score in top[:15]
                ]
    except (ImportError, OSError, ValueError):
        log.warning("scout.def_graph.failed", exc_info=True)

    return sections, fan_in, fan_out


def _gather_health(engine: Engine, worktree_id: int, scope: str | None) -> dict[str, Any]:
    """Gather coverage and lint health signals."""
    sections: dict[str, Any] = {}

    # Coverage
    try:
        from coderecon.index.analysis.coverage_ingestion import get_coverage_summary

        cov = get_coverage_summary(engine, worktree_id=worktree_id)
        if cov.get("total_defs", 0) > 0:
            sections["coverage"] = {
                "rate": cov["coverage_rate"],
                "covered": cov["defs_covered"],
                "total": cov["total_defs"],
            }
    except (ImportError, OSError, ValueError):
        log.debug("scout.coverage.skipped", exc_info=True)

    # Lint
    try:
        from coderecon.index.analysis.lint_status import get_lint_summary

        lint = get_lint_summary(engine, worktree_id=worktree_id)
        if lint.get("files_checked", 0) > 0:
            sections["lint"] = {
                "clean_files": lint["clean_files"],
                "total_errors": lint["total_errors"],
                "files_checked": lint["files_checked"],
            }
    except (ImportError, OSError, ValueError):
        log.debug("scout.lint.skipped", exc_info=True)

    return sections


def register_tools(mcp: FastMCP, app_ctx: AppContext) -> None:
    """Register recon_scout MCP tool."""

    @mcp.tool(
        annotations={
            "title": "Scout: codebase orientation",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def recon_scout(
        ctx: Context,  # noqa: ARG001
        scope: str | None = Field(
            default=None,
            description=(
                "Path prefix to zoom into a subtree "
                "(e.g. 'src/coderecon/mcp'). Omit for repo-wide briefing."
            ),
        ),
    ) -> dict[str, Any]:
        """Codebase orientation — structure, graph analysis, health signals.

        Returns tree (progressively compressed to fit budget), PageRank-ranked
        symbols and files, Louvain communities, Tarjan cycles, test coverage,
        lint health, and an agentic hint.

        Use scope to zoom into a subtree for focused analysis.
        """
        return await recon_scout_core(app_ctx, scope=scope)
