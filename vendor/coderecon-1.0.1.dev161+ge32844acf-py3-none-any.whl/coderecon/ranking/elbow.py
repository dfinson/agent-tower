"""Kneedle-based cutoff — model-free N prediction.

Finds the knee point of a descending score curve using maximum
perpendicular distance from the endpoint-to-endpoint line.
Used as a fallback when the LightGBM cutoff model is unavailable.
"""

from __future__ import annotations


def elbow_cut(scores: list[float], *, min_n: int = 3, knee_window: int | None = None) -> int:
    """Return the cutoff position in a descending score list.

    Combines two principled methods:

    1. **Kneedle** — finds the knee (point of maximum perpendicular
       distance from the endpoint line) within the *knee_window*.
    2. **Geometric extension** — extends past the knee to include all
       items whose score is above a threshold derived from the curve's
       own decay rate: ``threshold = score[knee]² / score[0]``.
       This is the geometric continuation of the head→knee decay applied
       once more, using only values intrinsic to the score distribution.
       The extension scans the *full* score list, not just the window.

    Parameters
    ----------
    scores
        Scores in descending order (e.g. RRF scores after sorting).
    min_n
        Hard lower bound on the returned cutoff.
    knee_window
        Maximum number of leading scores to consider when locating the
        knee.  Keeps the Kneedle line-fit accurate by excluding the long
        smooth tail.  When *None*, uses the full list.  Callers should
        pass a value derived from a real structural constraint (e.g. the
        number of files after file-level pruning).
    """
    n = len(scores)
    if n <= min_n:
        return n

    # Knee detection window — bounded for algorithmic accuracy
    upper = min(knee_window, n) if knee_window is not None else n

    window = scores[:upper]

    # Flat or single-value → return all within window
    if window[0] == window[-1]:
        return upper

    # Perpendicular distance from line (0, window[0]) → (upper-1, window[-1])
    rise = window[-1] - window[0]  # negative for descending
    run = upper - 1
    dists = [
        abs(rise * i - run * (window[i] - window[0]))
        for i in range(upper)
    ]
    knee = max(range(upper), key=lambda i: dists[i])

    # Geometric extension: the ratio score[knee]/score[0] captures how much
    # the curve decayed to reach the knee. Apply that same ratio once more
    # to get the threshold below which items are truly in the tail.
    # threshold = score[knee]^2 / score[0]
    knee_score = window[knee]
    top_score = window[0]
    threshold = (knee_score * knee_score) / top_score

    # Extend past knee — scan the FULL score list (not just the window)
    cut = knee + 1
    while cut < n and scores[cut] >= threshold:
        cut += 1

    return max(min_n, cut)
