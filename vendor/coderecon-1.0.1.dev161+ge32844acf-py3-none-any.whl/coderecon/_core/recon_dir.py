"""Ensure the ``.recon/`` directory exists with a proper ``.gitignore``."""
from __future__ import annotations

from pathlib import Path

_GITIGNORE_CONTENT = (
    "# Ignore everything except user config files\n"
    "*\n"
    "!.gitignore\n"
    "!config.yaml\n"
    "# state.yaml is auto-generated, do not commit\n"
)


def ensure_recon_dir(repo_root: Path) -> Path:
    """Create ``.recon/`` under *repo_root* and guarantee a ``.gitignore`` exists.

    Safe to call repeatedly — the directory and gitignore are only
    created when missing.  This must be used instead of bare
    ``(repo_root / ".recon").mkdir()`` so that the ``.gitignore`` is
    always present before any other files land in the directory.

    Returns the ``.recon/`` path.
    """
    recon_dir = repo_root / ".recon"
    recon_dir.mkdir(exist_ok=True)
    gitignore_path = recon_dir / ".gitignore"
    if not gitignore_path.exists():
        gitignore_path.write_text(_GITIGNORE_CONTENT, encoding="utf-8")
    return recon_dir
