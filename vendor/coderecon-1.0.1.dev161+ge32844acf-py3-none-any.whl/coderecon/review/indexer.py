"""Structural-only indexing for the lite review SDK.

Composes existing primitives (StructuralIndexer, Database, resolution passes)
without pulling in Tantivy, SPLADE, SCIP, or the daemon layer.
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import TYPE_CHECKING

import structlog
from sqlmodel import select

from coderecon._core.languages import detect_language_family
from coderecon.index.db import Database, create_additional_indexes
from coderecon.index.discovery import (
    ContextDiscovery,
    ContextProbe,
    MembershipResolver,
    Tier1AuthorityFilter,
)
from coderecon.index.discovery.ignore import IgnoreChecker
from coderecon.index.models import (
    CandidateContext,
    Context,
    ContextMarker,
    ProbeStatus,
    Worktree,
)
from coderecon.index.parsing.service import tree_sitter_service
from coderecon.index.structural.structural import StructuralIndexer

if TYPE_CHECKING:
    from collections.abc import Callable

log = structlog.get_logger(__name__)


def init_review_db(
    repo_root: Path,
    db_path: Path,
    *,
    worktree_name: str = "main",
) -> tuple[Database, StructuralIndexer]:
    """Create the DB and discover contexts (no Tantivy/SPLADE/SCIP).

    Returns (db, structural_indexer) ready for indexing.
    """
    db = Database(db_path)
    db.create_all()
    create_additional_indexes(db.engine)

    # Register main worktree
    _get_or_create_worktree(db, worktree_name, str(repo_root))

    # Context discovery (lightweight filesystem scan)
    discovery = ContextDiscovery(repo_root)
    discovery_result = discovery.discover_all()
    all_candidates = discovery_result.candidates
    root_fallback = next(
        (c for c in all_candidates if getattr(c, "is_root_fallback", False)),
        None,
    )
    regular_candidates = [
        c for c in all_candidates if not getattr(c, "is_root_fallback", False)
    ]

    # Authority filter
    authority = Tier1AuthorityFilter(repo_root)
    authority_result = authority.apply(regular_candidates)

    # Membership resolution
    membership = MembershipResolver()
    membership_result = membership.resolve(authority_result.pending)

    # Probe contexts
    parser = tree_sitter_service.parser
    probe = ContextProbe(repo_root, parser=parser)
    probed: list[CandidateContext] = []
    for candidate in membership_result.contexts:
        probe_result = probe.validate(candidate)
        if probe_result.valid:
            candidate.probe_status = ProbeStatus.VALID
        elif probe_result.reason and "empty" in probe_result.reason.lower():
            candidate.probe_status = ProbeStatus.EMPTY
        else:
            candidate.probe_status = ProbeStatus.FAILED
        probed.append(candidate)
    if root_fallback is not None:
        probed.append(root_fallback)

    # Persist contexts
    import json as _json

    with db.session() as session:
        for candidate in probed:
            if getattr(candidate, "is_root_fallback", False):
                name = "_root"
            else:
                name = candidate.root_path or "root"
            context = Context(
                name=name,
                language_family=candidate.language_family.value,
                root_path=candidate.root_path,
                tier=candidate.tier,
                probe_status=candidate.probe_status.value,
                include_spec=_json.dumps(candidate.include_spec)
                if candidate.include_spec
                else None,
                exclude_spec=_json.dumps(candidate.exclude_spec)
                if candidate.exclude_spec
                else None,
            )
            session.add(context)
            session.flush()
            for marker_path in candidate.markers:
                marker = ContextMarker(
                    context_id=context.id,
                    marker_path=marker_path,
                    marker_tier="tier1" if candidate.tier == 1 else "tier2",
                    detected_at=time.time(),
                )
                session.add(marker)
        for candidate in authority_result.detached:
            context = Context(
                name=candidate.root_path or "root",
                language_family=candidate.language_family.value,
                root_path=candidate.root_path,
                tier=candidate.tier,
                probe_status=ProbeStatus.DETACHED.value,
            )
            session.add(context)
        session.commit()

    structural = StructuralIndexer(db, repo_root)
    return db, structural


def index_structural(
    db: Database,
    structural: StructuralIndexer,
    repo_root: Path,
    *,
    worktree_name: str = "main",
    worktree_root: Path | None = None,
    on_progress: Callable[[int, int], None] | None = None,
) -> int:
    """Run structural-only indexing (Pass 1) + import/reference resolution.

    Returns the number of files indexed.
    """
    from coderecon.index.ops_glob import _compile_glob_set

    effective_root = worktree_root or repo_root
    wt_id = _get_or_create_worktree(db, worktree_name, str(effective_root))
    is_main = worktree_name == "main"

    # Get valid contexts
    with db.session() as session:
        contexts = list(
            session.exec(
                select(Context).where(Context.probe_status == ProbeStatus.VALID.value)
            ).all()
        )

    # Walk filesystem
    ignore_checker = IgnoreChecker(repo_root)
    all_files = _walk_files(effective_root, ignore_checker)

    # Match files to contexts
    specific_contexts = [c for c in contexts if c.tier != 3]
    root_context = next((c for c in contexts if c.tier == 3), None)

    files_to_index: list[tuple[str, int]] = []  # (rel_path, context_id)
    claimed: set[str] = set()

    for context in specific_contexts:
        context_root = effective_root / context.root_path if context.root_path else effective_root
        include_globs = context.get_include_globs()
        exclude_globs = context.get_exclude_globs()
        include_compiled = _compile_glob_set(include_globs) if include_globs else None
        exclude_compiled = _compile_glob_set(exclude_globs) if exclude_globs else None
        ctx_id = context.id or 0

        for file_path in all_files:
            rel = str(file_path.relative_to(effective_root))
            if rel in claimed:
                continue
            # Check if file belongs to this context
            if context.root_path and not rel.startswith(context.root_path):
                continue
            if include_compiled and not include_compiled.search(rel):
                continue
            if exclude_compiled and exclude_compiled.search(rel):
                continue
            claimed.add(rel)
            files_to_index.append((rel, ctx_id))

    # Root fallback for unclaimed
    if root_context is not None:
        root_ctx_id = root_context.id or 0
        for file_path in all_files:
            rel = str(file_path.relative_to(effective_root))
            if rel not in claimed:
                claimed.add(rel)
                files_to_index.append((rel, root_ctx_id))

    # Index in batches
    total = len(files_to_index)
    workers = min(os.cpu_count() or 4, 16)
    count = 0

    # Group by context
    by_context: dict[int, list[str]] = {}
    for rel, ctx_id in files_to_index:
        by_context.setdefault(ctx_id, []).append(rel)

    for ctx_id, paths in by_context.items():
        batch_size = 50
        for i in range(0, len(paths), batch_size):
            batch = paths[i : i + batch_size]
            structural.index_files(
                batch,
                ctx_id,
                worktree_id=wt_id,
                is_main_worktree=is_main,
                workers=workers,
                repo_root=effective_root,
            )
            count += len(batch)
            if on_progress:
                on_progress(count, total)

    # Resolution passes (structural only — no SCIP)
    structural.resolve_all_imports(worktree_id=wt_id)

    from coderecon.index.resolution.crossfile_lang import run_pass_1_5
    from coderecon.index.resolution.resolver import resolve_references

    run_pass_1_5(db, None, worktree_id=wt_id)
    resolve_references(db, worktree_id=wt_id)

    return count


def reindex_structural(
    db: Database,
    structural: StructuralIndexer,
    repo_root: Path,
    changed_paths: list[Path],
    *,
    worktree_name: str = "main",
    worktree_root: Path | None = None,
) -> int:
    """Incremental structural-only reindex for changed files.

    Returns number of files reindexed.
    """
    effective_root = worktree_root or repo_root
    wt_id = _get_or_create_worktree(db, worktree_name, str(effective_root))
    is_main = worktree_name == "main"

    # Normalize to relative paths
    rel_paths = []
    for p in changed_paths:
        if p.is_absolute():
            try:
                rel_paths.append(str(p.relative_to(effective_root)))
            except ValueError:
                continue
        else:
            rel_paths.append(str(p))

    # Filter to existing files
    existing = [rp for rp in rel_paths if (effective_root / rp).exists()]
    if not existing:
        return 0

    # Assign context_id (use first valid context or fallback)
    with db.session() as session:
        contexts = list(
            session.exec(
                select(Context).where(Context.probe_status == ProbeStatus.VALID.value)
            ).all()
        )
    ctx_id = contexts[0].id if contexts else 1

    workers = min(os.cpu_count() or 4, 16)
    structural.index_files(
        existing,
        ctx_id,
        worktree_id=wt_id,
        is_main_worktree=is_main,
        workers=workers,
        repo_root=effective_root,
    )

    # Re-resolve imports for changed files
    structural.resolve_all_imports(worktree_id=wt_id)

    from coderecon.index.resolution.crossfile_lang import run_pass_1_5
    from coderecon.index.resolution.resolver import resolve_references

    run_pass_1_5(db, None, worktree_id=wt_id)
    resolve_references(db, worktree_id=wt_id)

    return len(existing)


# ── Helpers ──────────────────────────────────────────────────────


def _walk_files(root: Path, ignore_checker: IgnoreChecker) -> list[Path]:
    """Walk repo and collect indexable files (respects .reconignore)."""
    from coderecon._core.excludes import PRUNABLE_DIRS

    results: list[Path] = []
    stack = [root]
    while stack:
        current = stack.pop()
        try:
            entries = sorted(current.iterdir())
        except OSError:
            continue
        for entry in entries:
            if entry.is_dir():
                if entry.name in PRUNABLE_DIRS:
                    continue
                if entry.name.startswith(".") and entry.name not in (".github",):
                    continue
                stack.append(entry)
            elif entry.is_file():
                rel = str(entry.relative_to(root))
                if ignore_checker.is_excluded_rel(rel):
                    continue
                results.append(entry)
    return results


def _get_or_create_worktree(db: Database, name: str, root_path: str) -> int:
    """Get or create a worktree row, return its ID."""
    with db.session() as session:
        existing = session.exec(
            select(Worktree).where(Worktree.name == name)
        ).first()
        if existing and existing.id is not None:
            return existing.id
        wt = Worktree(
            name=name,
            root_path=root_path,
            is_main=(name == "main"),
        )
        session.add(wt)
        session.commit()
        session.refresh(wt)
        if wt.id is None:
            raise RuntimeError(f"Failed to allocate worktree id for {name!r}")
        return wt.id
