---
title: CodeRecon Review SDK
description: Lightweight in-process structural analysis without heavy ML, search, or daemon dependencies
ms.date: 2026-05-12
ms.topic: reference
---

## Overview

The Review SDK provides structural code analysis (diffs, cycles, communities,
impact, orientation) as a single Python class with no external services. It
uses tree-sitter extraction and SQLite — no SPLADE, Tantivy, SCIP, or daemon
process required.

## Installation

The SDK is part of the `coderecon` package. No extra dependencies beyond the
core install.

```python
from coderecon.review import ReviewKit
```

## Quick Start

```python
from coderecon.review import ReviewKit

with ReviewKit("/path/to/repo") as kit:
    kit.ensure_indexed(worktree="main")

    diff = kit.semantic_diff(base="HEAD", worktree="main")
    cycles = kit.graph_cycles(worktree="main")
    communities = kit.graph_communities(worktree="main")
    health = kit.check_structural_health(worktree="main")
    orientation = kit.understand(worktree="main")
    refs = kit.impact("MyClass", worktree="main")
```

## Multi-Worktree

```python
kit = ReviewKit("/path/to/repo")
kit.register_worktree("feature-x", "/path/to/worktree")
kit.ensure_indexed(worktree="feature-x")

diff = kit.semantic_diff(base="main", worktree="feature-x")
cycles = kit.graph_cycles(worktree="feature-x")
```

## API Reference

### `ReviewKit(repo_root, *, db_path=None)`

Create a review instance. Database defaults to `<repo_root>/.recon/review.db`.

---

### `register_worktree(name, path)`

Register a git worktree for multi-worktree analysis.

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | `str` | Logical name (e.g. branch name) |
| `path` | `str \| Path` | Filesystem path to the worktree |

---

### `ensure_indexed(*, worktree, on_progress=None) -> int`

Run tree-sitter extraction and import resolution. No-op after first call
for a given worktree. Returns the number of files indexed.

---

### `reindex(changed_paths, *, worktree) -> int`

Incrementally reindex specific files. Returns the number of files reindexed.

---

### `semantic_diff(*, base="HEAD", target=None, paths=None, worktree) -> SemanticDiffResult`

Compute structural diff between two git states.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `base` | `str` | `"HEAD"` | Base ref (commit, branch, tag) |
| `target` | `str \| None` | `None` | Target ref (`None` = working tree) |
| `paths` | `list[str] \| None` | `None` | Limit to specific paths |
| `worktree` | `str` | — | Which worktree to analyze |

---

### `graph_cycles(*, level="file", worktree) -> CyclesResult`

Detect dependency cycles via Tarjan's algorithm.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `level` | `str` | `"file"` | `"file"` (import graph) or `"def"` (reference graph) |
| `worktree` | `str` | — | Which worktree's index to analyze |

**Returns** `CyclesResult(cycles, level, node_count, edge_count)`

---

### `graph_communities(*, level="file", resolution=1.0, worktree) -> CommunitiesResult`

Detect module communities via Louvain partitioning.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `level` | `str` | `"file"` | `"file"` or `"def"` |
| `resolution` | `float` | `1.0` | Higher values produce more communities |
| `worktree` | `str` | — | Which worktree's index to analyze |

**Returns** `CommunitiesResult(communities, level, node_count, edge_count)`

---

### `check_structural_health(*, baseline_cycles=None, worktree) -> StructuralHealthResult`

Combined health check: new cycles introduced since baseline + community overview.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `baseline_cycles` | `list[CycleCluster] \| None` | `None` | Previous cycles to diff against |
| `worktree` | `str` | — | Which worktree to check |

**Returns** `StructuralHealthResult(new_cycles, community_count, node_count, edge_count, healthy)`

---

### `understand(*, scope=None, worktree) -> UnderstandResult`

Full codebase orientation: top files/symbols by PageRank, cycles,
communities, language breakdown.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `scope` | `str \| None` | `None` | Path prefix to zoom into a subtree |
| `worktree` | `str` | — | Which worktree's index to analyze |

**Returns** `UnderstandResult(languages, top_files, top_symbols, cycles, communities, file_count, def_count)`

---

### `impact(target, *, worktree) -> ImpactResult`

Find all structural references to a symbol or file. Purely index-backed
(no lexical/tantivy fallback).

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `target` | `str` | — | Symbol name or file path |
| `worktree` | `str` | — | Which worktree's index to analyze |

**Returns** `ImpactResult(target, references, definition_sites, import_sites, total_references)`

---

### `close()`

Release database resources. Also available via context manager (`with ReviewKit(...) as kit:`).

## Return Types

All result types are dataclasses with `slots=True` for memory efficiency:

- `SemanticDiffResult` — classified structural changes (added/removed/modified defs)
- `CyclesResult` — list of `CycleCluster` (strongly connected components)
- `CommunitiesResult` — list of `Community` (Louvain partitions)
- `StructuralHealthResult` — aggregated health with `healthy: bool`
- `UnderstandResult` — full orientation with `.to_dict()` serialization
- `ImpactResult` — categorized references with `.to_dict()` serialization
