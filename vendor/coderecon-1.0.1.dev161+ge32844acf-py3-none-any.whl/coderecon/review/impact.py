"""Impact analysis for the lite review SDK.

Finds all structural references to a symbol or file path using the
indexed DefFact, RefFact, and ImportFact tables.  No tantivy/lexical
fallback — purely structural (index-backed) results.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import structlog
from sqlmodel import Session, col, or_, select

from coderecon.index.models import DefFact, File, ImportFact, RefFact

if TYPE_CHECKING:
    from pathlib import Path

    from sqlalchemy.engine import Engine

log = structlog.get_logger(__name__)


@dataclass(frozen=True, slots=True)
class ImpactReference:
    """A single reference site for impact analysis."""

    file: str
    line: int
    kind: str  # "definition", "reference", "import"
    name: str  # What was matched
    certainty: str  # "high" or "medium"


@dataclass(slots=True)
class ImpactResult:
    """Result of impact analysis for a symbol or file."""

    target: str
    references: list[ImpactReference] = field(default_factory=list)
    definition_sites: list[ImpactReference] = field(default_factory=list)
    import_sites: list[ImpactReference] = field(default_factory=list)

    @property
    def total_references(self) -> int:
        return len(self.references) + len(self.definition_sites) + len(self.import_sites)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to plain dict."""
        return {
            "target": self.target,
            "total_references": self.total_references,
            "definition_sites": [
                {"file": r.file, "line": r.line, "name": r.name}
                for r in self.definition_sites
            ],
            "import_sites": [
                {"file": r.file, "line": r.line, "name": r.name, "certainty": r.certainty}
                for r in self.import_sites
            ],
            "reference_sites": [
                {"file": r.file, "line": r.line, "name": r.name, "certainty": r.certainty}
                for r in self.references
            ],
        }


def impact(
    engine: Engine,
    target: str,
    *,
    worktree_id: int,
    repo_root: Path | None = None,
) -> ImpactResult:
    """Find all structural references to a symbol or file.

    Args:
        engine: SQLAlchemy engine connected to the review DB.
        target: Symbol name (e.g. 'MyClass') or file path
            (e.g. 'src/foo/bar.py').
        worktree_id: Worktree to scope analysis to.
        repo_root: Repo root for path normalization (optional).

    Returns:
        ImpactResult with all reference sites categorized.
    """
    is_file = "/" in target or target.endswith(".py")

    result = ImpactResult(target=target)

    if is_file:
        _find_file_references(engine, target, worktree_id, result)
    else:
        _find_symbol_references(engine, target, worktree_id, result)

    return result


def _find_symbol_references(
    engine: Engine, symbol: str, worktree_id: int, result: ImpactResult
) -> None:
    """Find all definitions and references for a symbol name."""
    with Session(engine) as session:
        # Find all definitions with this name in this worktree
        defs = session.exec(
            select(DefFact, File.path)
            .join(File, DefFact.file_id == File.id)  # type: ignore[arg-type]
            .where(DefFact.name == symbol)
            .where(File.worktree_id == worktree_id)
        ).all()

        seen: set[tuple[str, int]] = set()

        def_uids: list[str] = []
        for def_fact, file_path in defs:
            loc = (file_path, def_fact.start_line)
            if loc not in seen:
                seen.add(loc)
                result.definition_sites.append(
                    ImpactReference(
                        file=file_path,
                        line=def_fact.start_line,
                        kind="definition",
                        name=def_fact.name,
                        certainty="high",
                    )
                )
            def_uids.append(def_fact.def_uid)

        # Find all references to these defs in a single query
        if def_uids:
            refs = session.exec(
                select(RefFact, File.path)
                .join(File, RefFact.file_id == File.id)  # type: ignore[arg-type]
                .where(col(RefFact.target_def_uid).in_(def_uids))
                .where(File.worktree_id == worktree_id)
            ).all()

            for ref_fact, ref_file in refs:
                loc = (ref_file, ref_fact.start_line)
                if loc not in seen:
                    seen.add(loc)
                    result.references.append(
                        ImpactReference(
                            file=ref_file,
                            line=ref_fact.start_line,
                            kind="reference",
                            name=symbol,
                            certainty="high",
                        )
                    )

        # Also find imports that reference this symbol by name
        import_refs = session.exec(
            select(ImportFact, File.path)
            .join(File, ImportFact.file_id == File.id)  # type: ignore[arg-type]
            .where(ImportFact.imported_name == symbol)
            .where(File.worktree_id == worktree_id)
        ).all()

        for imp, imp_file in import_refs:
            loc = (imp_file, imp.start_line or 0)
            if loc not in seen:
                seen.add(loc)
                result.import_sites.append(
                    ImpactReference(
                        file=imp_file,
                        line=imp.start_line or 0,
                        kind="import",
                        name=imp.source_literal or symbol,
                        certainty="high",
                    )
                )


def _find_file_references(
    engine: Engine, file_path: str, worktree_id: int, result: ImpactResult
) -> None:
    """Find all imports referencing a file/module."""
    from coderecon.index.resolution.module_mapping import (
        file_to_import_candidates,
        file_to_import_sql_patterns,
    )

    # Normalize path
    file_path = file_path.lstrip("./").rstrip("/")

    with Session(engine) as session:
        # Look up the file for language-aware variant generation
        file_record = session.exec(
            select(File).where(File.path == file_path).where(File.worktree_id == worktree_id)
        ).first()

        language_family: str | None = None
        declared_module: str | None = None
        if file_record:
            language_family = file_record.language_family
            declared_module = file_record.declared_module

        # Generate import candidates
        candidates = file_to_import_candidates(
            file_path, language_family, declared_module
        )
        exact_matches, prefix_patterns = file_to_import_sql_patterns(
            file_path, language_family, declared_module
        )

        # Build SQL conditions
        conditions: list[Any] = []
        if exact_matches:
            conditions.append(col(ImportFact.source_literal).in_(exact_matches))
        for prefix in prefix_patterns:
            conditions.append(col(ImportFact.source_literal).like(f"{prefix}%"))
        # Bare name matches
        bare_names = list({
            c.split(".")[-1] for c in candidates if "." in c
        } | {c for c in candidates if "." not in c})
        if bare_names:
            conditions.append(col(ImportFact.imported_name).in_(bare_names))
        if candidates:
            conditions.append(col(ImportFact.imported_name).in_(candidates))

        if not conditions:
            return

        imports = session.exec(
            select(ImportFact, File.path)
            .join(File, ImportFact.file_id == File.id)  # type: ignore[arg-type]
            .where(or_(*conditions))
            .where(File.worktree_id == worktree_id)
        ).all()

        seen: set[tuple[str, int]] = set()
        for imp, imp_file in imports:
            line = imp.start_line or 0
            loc = (imp_file, line)
            if loc not in seen:
                seen.add(loc)
                # source_literal match = high, imported_name only = medium
                certainty = "high" if imp.source_literal else "medium"
                result.import_sites.append(
                    ImpactReference(
                        file=imp_file,
                        line=line,
                        kind="import",
                        name=imp.source_literal or imp.imported_name or file_path,
                        certainty=certainty,
                    )
                )

        # Also find defs exported from this file (to show what's affected)
        if file_record and file_record.id:
            defs = session.exec(
                select(DefFact)
                .where(DefFact.file_id == file_record.id)
                .order_by(col(DefFact.start_line))
            ).all()

            for def_fact in defs:
                result.definition_sites.append(
                    ImpactReference(
                        file=file_path,
                        line=def_fact.start_line,
                        kind="definition",
                        name=def_fact.name,
                        certainty="high",
                    )
                )

            # Find cross-file references TO symbols defined in this file
            def_uids = [d.def_uid for d in defs]
            uid_to_name = {d.def_uid: d.name for d in defs}
            if def_uids:
                refs = session.exec(
                    select(RefFact, File.path)
                    .join(File, RefFact.file_id == File.id)  # type: ignore[arg-type]
                    .where(col(RefFact.target_def_uid).in_(def_uids))
                    .where(RefFact.file_id != file_record.id)
                    .where(File.worktree_id == worktree_id)
                ).all()

                for ref_fact, ref_file in refs:
                    loc = (ref_file, ref_fact.start_line)
                    if loc not in seen:
                        seen.add(loc)
                        result.references.append(
                            ImpactReference(
                                file=ref_file,
                                line=ref_fact.start_line,
                                kind="reference",
                                name=uid_to_name.get(ref_fact.target_def_uid, ref_fact.target_def_uid),
                                certainty="high",
                            )
                        )
