"""Understand — codebase orientation for the lite review SDK.

Provides structural understanding of a codebase: top files by PageRank,
top symbols by PageRank, dependency cycles, communities, coverage/lint health,
and file-level language breakdown.

All analysis is backed by the structural index (SQLite).  No tantivy,
SPLADE, or MCP transport required.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import networkx as nx
import structlog
from sqlalchemy import func, text
from sqlmodel import Session, select

from coderecon.index.analysis.code_graph import (
    build_def_graph,
    build_file_graph,
    detect_communities,
    detect_cycles,
)
from coderecon.index.models import File

if TYPE_CHECKING:
    from sqlalchemy.engine import Engine

log = structlog.get_logger(__name__)


@dataclass(slots=True)
class UnderstandResult:
    """Complete codebase orientation result."""

    languages: list[dict[str, Any]] = field(default_factory=list)
    top_files: list[dict[str, Any]] = field(default_factory=list)
    top_symbols: list[dict[str, Any]] = field(default_factory=list)
    cycles: list[dict[str, Any]] = field(default_factory=list)
    communities: list[dict[str, Any]] = field(default_factory=list)
    coverage: dict[str, Any] | None = None
    lint: dict[str, Any] | None = None
    file_count: int = 0
    def_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize to plain dict."""
        result: dict[str, Any] = {
            "file_count": self.file_count,
            "def_count": self.def_count,
        }
        if self.languages:
            result["languages"] = self.languages
        if self.top_files:
            result["top_files"] = self.top_files
        if self.top_symbols:
            result["top_symbols"] = self.top_symbols
        if self.cycles:
            result["cycles"] = self.cycles
        if self.communities:
            result["communities"] = self.communities
        if self.coverage is not None:
            result["coverage"] = self.coverage
        if self.lint is not None:
            result["lint"] = self.lint
        return result


def understand(
    engine: Engine,
    *,
    worktree_id: int,
    scope: str | None = None,
) -> UnderstandResult:
    """Build codebase orientation from the structural index.

    Args:
        engine: SQLAlchemy engine connected to the review DB.
        worktree_id: Worktree to scope analysis to.
        scope: Optional path prefix to scope analysis to a subtree.

    Returns:
        UnderstandResult with all orientation sections.
    """
    result = UnderstandResult()

    # --- Language breakdown ---
    result.languages = _gather_languages(engine, worktree_id, scope)

    # --- File count ---
    result.file_count = _count_files(engine, worktree_id, scope)

    # --- Def count ---
    result.def_count = _count_defs(engine, worktree_id, scope)

    # --- File-level PageRank + cycles + communities ---
    _gather_file_graph(engine, worktree_id, scope, result)

    # --- Def-level PageRank (top symbols) ---
    _gather_def_graph(engine, worktree_id, scope, result)

    # --- Coverage health ---
    result.coverage = _gather_coverage(engine, worktree_id)

    # --- Lint health ---
    result.lint = _gather_lint(engine, worktree_id)

    return result


def _gather_languages(engine: Engine, worktree_id: int, scope: str | None) -> list[dict[str, Any]]:
    """Get language distribution from the File table."""
    with Session(engine) as session:
        stmt = (
            select(
                File.language_family,
                func.count().label("file_count"),
            )
            .where(File.language_family != None)  # noqa: E711
            .where(File.worktree_id == worktree_id)
        )
        if scope:
            stmt = stmt.where(File.path.startswith(scope))  # type: ignore[union-attr]
        stmt = stmt.group_by(File.language_family).order_by(func.count().desc())
        rows = session.exec(stmt).all()

    total = sum(count for _, count in rows)
    if total == 0:
        return []
    return [
        {
            "language": lang,
            "file_count": count,
            "percentage": round(count / total * 100, 1),
        }
        for lang, count in rows
        if lang
    ]


def _count_files(engine: Engine, worktree_id: int, scope: str | None) -> int:
    with Session(engine) as session:
        stmt = select(func.count()).select_from(File).where(File.worktree_id == worktree_id)
        if scope:
            stmt = stmt.where(File.path.startswith(scope))  # type: ignore[union-attr]
        return session.exec(stmt).one()


def _count_defs(engine: Engine, worktree_id: int, scope: str | None) -> int:
    from coderecon.index.models import DefFact

    with Session(engine) as session:
        stmt = select(func.count()).select_from(DefFact)
        # Scope to worktree via file_id
        subq = select(File.id).where(File.worktree_id == worktree_id)
        if scope:
            subq = subq.where(File.path.startswith(scope))  # type: ignore[union-attr]
        stmt = stmt.where(DefFact.file_id.in_(subq))  # type: ignore[union-attr]
        return session.exec(stmt).one()


def _gather_file_graph(
    engine: Engine, worktree_id: int, scope: str | None, result: UnderstandResult
) -> None:
    """Build file graph, compute PageRank, detect cycles + communities."""
    try:
        fg = build_file_graph(engine, worktree_id=worktree_id)
    except (OSError, ValueError):
        log.debug("understand.file_graph.failed", exc_info=True)
        return

    if scope:
        scope_nodes = {n for n in fg.nodes() if n.startswith(scope)}
        if not scope_nodes:
            return
        fg = fg.subgraph(scope_nodes).copy()

    if fg.number_of_nodes() == 0:
        return

    # PageRank
    file_pr = nx.pagerank(fg, alpha=0.85, max_iter=100, tol=1e-06)
    if file_pr:
        import statistics

        scores = list(file_pr.values())
        median = statistics.median(scores)
        top = sorted(
            ((path, score) for path, score in file_pr.items() if score >= median),
            key=lambda x: x[1],
            reverse=True,
        )
        result.top_files = [
            {"file": path, "pagerank": round(score, 6)}
            for path, score in top[:15]
        ]

    # Cycles
    cycles = detect_cycles(fg)
    if cycles:
        result.cycles = [
            {"size": c.size, "nodes": sorted(c.nodes)}
            for c in cycles
        ]

    # Communities
    communities = detect_communities(fg)
    if communities:
        result.communities = [
            {
                "id": c.community_id,
                "size": c.size,
                "representative": c.representative,
                "members": c.members[:20],
            }
            for c in communities[:10]
        ]


def _gather_def_graph(
    engine: Engine, worktree_id: int, scope: str | None, result: UnderstandResult
) -> None:
    """Build def graph and compute symbol-level PageRank."""
    try:
        dg = build_def_graph(engine, worktree_id=worktree_id)
    except (OSError, ValueError):
        log.debug("understand.def_graph.failed", exc_info=True)
        return

    if scope:
        scope_def_nodes = {
            n for n in dg.nodes()
            if dg.nodes[n].get("file_path", "").startswith(scope)
        }
        if not scope_def_nodes:
            return
        dg = dg.subgraph(scope_def_nodes).copy()

    if dg.number_of_nodes() == 0:
        return

    def_pr = nx.pagerank(dg, alpha=0.85, max_iter=100, tol=1e-06)
    if def_pr:
        import statistics

        scores = list(def_pr.values())
        median = statistics.median(scores)
        top = sorted(
            ((nid, score) for nid, score in def_pr.items() if score >= median),
            key=lambda x: x[1],
            reverse=True,
        )
        result.top_symbols = [
            {
                "name": dg.nodes[nid].get("name", nid),
                "file": dg.nodes[nid].get("file_path", ""),
                "kind": dg.nodes[nid].get("kind", "unknown"),
                "pagerank": round(score, 6),
            }
            for nid, score in top[:15]
        ]


def _gather_coverage(engine: Engine, worktree_id: int) -> dict[str, Any] | None:
    """Get coverage summary if available."""
    try:
        from coderecon.index.analysis.coverage_ingestion import get_coverage_summary

        cov = get_coverage_summary(engine, worktree_id=worktree_id)
        if cov.get("defs_covered", 0) > 0:
            return {
                "rate": cov["coverage_rate"],
                "covered": cov["defs_covered"],
                "total": cov["total_defs"],
            }
    except (ImportError, OSError, ValueError):
        pass
    return None


def _gather_lint(engine: Engine, worktree_id: int) -> dict[str, Any] | None:
    """Get lint summary if available."""
    try:
        from coderecon.index.analysis.lint_status import get_lint_summary

        lint = get_lint_summary(engine, worktree_id=worktree_id)
        if lint.get("files_checked", 0) > 0:
            return {
                "clean_files": lint["clean_files"],
                "total_errors": lint["total_errors"],
                "files_checked": lint["files_checked"],
            }
    except (ImportError, OSError, ValueError):
        pass
    return None
