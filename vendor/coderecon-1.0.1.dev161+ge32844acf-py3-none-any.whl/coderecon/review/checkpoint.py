"""Checkpoint pipeline for the ReviewKit SDK.

Diff → reachability-based test selection → import-graph fallback → test
execution, without commit/push.  Bridges the async ops classes into
ReviewKit's synchronous API.
"""

from __future__ import annotations

import asyncio
import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from coderecon.adapters.git.ops import GitOps
    from coderecon.index.db import Database
    from coderecon.index.diff.models import SemanticDiffResult
    from coderecon.index.graph.import_graph_models import ImportGraphResult
    from coderecon.lint.models import LintResult
    from coderecon.testing.models import TestResult

log = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class LintPhaseResult:
    """Lint phase outcome."""

    status: str  # "clean", "dirty", "skipped", "error"
    diagnostics: int = 0
    fixed_files: int = 0
    duration_sec: float = 0.0
    raw: LintResult | None = None


@dataclass
class TestPhaseResult:
    """Test phase outcome."""

    status: str  # "passed", "failed", "skipped", "error"
    passed: int = 0
    failed: int = 0
    targets_discovered: int = 0
    targets_affected: int = 0
    duration_sec: float = 0.0
    tiers: dict[int, int] = field(default_factory=dict)  # hop → target count
    failures: list[dict[str, Any]] = field(default_factory=list)
    strategy: str = "import_graph"  # "reachability", "import_graph", "hybrid"
    raw: TestResult | None = None


@dataclass
class DiffPhaseResult:
    """Diff phase outcome."""

    status: str  # "ok", "skipped", "error"
    structural_changes: int = 0
    non_structural_changes: int = 0
    breaking_changes: int = 0
    duration_sec: float = 0.0
    raw: SemanticDiffResult | None = None


@dataclass
class CheckpointResult:
    """Aggregate checkpoint outcome."""

    passed: bool
    summary: str
    changed_files: list[str]
    diff: DiffPhaseResult | None = None
    lint: LintPhaseResult | None = None
    tests: TestPhaseResult | None = None
    test_debt: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Coordinator shim
# ---------------------------------------------------------------------------


def _make_lite_coordinator(
    db: Database,
    repo_root: Path,
    worktree_id: int,
) -> Any:
    """Build a lightweight IndexCoordinatorEngine over ReviewKit's DB.

    Points at the same SQLite file.  Tantivy/SPLADE are never used by
    the lint and test paths, so a scratch directory is sufficient.
    """
    from coderecon.index.ops import IndexCoordinatorEngine

    tantivy_scratch = Path(tempfile.mkdtemp(prefix="reviewkit_tantivy_"))
    coordinator = IndexCoordinatorEngine(
        repo_root,
        db_path=db.db_path,
        tantivy_path=tantivy_scratch,
    )
    # Mark initialised so wait_for_freshness() is a no-op
    # (ReviewKit has already indexed synchronously).
    coordinator._initialized = True  # noqa: SLF001
    # Pre-seed the worktree cache so active_worktree_id resolves
    # without querying the ContextVar-based daemon dispatch.
    coordinator._worktree_id_cache["main"] = worktree_id  # noqa: SLF001
    return coordinator


# ---------------------------------------------------------------------------
# Phase runners
# ---------------------------------------------------------------------------


def _run_diff(
    db: Database,
    git_ops: GitOps,
    repo_root: Path,
    worktree_id: int,
    changed_files: list[str],
) -> DiffPhaseResult:
    """Execute the diff phase."""
    import time

    from coderecon.review.diff import structural_diff

    start = time.time()
    try:
        result = structural_diff(
            db, git_ops, repo_root,
            worktree_id=worktree_id,
            base="HEAD",
            target=None,
            paths=changed_files or None,
        )
    except Exception as exc:
        log.warning("checkpoint.diff_error", extra={"error": str(exc)})
        return DiffPhaseResult(
            status="error",
            duration_sec=time.time() - start,
        )

    breaking = sum(
        1 for c in result.structural_changes
        if c.structural_severity == "breaking"
    )

    return DiffPhaseResult(
        status="ok",
        structural_changes=len(result.structural_changes),
        non_structural_changes=len(result.non_structural_changes),
        breaking_changes=breaking,
        duration_sec=time.time() - start,
        raw=result,
    )


async def _run_lint(
    repo_root: Path,
    coordinator: Any,
    changed_files: list[str],
    autofix: bool,
) -> LintPhaseResult:
    """Execute the lint phase."""
    import time

    from coderecon.lint.ops import LintOps

    lint_ops = LintOps(repo_root, coordinator)
    start = time.time()
    try:
        result = await lint_ops.check(
            paths=changed_files or None,
            tools=None,
            categories=None,
            dry_run=not autofix,
        )
    except Exception as exc:
        log.warning("checkpoint.lint_error", extra={"error": str(exc)})
        return LintPhaseResult(
            status="error",
            duration_sec=time.time() - start,
        )

    return LintPhaseResult(
        status=result.status,
        diagnostics=result.total_diagnostics,
        fixed_files=result.total_files_modified,
        duration_sec=time.time() - start,
        raw=result,
    )


async def _run_tests(
    repo_root: Path,
    coordinator: Any,
    db: Database,
    worktree_id: int,
    changed_files: list[str],
    test_filter: str | None,
    max_test_hops: int,
) -> TestPhaseResult:
    """Discover affected tests and execute them.

    Strategy:
      1. **Primary** — query ``test_reachability_facts`` (symbol-level call
         graph).  Precise: only tests whose defs transitively call defs in
         the changed files.
      2. **Fallback** — walk ``ImportGraph`` (module-level import edges).
         Broader: any test that imports a changed module.  Used when
         reachability data is absent or mostly stale.
      3. **Hybrid** — if reachability covers some files but not all, union
         reachability results with import-graph results.
    """
    import time

    from coderecon.index.analysis.reachability import (
        affected_test_files_by_reachability,
    )
    from coderecon.index.graph.import_graph import ImportGraph
    from coderecon.testing.ops import TestOps

    start = time.time()

    # 1. Discover all test targets via TestOps
    test_ops = TestOps(repo_root, coordinator)
    discover_result = await test_ops.discover(paths=None)
    all_targets = discover_result.targets or []

    if not all_targets:
        return TestPhaseResult(
            status="skipped",
            duration_sec=time.time() - start,
        )

    if not changed_files:
        return TestPhaseResult(
            status="skipped",
            targets_discovered=len(all_targets),
            duration_sec=time.time() - start,
        )

    # 2. Primary: symbol-level reachability
    reach = affected_test_files_by_reachability(
        db, changed_files, worktree_id=worktree_id,
    )

    affected_paths: set[str] = set()
    strategy: str
    graph_result: ImportGraphResult | None = None

    if reach.has_data and reach.stale_ratio < 0.5:
        # Reachability data is fresh enough — use it
        affected_paths = set(reach.test_files)
        strategy = "reachability"
    else:
        strategy = "import_graph"

    # 3. Fallback / hybrid: import graph for coverage gaps
    if strategy == "import_graph" or not affected_paths:
        with db.session() as session:
            graph = ImportGraph(session, worktree_id=worktree_id)
            graph_result = graph.affected_tests(changed_files)
        import_paths = set(graph_result.test_files)

        if strategy == "reachability" and not affected_paths:
            # Reachability returned no hits despite having data — use import graph
            affected_paths = import_paths
            strategy = "import_graph"
        elif strategy == "reachability":
            # Union: import graph may catch tests that reachability missed
            # (e.g. unresolved refs, languages without call edges)
            new_paths = import_paths - affected_paths
            if new_paths:
                affected_paths |= new_paths
                strategy = "hybrid"
        else:
            affected_paths = import_paths

    if not affected_paths:
        return TestPhaseResult(
            status="skipped",
            targets_discovered=len(all_targets),
            strategy=strategy,
            duration_sec=time.time() - start,
        )

    # 4. Filter targets to affected ones
    filtered = [
        t for t in all_targets
        if _target_matches(t, affected_paths, repo_root)
    ]

    if not filtered:
        return TestPhaseResult(
            status="skipped",
            targets_discovered=len(all_targets),
            targets_affected=0,
            strategy=strategy,
            duration_sec=time.time() - start,
        )

    # 5. Assign hop tiers (from import graph when available)
    tier_counts: dict[int, int] = {}
    targets_to_run: list[Any] = filtered

    if graph_result is not None:
        tests_by_hop = graph_result.tests_by_hop()
        file_to_hop: dict[str, int] = {}
        for hop, files in tests_by_hop.items():
            for f in files:
                if f not in file_to_hop:
                    file_to_hop[f] = hop

        targets_to_run = []
        for t in filtered:
            hop = _resolve_hop(t, file_to_hop, repo_root)
            if hop <= max_test_hops:
                targets_to_run.append(t)
                tier_counts[hop] = tier_counts.get(hop, 0) + 1
    elif strategy == "reachability":
        # Pure reachability — all matched targets run (no hop filtering)
        tier_counts = {0: len(filtered)}
        targets_to_run = filtered

    if not targets_to_run:
        return TestPhaseResult(
            status="skipped",
            targets_discovered=len(all_targets),
            targets_affected=len(filtered),
            tiers=tier_counts,
            strategy=strategy,
            duration_sec=time.time() - start,
        )

    # 6. Execute tests
    target_ids = [t.target_id for t in targets_to_run]
    try:
        run_result = await test_ops.run(
            targets=target_ids,
            test_filter=test_filter,
            fail_fast=False,
            coverage=False,
        )
    except Exception as exc:
        log.warning("checkpoint.test_error", extra={"error": str(exc)})
        return TestPhaseResult(
            status="error",
            targets_discovered=len(all_targets),
            targets_affected=len(filtered),
            tiers=tier_counts,
            strategy=strategy,
            duration_sec=time.time() - start,
        )

    # 7. Parse results
    passed = 0
    failed = 0
    failures: list[dict[str, Any]] = []
    if run_result.run_status and run_result.run_status.progress:
        p = run_result.run_status.progress
        passed = p.cases.passed
        failed = p.cases.failed
    if run_result.run_status and run_result.run_status.failures:
        for f in run_result.run_status.failures:
            failures.append({
                "test_id": f.test_id,
                "message": f.message,
                "location": f.location,
            })

    status = "passed" if failed == 0 else "failed"

    return TestPhaseResult(
        status=status,
        passed=passed,
        failed=failed,
        targets_discovered=len(all_targets),
        targets_affected=len(filtered),
        tiers=tier_counts,
        failures=failures,
        strategy=strategy,
        duration_sec=time.time() - start,
        raw=run_result,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _target_matches(
    target: Any,
    affected_paths: set[str],
    repo_root: Path,
) -> bool:
    """Check if a test target matches any affected file path."""
    ws = Path(target.workspace_root)
    sel = target.selector
    scope_abs = ws / sel if sel else ws
    try:
        scope_rel = str(scope_abs.relative_to(repo_root))
    except ValueError:
        scope_rel = target.selector

    if scope_rel in affected_paths:
        return True
    return any(
        p == scope_rel or p.startswith(scope_rel + "/")
        for p in affected_paths
    )


def _resolve_hop(
    target: Any,
    file_to_hop: dict[str, int],
    repo_root: Path,
) -> int:
    """Determine the hop distance for a test target."""
    ws = Path(target.workspace_root)
    sel = target.selector
    scope_abs = ws / sel if sel else ws
    try:
        scope_rel = str(scope_abs.relative_to(repo_root))
    except ValueError:
        scope_rel = target.selector
    if scope_rel in file_to_hop:
        return file_to_hop[scope_rel]
    for fpath, fhop in file_to_hop.items():
        if fpath == scope_rel or fpath.startswith(scope_rel + "/"):
            return fhop
    return 0


def _detect_test_debt(
    changed_files: list[str],
    repo_root: Path,
) -> dict[str, Any] | None:
    """Detect source files changed without corresponding test updates."""
    from coderecon._core.languages import is_test_file

    source_files = [f for f in changed_files if not is_test_file(f)]
    test_files = [f for f in changed_files if is_test_file(f)]

    if not source_files or test_files:
        return None

    return {
        "source_files_without_tests": source_files,
        "hint": (
            f"{len(source_files)} source file(s) changed with no test updates. "
            "Consider adding or updating tests."
        ),
    }


def _build_summary(
    diff: DiffPhaseResult | None,
    lint: LintPhaseResult | None,
    tests: TestPhaseResult | None,
) -> str:
    """Build a compact summary string."""
    parts: list[str] = []
    if diff is None:
        parts.append("diff: skipped")
    elif diff.status == "error":
        parts.append("diff: error")
    elif diff.breaking_changes > 0:
        parts.append(f"diff: {diff.breaking_changes} breaking")
    else:
        total = diff.structural_changes + diff.non_structural_changes
        parts.append(f"diff: {total} files")

    if lint is None:
        parts.append("lint: skipped")
    elif lint.status == "clean":
        parts.append("lint: clean")
    elif lint.diagnostics > 0:
        parts.append(f"lint: {lint.diagnostics} issues")
    else:
        parts.append(f"lint: {lint.status}")

    if tests is None:
        parts.append("tests: skipped")
    elif tests.status == "skipped":
        parts.append("tests: skipped")
    elif tests.failed > 0:
        parts.append(f"tests: {tests.passed} passed, {tests.failed} FAILED")
    elif tests.passed > 0:
        parts.append(f"tests: {tests.passed} passed")
    else:
        parts.append(f"tests: {tests.status}")

    return " | ".join(parts)


# ---------------------------------------------------------------------------
# Public entry point (called from ReviewKit.checkpoint)
# ---------------------------------------------------------------------------


async def _checkpoint_async(
    db: Database,
    repo_root: Path,
    worktree_id: int,
    changed_files: list[str],
    *,
    diff: bool = True,
    git_ops: GitOps | None = None,
    lint: bool = True,
    autofix: bool = True,
    tests: bool = True,
    test_filter: str | None = None,
    max_test_hops: int = 0,
) -> CheckpointResult:
    """Async checkpoint pipeline."""
    coordinator = _make_lite_coordinator(db, repo_root, worktree_id)
    try:
        diff_result: DiffPhaseResult | None = None
        lint_result: LintPhaseResult | None = None
        test_result: TestPhaseResult | None = None

        if diff and git_ops is not None:
            diff_result = _run_diff(
                db, git_ops, repo_root, worktree_id,
                changed_files,
            )

        if lint:
            lint_result = await _run_lint(repo_root, coordinator, changed_files, autofix)
            # Skip tests if lint failed
            if lint_result.diagnostics > 0 and lint_result.status != "clean":
                tests = False

        if tests:
            test_result = await _run_tests(
                repo_root, coordinator, db, worktree_id,
                changed_files, test_filter, max_test_hops,
            )

        test_debt = _detect_test_debt(changed_files, repo_root)
        summary = _build_summary(diff_result, lint_result, test_result)

        lint_ok = lint_result is None or lint_result.status in ("clean", "skipped")
        tests_ok = test_result is None or test_result.status in ("passed", "skipped")
        passed = lint_ok and tests_ok

        return CheckpointResult(
            passed=passed,
            summary=summary,
            changed_files=changed_files,
            diff=diff_result,
            lint=lint_result,
            tests=test_result,
            test_debt=test_debt,
        )
    finally:
        # Clean up scratch tantivy dir created by _make_lite_coordinator
        shutil.rmtree(coordinator.tantivy_path, ignore_errors=True)


def run_checkpoint(
    db: Database,
    repo_root: Path,
    worktree_id: int,
    changed_files: list[str],
    *,
    diff: bool = True,
    git_ops: GitOps | None = None,
    lint: bool = True,
    autofix: bool = True,
    tests: bool = True,
    test_filter: str | None = None,
    max_test_hops: int = 0,
) -> CheckpointResult:
    """Synchronous entry point for ReviewKit.checkpoint()."""
    return asyncio.run(
        _checkpoint_async(
            db, repo_root, worktree_id, changed_files,
            diff=diff, git_ops=git_ops,
            lint=lint, autofix=autofix, tests=tests,
            test_filter=test_filter, max_test_hops=max_test_hops,
        )
    )
