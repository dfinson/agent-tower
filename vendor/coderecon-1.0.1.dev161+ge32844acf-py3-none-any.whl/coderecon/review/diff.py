"""Structural diff for the lite review SDK.

Thin wrapper over the extracted `run_structural_diff` function from the
index.diff.pipeline module (no fastmcp/MCP dependencies).
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from coderecon.index.diff.models import SemanticDiffResult
from coderecon.index.diff.pipeline import run_structural_diff

if TYPE_CHECKING:
    from coderecon.adapters.git.ops import GitOps
    from coderecon.index.db import Database


def structural_diff(
    db: Database,
    git_ops: GitOps,
    repo_root: Path,
    *,
    worktree_id: int,
    base: str = "HEAD",
    target: str | None = None,
    paths: list[str] | None = None,
) -> SemanticDiffResult:
    """Compute a structural diff between two git states.

    Args:
        db: Database with indexed structural facts.
        git_ops: GitOps for the repo (or worktree).
        repo_root: Root path of the repository.
        base: Base ref (commit, branch, tag). Defaults to HEAD.
        target: Target ref. None means working tree.
        paths: Limit analysis to these paths.

    Returns:
        SemanticDiffResult with classified structural changes.
    """
    return run_structural_diff(
        db, git_ops, repo_root, worktree_id=worktree_id, base=base, target=target, paths=paths,
    )
