"""Graph analysis for the lite review SDK.

Wraps cycle detection, community detection, and structural health checks
over the existing code_graph module.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from coderecon.index.analysis.code_graph import (
    Community,
    CycleCluster,
    build_def_graph,
    build_file_graph,
    detect_communities,
    detect_cycles,
)

if TYPE_CHECKING:
    from sqlalchemy.engine import Engine


@dataclass(frozen=True, slots=True)
class CyclesResult:
    """Result of cycle detection."""

    cycles: list[CycleCluster]
    level: str  # "file" or "def"
    node_count: int
    edge_count: int


@dataclass(frozen=True, slots=True)
class CommunitiesResult:
    """Result of community detection."""

    communities: list[Community]
    level: str
    node_count: int
    edge_count: int


@dataclass(slots=True)
class StructuralHealthResult:
    """Structural health check combining cycles + community drift."""

    new_cycles: list[CycleCluster] = field(default_factory=list)
    community_count: int = 0
    node_count: int = 0
    edge_count: int = 0
    healthy: bool = True


def graph_cycles(engine: Engine, *, worktree_id: int, level: str = "file") -> CyclesResult:
    """Detect dependency cycles in the codebase.

    Args:
        engine: SQLAlchemy engine connected to the index DB.
        worktree_id: Worktree to scope analysis to.
        level: "file" (import-based) or "def" (reference-based).

    Returns:
        CyclesResult with all SCCs of size > 1.
    """
    if level == "def":
        g = build_def_graph(engine, worktree_id=worktree_id)
    else:
        g = build_file_graph(engine, worktree_id=worktree_id)

    cycles = detect_cycles(g)
    return CyclesResult(
        cycles=cycles,
        level=level,
        node_count=g.number_of_nodes(),
        edge_count=g.number_of_edges(),
    )


def graph_communities(
    engine: Engine, *, worktree_id: int, level: str = "file", resolution: float = 1.0
) -> CommunitiesResult:
    """Detect module communities via Louvain.

    Args:
        engine: SQLAlchemy engine connected to the index DB.
        worktree_id: Worktree to scope analysis to.
        level: "file" or "def".
        resolution: Louvain resolution parameter (higher = more communities).

    Returns:
        CommunitiesResult with detected communities.
    """
    if level == "def":
        g = build_def_graph(engine, worktree_id=worktree_id)
    else:
        g = build_file_graph(engine, worktree_id=worktree_id)

    communities = detect_communities(g, resolution=resolution)
    return CommunitiesResult(
        communities=communities,
        level=level,
        node_count=g.number_of_nodes(),
        edge_count=g.number_of_edges(),
    )


def check_structural_health(
    engine: Engine,
    *,
    worktree_id: int,
    baseline_cycles: list[CycleCluster] | None = None,
) -> StructuralHealthResult:
    """Run a structural health check (cycles + community overview).

    Args:
        engine: SQLAlchemy engine connected to the index DB.
        worktree_id: Worktree to scope analysis to.
        baseline_cycles: Optional baseline to diff against. If provided,
            only cycles NOT in the baseline are flagged as new.

    Returns:
        StructuralHealthResult indicating whether new cycles were introduced.
    """
    g = build_file_graph(engine, worktree_id=worktree_id)
    current_cycles = detect_cycles(g)
    communities = detect_communities(g)

    # Determine new cycles by comparing against baseline
    if baseline_cycles is not None:
        baseline_sets = {c.nodes for c in baseline_cycles}
        new_cycles = [c for c in current_cycles if c.nodes not in baseline_sets]
    else:
        new_cycles = current_cycles

    return StructuralHealthResult(
        new_cycles=new_cycles,
        community_count=len(communities),
        node_count=g.number_of_nodes(),
        edge_count=g.number_of_edges(),
        healthy=len(new_cycles) == 0,
    )
