"""Background SCIP refresh scheduler.

Hooks into the BackgroundIndexer's on_complete callback. After incremental
indexing completes, starts an idle timer. When the idle window expires:

- Runs **incremental** SCIP indexing for tools that support partial
  refresh (``per_file``, ``per_package``), scoped to the changed paths
  accumulated since the last run.
- Runs **full-project** SCIP refresh for tools that require it
  (``full_project`` granularity) when any source file has changed since
  the last import.

This keeps SCIP cross-file resolution current without blocking interactive
indexing.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from coderecon.index.db import Database
    from coderecon.index.ops import IndexStats

log = structlog.get_logger(__name__)


class ScipScheduler:
    """Schedules background SCIP refresh after indexing idle periods.

    Lifecycle:
        1. Attach to BackgroundIndexer via ``indexer.add_on_complete(scheduler.on_index_complete)``
        2. Each indexing completion accumulates changed paths and resets the idle timer
        3. When idle timer fires, run incremental SCIP for per-file/per-package
           tools scoped to the accumulated paths, then full-project SCIP for
           full-project tools with stale data
        4. Stop via ``await scheduler.stop()``
    """

    def __init__(
        self,
        db: Database,
        repo_root: Path,
        idle_delay_sec: float,
    ) -> None:
        self._db = db
        self._repo_root = repo_root
        self._idle_delay_sec = idle_delay_sec
        self._timer_task: asyncio.Task[None] | None = None
        self._running = False
        self._refresh_lock = asyncio.Lock()
        self._pending_paths: set[str] = set()
        self._consecutive_failures = 0
        self._max_consecutive_failures = 3

    def start(self) -> None:
        """Mark scheduler as active."""
        self._running = True
        log.debug("scip_scheduler.started", idle_delay=self._idle_delay_sec)

    async def stop(self) -> None:
        """Cancel any pending timer and wait for in-flight refresh."""
        self._running = False
        if self._timer_task is not None and not self._timer_task.done():
            self._timer_task.cancel()
            try:
                await self._timer_task
            except asyncio.CancelledError:
                pass
            self._timer_task = None
        # If a refresh is in-flight, wait for it to finish so the caller
        # can safely tear down the DB afterwards.
        if self._refresh_lock.locked():
            async with self._refresh_lock:
                pass  # just wait for the running refresh to release
        log.debug("scip_scheduler.stopped")

    async def on_index_complete(self, stats: IndexStats, paths: list[Path]) -> None:
        """Callback from BackgroundIndexer after each indexing batch completes.

        Accumulates changed paths and resets the idle timer — SCIP refresh
        only fires when no more indexing activity occurs within idle_delay_sec.
        """
        if not self._running:
            return

        # A new indexing event means the system is alive — reset failure counter
        self._consecutive_failures = 0

        # Accumulate repo-relative paths (skip paths outside repo root)
        for p in paths:
            try:
                rel = os.path.relpath(p, self._repo_root)
            except ValueError:
                continue
            if rel.startswith(".."):
                continue
            self._pending_paths.add(rel)

        # Cancel any existing timer
        if self._timer_task is not None and not self._timer_task.done():
            self._timer_task.cancel()
            try:
                await self._timer_task
            except asyncio.CancelledError:
                pass

        # Start a new idle timer
        self._timer_task = asyncio.create_task(self._idle_then_refresh())

    async def _idle_then_refresh(self) -> None:
        """Wait for idle period, then run SCIP refresh."""
        try:
            await asyncio.sleep(self._idle_delay_sec)
        except asyncio.CancelledError:
            return

        if not self._running:
            return

        # Only one refresh at a time
        if self._refresh_lock.locked():
            log.debug("scip_scheduler.refresh_already_running")
            return

        async with self._refresh_lock:
            await self._run_scip_refresh()

        # If more paths arrived while we held the lock, reschedule so
        # they don't strand until the next save event.
        if self._pending_paths and self._running:
            self._timer_task = asyncio.create_task(self._idle_then_refresh())

    async def _run_scip_refresh(self) -> None:
        """Run SCIP indexers — incremental for partial tools, full for the rest."""
        from coderecon.index.scip.runner import (
            ensure_scip_current,
            run_scip_incremental,
        )
        from coderecon.index.scip.tools import detect_scip_tools

        log.info("scip_scheduler.refresh_starting")

        try:
            tools_with_paths = detect_scip_tools(self._repo_root)

            if not tools_with_paths:
                log.debug("scip_scheduler.no_tools_detected")
                return

            # --- Phase 1: incremental SCIP for per-file/per-package tools ---
            # Snapshot and drain pending paths
            changed = list(self._pending_paths)
            self._pending_paths.clear()

            has_incremental_tools = any(
                tool.refresh_granularity != "full_project" and path is not None
                for tool, path in tools_with_paths
            )
            if changed and has_incremental_tools:
                log.info(
                    "scip_scheduler.incremental_starting",
                    changed_files=len(changed),
                )
                try:
                    inc_result = await run_scip_incremental(
                        self._db, self._repo_root, changed,
                    )
                except Exception:
                    # Restore paths so they're retried on next trigger
                    self._pending_paths.update(changed)
                    raise
                inc_ok = [r for r in inc_result.results if r.success]
                inc_fail = [r for r in inc_result.results if not r.success]
                if inc_ok:
                    log.info(
                        "scip_scheduler.incremental_complete",
                        refs_proven=inc_result.total_refs_matched,
                        refs_external=inc_result.total_refs_external,
                        tools=[r.tool_name for r in inc_ok],
                    )
                for r in inc_fail:
                    log.warning(
                        "scip_scheduler.incremental_tool_failed",
                        tool=r.tool_name,
                        language=r.language,
                        error=r.error,
                    )

            # --- Phase 2: full-project SCIP for full_project tools ---
            # Reuse the already-detected tools — no need to re-scan markers,
            # check prerequisites, or auto-provision again.
            full_project_tools = [
                (tool, path)
                for tool, path in tools_with_paths
                if tool.refresh_granularity == "full_project" and path is not None
            ]

            if full_project_tools:
                log.info(
                    "scip_scheduler.full_project_starting",
                    tools=[t.name for t, _ in full_project_tools],
                )
                # ensure_scip_current handles staleness checks internally
                fp_result = await ensure_scip_current(self._db, self._repo_root)
                fp_ok = [r for r in fp_result.results if r.success]
                fp_fail = [r for r in fp_result.results if not r.success]

                total_refs = sum(r.refs_matched for r in fp_ok)
                total_ext = sum(r.refs_external for r in fp_ok)

                log.info(
                    "scip_scheduler.full_project_complete",
                    refs_proven=total_refs,
                    refs_external=total_ext,
                    failures=len(fp_fail),
                )

                for r in fp_fail:
                    log.warning(
                        "scip_scheduler.tool_failed",
                        tool=r.tool_name,
                        language=r.language,
                        error=r.error,
                    )

            self._consecutive_failures = 0

        except Exception as e:
            self._consecutive_failures += 1
            if self._consecutive_failures >= self._max_consecutive_failures:
                # Drop pending paths to break the retry loop — they'll be
                # re-discovered on the next save event.
                dropped = len(self._pending_paths)
                self._pending_paths.clear()
                log.error(
                    "scip_scheduler.refresh_disabled_after_failures",
                    consecutive=self._consecutive_failures,
                    dropped_paths=dropped,
                    error=str(e),
                    exc_info=True,
                )
            else:
                log.error("scip_scheduler.refresh_error", error=str(e), exc_info=True)
