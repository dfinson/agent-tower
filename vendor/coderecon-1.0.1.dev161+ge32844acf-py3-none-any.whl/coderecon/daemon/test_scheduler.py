"""Background test scheduler — run affected tests after indexing settles.

Hooks into BackgroundIndexer's on_complete callback via AnalysisPipeline.
After incremental indexing completes, starts an idle timer. When no further
indexing activity occurs within the idle window, discovers affected tests
via the reachability graph and runs them. Results are persisted to a
``background_test_runs`` table so checkpoint can read them instead of
re-running.

Design constraints:
  - Tests run ONCE per idle window, not per save.
  - A new save cancels any pending test run (results would be stale).
  - Only one test run at a time — concurrent runs are suppressed.
  - Test execution is fire-and-forget from the pipeline's perspective.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from coderecon.index.ops import IndexCoordinatorEngine, IndexStats
    from coderecon.testing.ops import TestOps

log = structlog.get_logger(__name__)


@dataclass
class BackgroundTestRun:
    """Result of a background test run, persisted for checkpoint to read."""

    epoch: int
    changed_files: list[str]
    affected_targets: int
    passed: int
    failed: int
    error: int
    skipped: int
    status: str  # "passed", "failed", "error", "no_targets"
    duration_sec: float
    started_at: float
    failures: list[dict[str, Any]] = field(default_factory=list)


class TestScheduler:
    """Schedules background test runs after indexing idle periods.

    Lifecycle:
        1. Call ``on_index_complete`` after each indexing batch
        2. Accumulates changed file paths across batches
        3. When idle timer fires, run affected tests
        4. Results persisted for checkpoint cache reads
        5. New indexing resets the timer and accumulates more paths
    """

    def __init__(
        self,
        coordinator: IndexCoordinatorEngine,
        test_ops: TestOps,
        repo_root: Path,
        idle_delay_sec: float,
    ) -> None:
        self._coordinator = coordinator
        self._test_ops = test_ops
        self._repo_root = repo_root
        self._idle_delay_sec = idle_delay_sec
        self._timer_task: asyncio.Task[None] | None = None
        self._running = False
        self._run_lock = asyncio.Lock()
        # Accumulate changed paths across debounce batches
        self._pending_paths: set[str] = set()
        self._last_run: BackgroundTestRun | None = None
        # Monotonic generation counter — incremented on each new save batch.
        # A running test compares its generation to the current value;
        # if they differ, its results are stale and it should abort.
        self._generation: int = 0
        # True while inside _run_affected_tests — prevents cancel() from
        # injecting CancelledError into test subprocess tasks.
        self._in_run: bool = False

    def start(self) -> None:
        """Mark scheduler as active.

        Ensures the ``background_test_runs`` table exists before
        accepting work.  Raises on DB errors — caller should not
        start the scheduler if the DB is broken.
        """
        _ensure_table(self._coordinator)
        self._running = True
        log.debug("test_scheduler.started", idle_delay=self._idle_delay_sec)

    async def stop(self) -> None:
        """Cancel any pending timer and stop."""
        self._running = False
        if self._timer_task is not None and not self._timer_task.done():
            self._timer_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._timer_task
        self._timer_task = None
        # Bump generation so any in-flight run sees itself as stale
        self._generation += 1
        log.debug("test_scheduler.stopped")

    async def on_index_complete(self, stats: IndexStats, paths: list[Path]) -> None:  # noqa: ARG002
        """Called after each indexing batch completes.

        Accumulates changed paths and resets the idle timer.
        MUST return quickly — the indexer awaits callbacks serially.
        """
        if not self._running:
            return

        # Bump generation — any in-flight test run is now stale.
        # The running test will notice at the next generation check
        # and restore its paths without needing cancellation.
        self._generation += 1

        # Accumulate relative paths
        for p in paths:
            try:
                rel = str(p.relative_to(self._repo_root))
            except ValueError:
                rel = str(p)
            self._pending_paths.add(rel)

        # Cancel existing idle timer ONLY if it hasn't started running yet.
        # Once the timer fires and enters _run_affected_tests, we let it
        # finish naturally — the generation check will discard stale results.
        # Cancelling mid-run would inject CancelledError into test_ops.run(),
        # orphaning subprocess tasks and losing paths.
        if (
            self._timer_task is not None
            and not self._timer_task.done()
            and not self._in_run
        ):
            self._timer_task.cancel()

        # Start new idle timer
        self._timer_task = asyncio.create_task(self._idle_then_run())

    async def _idle_then_run(self) -> None:
        """Wait for idle period, then run affected tests."""
        try:
            await asyncio.sleep(self._idle_delay_sec)
        except asyncio.CancelledError:
            return

        if not self._running:
            return

        # Snapshot the generation at the time we start.
        # If it changes during discovery/execution, our results are stale.
        gen = self._generation

        if self._run_lock.locked():
            # Another run is in progress. Don't block — it will notice
            # the new generation via its own checks and bail out.
            # After it finishes, _maybe_reschedule will start a new timer.
            log.debug("test_scheduler.run_already_in_progress")
            return

        self._in_run = True
        try:
            async with self._run_lock:
                await self._run_affected_tests(gen)
        finally:
            self._in_run = False
            # If new paths arrived while we were running (or paths were
            # restored due to staleness), start a new idle timer so they
            # get picked up.
            self._maybe_reschedule()

    def _maybe_reschedule(self) -> None:
        """If pending paths exist and no timer is active, start a new one."""
        if not self._running or not self._pending_paths:
            return
        if self._timer_task is not None and not self._timer_task.done():
            return  # timer already scheduled
        self._timer_task = asyncio.create_task(self._idle_then_run())
        log.debug("test_scheduler.rescheduled", pending=len(self._pending_paths))

    async def _run_affected_tests(self, gen: int) -> None:
        """Discover and run tests affected by accumulated changes.

        Args:
            gen: Generation snapshot — if ``self._generation`` has advanced
                 past this value at any await point, a new save arrived and
                 our results would be stale. We restore paths and bail out.
        """
        # Atomically grab pending paths — but keep a copy for restoration
        changed = list(self._pending_paths)
        self._pending_paths.clear()

        if not changed:
            return

        epoch = self._coordinator.current_epoch
        t0 = time.time()

        log.info(
            "test_scheduler.run_starting",
            changed_files=len(changed),
        )

        try:
            # Use the import graph to find affected test targets
            graph_result = await self._coordinator.get_affected_test_targets(changed)

            if self._generation != gen:
                self._pending_paths.update(changed)
                log.info("test_scheduler.preempted_during_discovery")
                return

            affected_paths = set(graph_result.test_files)

            if not affected_paths:
                self._last_run = BackgroundTestRun(
                    epoch=epoch,
                    changed_files=changed,
                    affected_targets=0,
                    passed=0, failed=0, error=0, skipped=0,
                    status="no_targets",
                    duration_sec=time.time() - t0,
                    started_at=t0,
                )
                log.info("test_scheduler.no_affected_tests")
                _persist_run(self._coordinator, self._last_run)
                return

            # Discover all test targets
            discover_result = await self._test_ops.discover(paths=None)
            all_targets = discover_result.targets or []

            # Filter to affected targets
            from coderecon.mcp.tools.checkpoint_helpers import (
                _target_matches_affected_files,
            )
            filtered = [
                t for t in all_targets
                if _target_matches_affected_files(t, affected_paths, self._repo_root)
            ]

            if not filtered:
                self._last_run = BackgroundTestRun(
                    epoch=epoch,
                    changed_files=changed,
                    affected_targets=0,
                    passed=0, failed=0, error=0, skipped=0,
                    status="no_targets",
                    duration_sec=time.time() - t0,
                    started_at=t0,
                )
                log.info("test_scheduler.no_matching_targets")
                _persist_run(self._coordinator, self._last_run)
                return

            # Check again: has a new save arrived while we were discovering?
            if self._generation != gen:
                self._pending_paths.update(changed)
                log.info("test_scheduler.preempted_before_run")
                return

            # Run the tests with the runner's own timeout as a hard ceiling
            target_ids = [t.target_id for t in filtered]
            try:
                test_result = await asyncio.wait_for(
                    self._test_ops.run(
                        targets=target_ids,
                        coverage=True,
                        fail_fast=False,
                    ),
                    timeout=self._test_ops._timeout_sec,  # noqa: SLF001 — use the configured ceiling
                )
            except TimeoutError:
                self._last_run = BackgroundTestRun(
                    epoch=epoch,
                    changed_files=changed,
                    affected_targets=len(filtered),
                    passed=0, failed=0, error=0, skipped=0,
                    status="timeout",
                    duration_sec=time.time() - t0,
                    started_at=t0,
                )
                _persist_run(self._coordinator, self._last_run)
                log.warning(
                    "test_scheduler.run_timeout",
                    targets=len(filtered),
                    timeout_sec=self._test_ops._timeout_sec,  # noqa: SLF001
                )
                return

            # If generation advanced during test execution, results are stale
            if self._generation != gen:
                self._pending_paths.update(changed)
                log.info("test_scheduler.stale_after_run")
                return

            # Parse results
            rs = test_result.run_status
            passed = rs.progress.cases.passed if rs and rs.progress else 0
            failed = rs.progress.cases.failed if rs and rs.progress else 0
            errors = rs.progress.cases.errors if rs and rs.progress else 0
            skipped = rs.progress.cases.skipped if rs and rs.progress else 0

            # Guard: if nothing actually executed, don't record as "passed".
            # This catches missing runner packs, broken environments, etc.
            total_ran = passed + failed + errors
            if total_ran == 0:
                self._last_run = BackgroundTestRun(
                    epoch=epoch,
                    changed_files=changed,
                    affected_targets=len(filtered),
                    passed=0, failed=0, error=0, skipped=skipped,
                    status="no_results",
                    duration_sec=time.time() - t0,
                    started_at=t0,
                )
                _persist_run(self._coordinator, self._last_run)
                log.warning(
                    "test_scheduler.no_test_cases_ran",
                    targets=len(filtered),
                    agentic_hint=test_result.agentic_hint,
                )
                return

            failures: list[dict[str, Any]] = []
            if rs and rs.failures:
                for f in rs.failures:
                    failures.append({
                        "name": f.name,
                        "path": f.path,
                        "line": f.line,
                        "message": f.message,
                    })

            status = "passed" if failed == 0 and errors == 0 else "failed"

            self._last_run = BackgroundTestRun(
                epoch=epoch,
                changed_files=changed,
                affected_targets=len(filtered),
                passed=passed,
                failed=failed,
                error=errors,
                skipped=skipped,
                status=status,
                duration_sec=time.time() - t0,
                started_at=t0,
                failures=failures,
            )

            _persist_run(self._coordinator, self._last_run)

            log.info(
                "test_scheduler.run_complete",
                targets=len(filtered),
                passed=passed,
                failed=failed,
                errors=errors,
                duration_sec=round(time.time() - t0, 1),
            )

        except Exception:
            log.error("test_scheduler.run_error", exc_info=True)
            self._last_run = BackgroundTestRun(
                epoch=epoch,
                changed_files=changed,
                affected_targets=0,
                passed=0, failed=0, error=0, skipped=0,
                status="error",
                duration_sec=time.time() - t0,
                started_at=t0,
            )
            try:
                _persist_run(self._coordinator, self._last_run)
            except Exception:
                log.error("test_scheduler.persist_error_status_failed", exc_info=True)

    @property
    def last_run(self) -> BackgroundTestRun | None:
        """Most recent background test run result."""
        return self._last_run

    @property
    def is_running(self) -> bool:
        """Whether a test run is currently in progress."""
        return self._run_lock.locked()

    @property
    def is_pending(self) -> bool:
        """Whether a test run is pending (idle timer active)."""
        return (
            self._timer_task is not None
            and not self._timer_task.done()
        )


def _ensure_table(coordinator: IndexCoordinatorEngine) -> None:
    """Create ``background_test_runs`` if it doesn't exist.

    Called once at scheduler startup.  Uses CREATE TABLE IF NOT EXISTS
    so it's safe to call repeatedly and doesn't depend on alembic
    migration state.
    """
    from sqlalchemy import text

    with coordinator.db.engine.begin() as conn:
        conn.execute(
            text("""\
                CREATE TABLE IF NOT EXISTS background_test_runs (
                    epoch          INTEGER PRIMARY KEY,
                    changed_files  TEXT    NOT NULL,
                    affected_targets INTEGER NOT NULL,
                    passed         INTEGER NOT NULL DEFAULT 0,
                    failed         INTEGER NOT NULL DEFAULT 0,
                    error          INTEGER NOT NULL DEFAULT 0,
                    skipped        INTEGER NOT NULL DEFAULT 0,
                    status         TEXT    NOT NULL,
                    duration_sec   REAL    NOT NULL,
                    started_at     REAL    NOT NULL,
                    failures_json  TEXT
                )
            """),
        )


def _persist_run(
    coordinator: IndexCoordinatorEngine,
    run: BackgroundTestRun,
) -> None:
    """Persist a background test run result to the DB.

    Raises on failure — caller is responsible for handling.
    """
    import json

    from sqlalchemy import text

    with coordinator.db.session() as session:
        session.execute(
            text("""\
                INSERT OR REPLACE INTO background_test_runs
                    (epoch, changed_files, affected_targets,
                     passed, failed, error, skipped,
                     status, duration_sec, started_at, failures_json)
                VALUES
                    (:epoch, :changed_files, :affected_targets,
                     :passed, :failed, :error, :skipped,
                     :status, :duration_sec, :started_at, :failures_json)
            """),
            {
                "epoch": run.epoch,
                "changed_files": json.dumps(run.changed_files),
                "affected_targets": run.affected_targets,
                "passed": run.passed,
                "failed": run.failed,
                "error": run.error,
                "skipped": run.skipped,
                "status": run.status,
                "duration_sec": run.duration_sec,
                "started_at": run.started_at,
                "failures_json": json.dumps(run.failures),
            },
        )
        session.commit()


def try_read_background_test_run(
    coordinator: IndexCoordinatorEngine,
    changed_files: list[str],
) -> BackgroundTestRun | None:
    """Read the most recent background test run covering the given files.

    Returns the run if:
      - It's at the current epoch (not stale)
      - Its changed_files are a superset of the requested files
      - Its status is conclusive (``passed`` or ``failed``)

    Returns None for inconclusive runs (``error``, ``timeout``,
    ``no_results``, ``no_targets``) — checkpoint should run tests live.
    """
    import json

    from sqlalchemy import text

    current_epoch = coordinator.current_epoch

    try:
        with coordinator.db.engine.connect() as conn:
            row = conn.execute(
                text("""\
                    SELECT epoch, changed_files, affected_targets,
                           passed, failed, error, skipped,
                           status, duration_sec, started_at, failures_json
                    FROM background_test_runs
                    WHERE epoch = :epoch
                    ORDER BY started_at DESC
                    LIMIT 1
                """),
                {"epoch": current_epoch},
            ).fetchone()

            if row is None:
                return None

            run_changed = set(json.loads(row[1]))
            requested = set(changed_files)

            # The background run must cover all requested files
            if not requested.issubset(run_changed):
                return None

            status = row[7]

            # Only trust conclusive runs — error/timeout/no_results
            # should fall through to live execution
            if status not in ("passed", "failed"):
                return None

            return BackgroundTestRun(
                epoch=row[0],
                changed_files=json.loads(row[1]),
                affected_targets=row[2],
                passed=row[3],
                failed=row[4],
                error=row[5],
                skipped=row[6],
                status=row[7],
                duration_sec=row[8],
                started_at=row[9],
                failures=json.loads(row[10]) if row[10] else [],
            )

    except Exception:
        log.error("test_scheduler.read_cached_failed", exc_info=True)
        return None
