"""Additional index creation for query performance.

These indexes complement the basic indexes defined in SQLModel Field()
declarations. They are composite indexes for common query patterns that
cannot be expressed via Field(index=True).

NOTE: These indexes are now also created by the Alembic 0001 migration.
The create_additional_indexes() function is kept for backward compatibility
but is effectively idempotent (CREATE INDEX IF NOT EXISTS).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import text

if TYPE_CHECKING:
    from sqlalchemy import Engine

ADDITIONAL_INDEXES = [
    # Composite indexes for common Tier 1 query patterns
    # DefFact queries by file and name
    "CREATE INDEX IF NOT EXISTS idx_def_facts_file_name ON def_facts(file_id, name)",
    # RefFact queries by file and target
    "CREATE INDEX IF NOT EXISTS idx_ref_facts_file_target ON ref_facts(file_id, target_def_uid)",
    "CREATE INDEX IF NOT EXISTS idx_ref_facts_target_tier ON ref_facts(target_def_uid, ref_tier)",
    # ScopeFact queries by file
    "CREATE INDEX IF NOT EXISTS idx_scope_facts_file ON scope_facts(file_id)",
    # ImportFact queries by file
    "CREATE INDEX IF NOT EXISTS idx_import_facts_file ON import_facts(file_id)",
    # LocalBindFact queries by scope
    "CREATE INDEX IF NOT EXISTS idx_local_bind_facts_scope ON local_bind_facts(scope_id)",
    # ExportSurface queries by unit
    "CREATE INDEX IF NOT EXISTS idx_export_surfaces_unit ON export_surfaces(unit_id)",
    # Context queries by name and status
    "CREATE INDEX IF NOT EXISTS idx_contexts_family_status ON contexts(language_family, probe_status)",
    # AnchorGroup queries by unit (not file)
    "CREATE INDEX IF NOT EXISTS idx_anchor_groups_unit ON anchor_groups(unit_id)",
    # TestCoverageFact queries by target def and staleness
    "CREATE INDEX IF NOT EXISTS idx_test_coverage_target_stale ON test_coverage_facts(target_def_uid, stale)",
    "CREATE INDEX IF NOT EXISTS idx_test_coverage_test_id ON test_coverage_facts(test_id)",
    # LintStatusFact queries by file and tool
    "CREATE INDEX IF NOT EXISTS idx_lint_status_file_tool ON lint_status_facts(file_path, tool_id)",
    # EndpointFact queries by url pattern and kind
    "CREATE INDEX IF NOT EXISTS idx_endpoint_facts_url ON endpoint_facts(url_pattern, kind)",
    # DocCrossRef queries by target
    "CREATE INDEX IF NOT EXISTS idx_doc_cross_refs_target ON doc_cross_refs(target_def_uid)",
    # CallEdge composite for batch CTE traversal (callee lookup)
    "CREATE INDEX IF NOT EXISTS idx_call_edges_callee ON call_edges(callee_def_uid)",
]

def create_additional_indexes(engine: Engine) -> None:
    """Create additional composite indexes for Tier 1 fact tables."""
    with engine.connect() as conn:
        for sql in ADDITIONAL_INDEXES:
            conn.execute(text(sql))
        conn.commit()

def drop_additional_indexes(engine: Engine) -> None:
    """Drop additional indexes (for testing/reset)."""
    index_names = [
        "idx_def_facts_file_name",
        "idx_ref_facts_file_target",
        "idx_ref_facts_target_tier",
        "idx_scope_facts_file",
        "idx_import_facts_file",
        "idx_local_bind_facts_scope",
        "idx_export_surfaces_unit",
        "idx_contexts_family_status",
        "idx_anchor_groups_unit",
    ]
    with engine.connect() as conn:
        for name in index_names:
            conn.execute(text(f"DROP INDEX IF EXISTS {name}"))
        conn.commit()
