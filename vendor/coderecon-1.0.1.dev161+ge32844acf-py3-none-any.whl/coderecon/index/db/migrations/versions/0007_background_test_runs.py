"""add background_test_runs table

Revision ID: 0007
Revises: 0006
Create Date: 2026-07-12

Persists results of background test executions triggered after indexing.
Checkpoint reads this table instead of re-running tests when results
are available at the current epoch.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0007"
down_revision: str = "0006"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    tables = inspector.get_table_names()

    if "background_test_runs" not in tables:
        op.create_table(
            "background_test_runs",
            sa.Column("epoch", sa.Integer, primary_key=True),
            sa.Column("changed_files", sa.Text, nullable=False),
            sa.Column("affected_targets", sa.Integer, nullable=False),
            sa.Column("passed", sa.Integer, nullable=False, server_default="0"),
            sa.Column("failed", sa.Integer, nullable=False, server_default="0"),
            sa.Column("error", sa.Integer, nullable=False, server_default="0"),
            sa.Column("skipped", sa.Integer, nullable=False, server_default="0"),
            sa.Column("status", sa.String, nullable=False),
            sa.Column("duration_sec", sa.Float, nullable=False),
            sa.Column("started_at", sa.Float, nullable=False),
            sa.Column("failures_json", sa.Text),
        )


def downgrade() -> None:
    op.drop_table("background_test_runs")
