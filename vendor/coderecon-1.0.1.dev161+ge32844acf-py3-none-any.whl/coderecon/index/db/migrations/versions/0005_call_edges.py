"""add call_edges table for batch reachability

Revision ID: 0005
Revises: 0004
Create Date: 2026-06-07

Materialized caller→callee edge table enabling batch CTE reachability
instead of per-test-def recursive queries.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0005"
down_revision: str = "0004"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    tables = inspector.get_table_names()

    if "call_edges" not in tables:
        op.create_table(
            "call_edges",
            sa.Column("id", sa.Integer, primary_key=True),
            sa.Column(
                "caller_def_uid",
                sa.String,
                sa.ForeignKey("def_facts.def_uid", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column(
                "callee_def_uid",
                sa.String,
                sa.ForeignKey("def_facts.def_uid", ondelete="CASCADE"),
                nullable=False,
            ),
            sa.Column("edge_kind", sa.String, nullable=False),
            sa.UniqueConstraint(
                "caller_def_uid", "callee_def_uid", name="uq_call_edge"
            ),
        )
        op.create_index(
            "ix_call_edges_caller_def_uid", "call_edges", ["caller_def_uid"]
        )
        op.create_index(
            "ix_call_edges_callee_def_uid", "call_edges", ["callee_def_uid"]
        )
        op.create_index("ix_call_edges_edge_kind", "call_edges", ["edge_kind"])


def downgrade() -> None:
    op.drop_table("call_edges")
