"""add scip_imports table and is_external column

Revision ID: 0006
Revises: 0005
Create Date: 2026-05-11

SCIP import metadata tracking and external def marker.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0006"
down_revision: str = "0005"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    tables = inspector.get_table_names()

    if "scip_imports" not in tables:
        op.create_table(
            "scip_imports",
            sa.Column("id", sa.Integer, primary_key=True),
            sa.Column("language", sa.String, nullable=False),
            sa.Column("scip_path", sa.String, nullable=False),
            sa.Column("imported_at", sa.Float, nullable=False),
            sa.Column("file_count", sa.Integer),
            sa.Column("occurrence_count", sa.Integer),
            sa.Column("refs_matched", sa.Integer),
            sa.Column("refs_external", sa.Integer),
        )
        op.create_index("ix_scip_imports_language", "scip_imports", ["language"])

    # Add is_external column to def_facts if not present
    columns = [c["name"] for c in inspector.get_columns("def_facts")]
    if "is_external" not in columns:
        op.add_column(
            "def_facts",
            sa.Column("is_external", sa.Boolean, server_default=sa.text("0"), nullable=False),
        )


def downgrade() -> None:
    op.drop_table("scip_imports")
    op.drop_column("def_facts", "is_external")
