"""add def_name_parts table for part-based name lookup

Revision ID: 0002
Revises: 0001
Create Date: 2026-05-05

Adds a table that stores camelCase/snake_case split parts of each
definition name, enabling O(log n) query-time lookup of defs whose
name contains a given concept word (e.g., 'sarif' → parse_sarif).
"""

from __future__ import annotations

import re

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0002"
down_revision: str = "0001"
branch_labels: str | None = None
depends_on: str | None = None


def _split_name(name: str) -> list[str]:
    """Split a def name into lowercase constituent parts."""
    parts = re.split(r"[_\W]+", name)
    out: list[str] = []
    for p in parts:
        if not p:
            continue
        # camelCase / PascalCase → separate words
        sub = re.sub(r"(?<!^)(?=[A-Z])", " ", p).lower().split()
        out.extend(sub)
    return [part for part in out if len(part) >= 3]


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    existing = set(inspector.get_table_names())

    if "def_name_parts" not in existing:
        op.create_table(
            "def_name_parts",
            sa.Column("part", sa.String, primary_key=True),
            sa.Column(
                "def_uid", sa.String,
                sa.ForeignKey("def_facts.def_uid", ondelete="CASCADE"),
                primary_key=True,
            ),
        )
        op.create_index(
            "idx_def_name_parts_part", "def_name_parts", ["part"]
        )

    # Backfill from existing def_facts
    conn = op.get_bind()
    rows = conn.execute(sa.text("SELECT def_uid, name FROM def_facts")).fetchall()
    if rows:
        batch: list[dict[str, str]] = []
        seen: set[tuple[str, str]] = set()
        for def_uid, name in rows:
            for part in _split_name(name):
                key = (part, def_uid)
                if key not in seen:
                    seen.add(key)
                    batch.append({"part": part, "def_uid": def_uid})
        if batch:
            tbl = sa.table(
                "def_name_parts",
                sa.column("part", sa.String),
                sa.column("def_uid", sa.String),
            )
            # Insert in chunks to avoid oversized statements
            chunk_size = 500
            for i in range(0, len(batch), chunk_size):
                conn.execute(tbl.insert(), batch[i:i + chunk_size])


def downgrade() -> None:
    op.drop_table("def_name_parts")
