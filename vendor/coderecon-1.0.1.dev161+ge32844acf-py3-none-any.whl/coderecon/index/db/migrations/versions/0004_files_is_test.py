"""add is_test column to files table

Revision ID: 0004
Revises: 0003
Create Date: 2026-05-07

Persists test-file classification so SQL queries can filter without
loading file paths into Python.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0004"
down_revision: str = "0003"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = {col["name"] for col in inspector.get_columns("files")}

    if "is_test" not in columns:
        op.add_column(
            "files",
            sa.Column("is_test", sa.Boolean, nullable=False, server_default="0"),
        )
        op.create_index("ix_files_is_test", "files", ["is_test"])

        # Backfill: mark files with test-like paths
        bind.execute(
            sa.text(
                "UPDATE files SET is_test = 1 "
                "WHERE path LIKE 'test%' OR path LIKE '%/test%' "
                "OR path LIKE '%_test.%' OR path LIKE '%_spec.%'"
            )
        )


def downgrade() -> None:
    op.drop_index("ix_files_is_test", table_name="files")
    op.drop_column("files", "is_test")
