"""add test_reachability_facts table for static call graph walk

Revision ID: 0003
Revises: 0002
Create Date: 2026-05-07

Adds a table storing test→def reachability edges derived from static
call graph analysis.  Populated at index time, calibrated at runtime
when instrumented coverage data becomes available.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "0003"
down_revision: str = "0002"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    existing = set(inspector.get_table_names())

    if "test_reachability_facts" not in existing:
        op.create_table(
            "test_reachability_facts",
            sa.Column("id", sa.Integer, primary_key=True),
            sa.Column(
                "test_def_uid", sa.String,
                sa.ForeignKey("def_facts.def_uid", ondelete="CASCADE"),
                nullable=False, index=True,
            ),
            sa.Column(
                "target_def_uid", sa.String,
                sa.ForeignKey("def_facts.def_uid", ondelete="CASCADE"),
                nullable=False, index=True,
            ),
            sa.Column("source", sa.String, nullable=False, index=True),
            sa.Column("depth", sa.Integer, nullable=False),
            sa.Column("stale", sa.Boolean, nullable=False, default=False, index=True),
            sa.Column("epoch", sa.Integer, nullable=False, index=True),
            sa.UniqueConstraint(
                "test_def_uid", "target_def_uid",
                name="uq_reachability_test_target",
            ),
        )

    # Composite index for the recursive CTE range scan on ref_facts
    existing_indexes = {idx["name"] for idx in inspector.get_indexes("ref_facts")}
    if "idx_ref_facts_file_line" not in existing_indexes:
        op.create_index(
            "idx_ref_facts_file_line", "ref_facts", ["file_id", "start_line"]
        )


def downgrade() -> None:
    op.drop_table("test_reachability_facts")
