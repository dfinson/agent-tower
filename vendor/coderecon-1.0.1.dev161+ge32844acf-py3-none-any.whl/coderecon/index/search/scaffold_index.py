"""Per-def scaffold BM25 index — tantivy-backed search over anglicised scaffolds.

Provides per-definition BM25 scoring (as opposed to the file-level lexical
index in ``lexical.py``).  Each document is a single DefFact's scaffold
text (the same text used for SPLADE encoding), keyed by ``def_uid``.

This enables the B harvester to rank individual definitions by BM25
relevance instead of assigning a uniform file-level score to all defs
in a file.
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import tantivy

from coderecon.adapters.files.ops import atomic_write_text

# Schema version for the scaffold index.  Bump on schema changes to
# trigger automatic rebuild.
SCAFFOLD_SCHEMA_VERSION = 1


class ScaffoldIndex:
    """BM25 index over per-def scaffold texts.

    Separate from the file-level LexicalIndex.  Stores one document per
    definition with fields:

    - ``def_uid``: unique identifier (stored, exact-match for deletion)
    - ``scaffold``: anglicised scaffold text (tokenized, BM25-scored)
    - ``file_path``: source file path (stored, tokenized for filtering)
    - ``worktree``: worktree discriminator (stored, raw)
    """

    def __init__(self, index_path: Path | str) -> None:
        self.index_path = Path(index_path)
        self._index: tantivy.Index | None = None
        self._schema: tantivy.Schema | None = None
        self._initialized = False
        self._staged_adds: list[dict[str, Any]] = []
        self._staged_removes: list[str] = []  # def_uids to remove

    def _ensure_initialized(self) -> None:
        """Lazily initialize the tantivy index."""
        if self._initialized:
            return

        version_file = self.index_path / "schema_version.json"
        if self.index_path.exists() and version_file.exists():
            try:
                stored = json.loads(version_file.read_text())["version"]
            except (OSError, KeyError, ValueError):
                stored = 0
            if stored != SCAFFOLD_SCHEMA_VERSION:
                shutil.rmtree(self.index_path, ignore_errors=True)
        elif self.index_path.exists() and any(self.index_path.iterdir()):
            shutil.rmtree(self.index_path, ignore_errors=True)

        schema_builder = tantivy.SchemaBuilder()
        # Exact-match key for upsert/deletion.
        schema_builder.add_text_field("def_uid", stored=True, tokenizer_name="raw")
        # The scaffold text — this is what gets BM25-scored.
        schema_builder.add_text_field("scaffold", stored=False, tokenizer_name="default")
        # File path (stored for result grouping, tokenized for path-prefix queries).
        schema_builder.add_text_field("file_path", stored=True, tokenizer_name="default")
        # Worktree discriminator for multi-worktree support.
        schema_builder.add_text_field("worktree", stored=True, tokenizer_name="raw")
        self._schema = schema_builder.build()

        self.index_path.mkdir(parents=True, exist_ok=True)
        self._index = tantivy.Index(self._schema, path=str(self.index_path))
        self._initialized = True
        atomic_write_text(version_file, json.dumps({"version": SCAFFOLD_SCHEMA_VERSION}))

    # ── Write API ────────────────────────────────────────────────

    def stage_def(
        self,
        def_uid: str,
        scaffold: str,
        file_path: str,
        worktree: str = "main",
    ) -> None:
        """Stage a scaffold document for later atomic commit."""
        self._staged_adds.append({
            "def_uid": def_uid,
            "scaffold": scaffold,
            "file_path": file_path,
            "worktree": worktree,
        })

    def stage_remove(self, def_uid: str) -> None:
        """Stage a def removal for later atomic commit."""
        self._staged_removes.append(def_uid)

    def has_staged_changes(self) -> bool:
        return bool(self._staged_adds or self._staged_removes)

    def staged_count(self) -> tuple[int, int]:
        return len(self._staged_adds), len(self._staged_removes)

    def commit_staged(self) -> int:
        """Commit all staged scaffold documents atomically."""
        if not self.has_staged_changes():
            return 0
        self._ensure_initialized()
        writer = self._index.writer()
        count = 0
        try:
            for uid in self._staged_removes:
                writer.delete_documents("def_uid", uid)
                count += 1
            for doc_data in self._staged_adds:
                writer.delete_documents("def_uid", doc_data["def_uid"])
                doc = tantivy.Document()
                doc.add_text("def_uid", doc_data["def_uid"])
                doc.add_text("scaffold", doc_data["scaffold"])
                doc.add_text("file_path", doc_data["file_path"])
                doc.add_text("worktree", doc_data["worktree"])
                writer.add_document(doc)
                count += 1
            writer.commit()
        except BaseException:
            self._staged_adds.clear()
            self._staged_removes.clear()
            raise
        self._staged_adds.clear()
        self._staged_removes.clear()
        return count

    def discard_staged(self) -> int:
        """Discard staged changes."""
        count = len(self._staged_adds) + len(self._staged_removes)
        self._staged_adds.clear()
        self._staged_removes.clear()
        return count

    # ── Read API ─────────────────────────────────────────────────

    def score_defs_bm25(
        self,
        query: str,
        *,
        limit: int = 500,
        worktrees: list[str] | None = None,
    ) -> dict[str, float]:
        """Score definitions by BM25 on their scaffold text.

        Returns {def_uid: bm25_score} for all defs scoring > 0.
        """
        self._ensure_initialized()

        effective_wt = worktrees or ["main"]
        full_query = _build_scaffold_query(query, effective_wt)
        if full_query is None:
            return {}

        searcher = self._index.searcher()
        try:
            parsed = self._index.parse_query(full_query, ["scaffold"])
        except ValueError:
            # Fallback: strip all syntax and retry
            from coderecon.index.search.lexical_search import _escape_query
            escaped = _escape_query(query)
            wt_filter = " OR ".join(
                f'worktree:"{wt}"' for wt in effective_wt
            )
            fallback = f"({wt_filter}) AND ({escaped})"
            try:
                parsed = self._index.parse_query(fallback, ["scaffold"])
            except ValueError:
                return {}

        top_docs = searcher.search(parsed, limit=limit).hits

        scores: dict[str, float] = {}
        for bm25_score, doc_addr in top_docs:
            doc = searcher.doc(doc_addr)
            uid = doc.get_first("def_uid") or ""
            if uid:
                # Keep max score per def_uid (handles worktree overlaps)
                if float(bm25_score) > scores.get(uid, 0.0):
                    scores[uid] = float(bm25_score)

        return scores

    def reload(self) -> None:
        """Reload index to see latest changes."""
        if self._index:
            self._index.reload()

    def doc_count(self) -> int:
        """Return number of documents in the index."""
        self._ensure_initialized()
        searcher = self._index.searcher()
        return int(searcher.num_docs)

    def clear(self) -> None:
        """Clear all documents from the index."""
        self._ensure_initialized()
        writer = self._index.writer()
        writer.delete_all_documents()
        writer.commit()


# ── Query builder ────────────────────────────────────────────────

import re

_SYNTAX_CHARS = set(r'+-&|!(){}[]^~*?:\\/".@,;')


def _clean_token(tok: str) -> str:
    return "".join(ch for ch in tok if ch not in _SYNTAX_CHARS)


def _build_scaffold_query(
    query: str,
    worktrees: list[str],
) -> str | None:
    """Build an OR-joined BM25 query for scaffold search."""
    raw_tokens = re.findall(r'"[^"]+"|\S+', query)
    if not raw_tokens:
        return None

    parts: list[str] = []
    for token in raw_tokens:
        upper = token.upper()
        if upper in ("AND", "OR", "NOT"):
            continue
        if token.startswith('"') and token.endswith('"'):
            cleaned = _clean_token(token[1:-1])
            if cleaned:
                parts.append(f'"{cleaned}"')
        else:
            cleaned = _clean_token(token)
            if cleaned and len(cleaned) >= 2:
                parts.append(cleaned)

    if not parts:
        return None

    or_query = " OR ".join(parts)
    wt_filter = " OR ".join(
        'worktree:"{}"'.format(wt.replace("\\", "\\\\").replace('"', '\\"'))
        for wt in worktrees
    )
    return f"({wt_filter}) AND ({or_query})"
