"""SPLADE sparse retrieval — scaffold building, encoding, and storage.

Uses splade-mini (rasyosef/splade-mini, 11M params, Apache-2.0) via a
pre-exported ONNX model to produce sparse term-weight vectors for each
DefFact.  Vectors are stored in SQLite as compact JSON and queried via
sparse dot-product at retrieval time.

Runtime dependencies: ``onnxruntime`` + ``tokenizers`` (~55 MB total).
No torch or sentence-transformers required.

The scaffold builder converts structured index facts into anglicised text
that SPLADE can encode effectively.  Field order follows measured marginal
recall from the recon-lab bakeoff (calls +4.8%, uses, mentions +1.5%,
sig +0.7%, doc +0.2%).
"""

from __future__ import annotations

import json
import os
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import onnxruntime as ort
from onnxruntime.capi.onnxruntime_pybind11_state import Fail as OrtFail
from onnxruntime.capi.onnxruntime_pybind11_state import RuntimeException as OrtRuntimeException
import structlog
from tokenizers import Tokenizer

from coderecon.config.constants import BYTES_PER_MB

log = structlog.get_logger(__name__)

# ── ONNX provider selection ──────────────────────────────────────

# Cache: None = not checked, True/False = result
_gpu_active: bool | None = None

def _ensure_cuda_lib_path() -> None:
    """Make cuDNN / cuBLAS findable for onnxruntime-gpu.
    On Linux, ``onnxruntime-gpu`` needs ``libcudnn.so.9`` at runtime.
    We search pip-installed nvidia packages and well-known system paths,
    then **preload** the library via ctypes so ``dlopen`` finds it even
    when LD_LIBRARY_PATH wasn't set at process start.
    This must be called **before** the first ``InferenceSession`` creation.
    """
    import ctypes
    import os
    import sys
    if sys.platform != "linux":
        return
    lib_dirs: list[str] = []
    # 1. Pip-installed nvidia packages (canonical for venv-based installs)
    for pkg in ("nvidia.cudnn", "nvidia.cublas", "nvidia.cuda_nvrtc"):
        try:
            mod = __import__(pkg, fromlist=["__path__"])
            lib_dir = str(Path(mod.__path__[0]) / "lib")
            if Path(lib_dir).is_dir():
                lib_dirs.append(lib_dir)
        except ImportError:
            log.debug("cuda_pkg_not_available", pkg=pkg)
    # 2. Well-known system CUDA paths
    if not lib_dirs:
        candidates = [
            "/usr/local/cuda/lib64",
            "/usr/lib/x86_64-linux-gnu",
        ]
        # Ollama bundles cuDNN 9 + CUDA libs; search its known directories
        for p in sorted(Path("/usr/local/lib/ollama").glob("*cuda*"), reverse=True):
            if p.is_dir():
                candidates.insert(0, str(p))
        for candidate in candidates:
            cudnn = Path(candidate) / "libcudnn.so.9"
            if cudnn.exists():
                lib_dirs.append(candidate)
                break
    if not lib_dirs:
        return
    # Update LD_LIBRARY_PATH for any child processes
    existing = os.environ.get("LD_LIBRARY_PATH", "")
    existing_parts = set(existing.split(":")) if existing else set()
    new_parts = [d for d in lib_dirs if d not in existing_parts]
    if new_parts:
        os.environ["LD_LIBRARY_PATH"] = ":".join(new_parts + ([existing] if existing else []))
    # Preload libcudnn.so.9 so dlopen() finds it in the current process
    for d in lib_dirs:
        cudnn_path = Path(d) / "libcudnn.so.9"
        if cudnn_path.exists():
            try:
                ctypes.CDLL(str(cudnn_path), mode=ctypes.RTLD_GLOBAL)
            except OSError:
                log.debug("cudnn_preload_failed", path=str(cudnn_path), exc_info=True)
            break

def _arena_limit(vram_bytes: int) -> int:
    """Maximum VRAM the CUDA BFC arena may allocate.

    Reserves 15 % for the CUDA context, display compositor, and other
    GPU consumers so the arena never exhausts physical VRAM.  The
    returned value is set as ``gpu_mem_limit`` on the CUDA EP and used
    by :func:`_compute_gpu_batch_size` to derive the activation budget.
    """
    return int(vram_bytes * 0.85)


def _select_onnx_providers(
    vram_bytes: int | None = None,
) -> list[str | tuple[str, dict[str, Any]]]:
    """Select the best available ONNX Runtime execution providers.
    Tries GPU providers first (CUDA, ROCm, CoreML), falls back to CPU.
    Respects CODERECON_ONNX_DEVICE env var to force a specific provider.
    When *vram_bytes* is given and CUDA is available, configures the BFC
    arena to use ``kSameAsRequested`` (no power-of-two overshoot) and
    caps ``gpu_mem_limit`` via :func:`_arena_limit` so the arena never
    grabs everything.
    """
    import os
    forced = os.environ.get("CODERECON_ONNX_DEVICE", "").lower()
    if forced == "cpu":
        return ["CPUExecutionProvider"]
    # Ensure CUDA libs are findable before querying providers
    _ensure_cuda_lib_path()
    available = set(ort.get_available_providers())
    providers: list[str | tuple[str, dict[str, Any]]] = []
    # Prefer CUDA > ROCm > CoreML > CPU
    if "CUDAExecutionProvider" in available:
        cuda_opts: dict[str, Any] = {
            # kSameAsRequested = 1: allocate exactly the amount needed,
            # not next-power-of-two.  Prevents the arena from claiming
            # all VRAM on a single large allocation attempt.
            "arena_extend_strategy": "kSameAsRequested",
        }
        if vram_bytes:
            cuda_opts["gpu_mem_limit"] = _arena_limit(vram_bytes)
        providers.append(("CUDAExecutionProvider", cuda_opts))
    if "ROCMExecutionProvider" in available:
        providers.append("ROCMExecutionProvider")
    if "CoreMLExecutionProvider" in available:
        providers.append("CoreMLExecutionProvider")
    # Always include CPU as fallback
    providers.append("CPUExecutionProvider")
    return providers

def is_gpu_active() -> bool:
    """Return True if the last ONNX session loaded a GPU provider.
    Only valid after at least one encoder has been loaded.
    """
    return _gpu_active is True

# ── Constants ────────────────────────────────────────────────────

MODEL_VERSION = "splade-mini-onnx-v1"

# ── Adaptive batch sizing ────────────────────────────────────────
#
# GPU: no hardcoded cap.  OOM recovery (halving + watermark) self-
# tunes the effective batch size.  Arena shrinkage via RunOptions
# prevents BFC arena fragmentation across runs with variable shapes
# (ORT issue #11627).
#
# CPU: tensor budget derived from the actual L3 cache size (queried
# from sysfs on Linux).  Batch cap derived from available CPU count
# (os.sched_getaffinity) — ORT intra-op parallelism doesn't benefit
# beyond the number of available cores.


def _query_l3_cache_bytes() -> int | None:
    """Query the L3 cache size from sysfs (Linux).

    Returns None if the sysfs entry doesn't exist or can't be parsed.
    """
    try:
        raw = Path("/sys/devices/system/cpu/cpu0/cache/index3/size").read_text().strip()
        # Format: "24576K" or "32M" — parse the numeric + suffix.
        if raw.endswith("K"):
            return int(raw[:-1]) * 1024
        if raw.endswith("M"):
            return int(raw[:-1]) * 1024 * 1024
        return int(raw)  # bare bytes
    except (OSError, ValueError):
        return None


def _cpu_tensor_budget_bytes() -> int:
    """Return the tensor budget for CPU batching.

    Sized to fit in the L3 cache (queried from sysfs).  Falls back to
    the smallest L3 seen on any Intel/AMD desktop CPU shipping since
    2018 — 8 MB (e.g. Intel i5-8400).
    """
    l3 = _query_l3_cache_bytes()
    if l3 is not None and l3 > 0:
        return l3
    return 8 * BYTES_PER_MB


def _max_batch_size_cpu() -> int:
    """Return the CPU batch cap from available core count.

    ORT distributes intra-op work across available cores.  Batches
    larger than the core count add context-switching overhead without
    additional parallelism.
    """
    try:
        return len(os.sched_getaffinity(0))
    except (AttributeError, OSError):
        # sched_getaffinity unavailable (macOS, some containers).
        return os.cpu_count() or 4

def _query_gpu_vram_bytes() -> int | None:
    """Query total GPU VRAM in bytes via nvidia-smi.
    Returns None if nvidia-smi is unavailable or fails.
    """
    import subprocess
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=memory.total",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            # Output is in MiB, one line per GPU — take the first
            mib = int(result.stdout.strip().split("\n")[0])
            return mib * BYTES_PER_MB
    except (FileNotFoundError, ValueError, subprocess.TimeoutExpired):
        log.debug("nvidia_smi_query_failed", exc_info=True)
    return None


def _query_gpu_memory_used_bytes() -> int | None:
    """Query current GPU memory usage in bytes via nvidia-smi.

    Returns None if nvidia-smi is unavailable or fails.
    """
    import subprocess
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=memory.used",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            mib = int(result.stdout.strip().split("\n")[0])
            return mib * BYTES_PER_MB
    except (FileNotFoundError, ValueError, subprocess.TimeoutExpired):
        log.debug("nvidia_smi_used_query_failed", exc_info=True)
    return None


# ── GPU batch sizing from model architecture ─────────────────────
#
# Architecture constants read from the vendored ONNX model weights
# and confirmed against the upstream config.json
# (https://huggingface.co/rasyosef/splade-mini/raw/main/config.json).
# These are fixed by the model spec, not tunable parameters.
_SPLADE_HIDDEN = 256          # hidden_size  (from LayerNorm.weight shape)
_SPLADE_FFN = 1024            # intermediate_size  (from intermediate dense shape)
_SPLADE_LAYERS = 4            # num_hidden_layers  (from weight name indices 0-3)
_SPLADE_HEADS = 4             # num_attention_heads  (from config.json, H/A=64)
_SPLADE_VOCAB = 30522         # vocab_size  (from config.json, matches BertTokenizer)
_SPLADE_BYTES_PER_EL = 4      # float32  (torch_dtype in config)


def _compute_gpu_batch_size(max_seq_len: int, vram_free: int) -> int:
    """Derive the max GPU batch size from free VRAM and model architecture.

    Two memory components per sample:

    1. **Transformer layers** — attention scores and FFN intermediates::

           M_xfmr = L × 4 × S × (H + A×S + H_ffn)

    2. **MLM head → SPLADE pooling** — the graph produces a chain of
       (S × vocab) tensors (matmul → bias-add → relu → add-1 → log →
       mask-mul → reduce-max).  ORT's graph executor keeps up to 4 of
       these alive simultaneously (op input, op output, and upstream
       buffers awaiting downstream consumers)::

           M_vocab = 4 × 4 × S × V

    A fixed per-run cost (independent of batch size) is subtracted
    first: the ``Transpose`` op creates a ``(V, H)`` copy of the
    decoder weight matrix before the final MatMul::

        M_fixed = V × H × 4

    Solving for B::

        B_max = (V_free − M_fixed) / (M_xfmr + M_vocab)

    All constants are from the model spec (config.json / ONNX weights).
    """
    S = max(1, max_seq_len)
    xfmr_per_sample = (
        _SPLADE_LAYERS
        * _SPLADE_BYTES_PER_EL
        * S
        * (_SPLADE_HIDDEN + _SPLADE_HEADS * S + _SPLADE_FFN)
    )
    vocab_per_sample = (
        4 * _SPLADE_BYTES_PER_EL * S * _SPLADE_VOCAB
    )
    per_sample = xfmr_per_sample + vocab_per_sample
    # Fixed per-run: transposed decoder weight (Transpose op before
    # the final MatMul creates a V×H copy each sess.run()).
    fixed = _SPLADE_VOCAB * _SPLADE_HIDDEN * _SPLADE_BYTES_PER_EL
    available = max(0, vram_free - fixed)
    if per_sample <= 0:
        return 1
    return max(1, available // per_sample)


def _compute_cpu_batch_size(max_seq_len: int) -> int:
    """Derive CPU batch size from L3-cache and core-count constraints.

    Each sample contributes ``seq_len × 3 arrays × 8 bytes`` (int64) to
    the input tensors.  We size the batch so the total tensor fits in
    the L3 cache, capped at the available CPU core count.
    """
    seq = max(1, max_seq_len)
    bytes_per_sample = seq * 3 * 8  # ids + mask + tids, int64
    budget = _cpu_tensor_budget_bytes()
    batch = max(1, budget // bytes_per_sample)
    return min(batch, _max_batch_size_cpu())

# Vendored ONNX model + tokenizer (from coderecon-models-splade package)
from coderecon_models_splade import ONNX_PATH as _ONNX_PATH
from coderecon_models_splade import TOKENIZER_PATH as _TOKENIZER_PATH

# ── Encoder wrapper ──────────────────────────────────────────────

@dataclass
class SpladeEncoder:
    """ONNX-based SPLADE encoder (splade-mini via onnxruntime + tokenizers).
    No torch dependency.  Loads the vendored ONNX model and tokenizer
    from the package data directory.
    """
    onnx_path: Path = _ONNX_PATH
    tokenizer_path: Path = _TOKENIZER_PATH
    _session: ort.InferenceSession | None = field(default=None, repr=False)
    _tokenizer: Tokenizer | None = field(default=None, repr=False)
    _cpu_session: ort.InferenceSession | None = field(default=None, repr=False)
    _vram_bytes: int | None = field(default=None, repr=False)
    _vram_free: int | None = field(default=None, repr=False)
    _oom_batch_ceiling: int | None = field(default=None, repr=False)

    def _refresh_vram_free(self) -> None:
        """Re-measure available VRAM from nvidia-smi.

        Called before session rebuilds so batch sizing uses current VRAM
        state rather than the stale value captured at initial load().
        """
        if not _gpu_active or not self._vram_bytes:
            return
        vram_used = _query_gpu_memory_used_bytes()
        if vram_used is not None:
            limit = _arena_limit(self._vram_bytes)
            self._vram_free = max(0, limit - vram_used)
            log.debug(
                "splade.vram_refreshed",
                extra={"free_mib": self._vram_free // BYTES_PER_MB},
            )

    def _safe_destroy_session(self) -> None:
        """Destroy the CUDA session without risking a SIGABRT.

        The BFC arena destructor can abort() if the CUDA context or the
        WSL2 dxgkrnl paravirtualization layer is in a degraded state
        (e.g. ioctl returning EINVAL during cudaFree).  We isolate the
        destruction in a daemon thread with a timeout — if it hangs or
        aborts, the main process survives and the OS reclaims the GPU
        memory when the orphaned session object is eventually collected.
        """
        session = self._session
        self._session = None
        if session is None:
            return
        import threading

        def _destroy() -> None:
            nonlocal session
            del session

        t = threading.Thread(target=_destroy, daemon=True, name="ort-session-gc")
        t.start()
        t.join(timeout=5.0)
        if t.is_alive():
            log.warning("splade.session_destroy_hung")
        # Explicit gc to reclaim Python-side wrappers regardless.
        import gc
        gc.collect()

    def _make_gpu_session(
        self,
        vram_bytes: int | None = None,
    ) -> ort.InferenceSession:
        """Create a CUDA InferenceSession.

        Each session owns a fresh BFC arena.  By creating a new session
        per batch we prevent dead-allocation buildup across runs with
        different shapes (ORT issue #11627).  When the old session is
        garbage-collected its arena is freed back to the CUDA driver.
        """
        opts = ort.SessionOptions()
        opts.enable_mem_pattern = False
        # Disable memory reuse across runs — required for variable batch
        # sizes. Without this, the CUDA executor caches LayerNorm output
        # buffers from the first run and rejects later runs with different
        # batch dims ("Shape mismatch attempting to re-use buffer").
        opts.enable_mem_reuse = False
        opts.enable_cpu_mem_arena = False
        # Suppress BFC arena fallback warnings — the allocator
        # intentionally falls back to system malloc when a single
        # allocation exceeds the arena's free capacity.
        opts.log_severity_level = 3  # Error
        providers = _select_onnx_providers(vram_bytes=vram_bytes)
        return ort.InferenceSession(
            str(self.onnx_path),
            sess_options=opts,
            providers=providers,
        )
    @staticmethod
    def _validate_model_batch_axis(onnx_path: Path) -> None:
        """Verify the ONNX model has a dynamic batch axis on its output.
        Models with a hardcoded batch dimension (e.g. ``[1, seq, vocab]``)
        cause CUDA buffer-reuse failures when batch > 1.  Fail fast with
        a clear message instead of surfacing a cryptic shape-mismatch
        error at inference time.
        """
        try:
            import onnx
        except ImportError:
            return
        try:
            model = onnx.load(str(onnx_path), load_external_data=False)
        except (OSError, RuntimeError, ValueError):
            log.debug("onnx_model_load_failed", exc_info=True)
            return
        for out in model.graph.output:
            dims = out.type.tensor_type.shape.dim
            if not dims:
                continue
            first = dims[0]
            if first.dim_value and first.dim_value > 0:
                raise RuntimeError(
                    f"SPLADE ONNX model has hardcoded batch dimension "
                    f"({first.dim_value}) on output '{out.name}'. "
                    f"The model must use a dynamic batch axis (dim_param). "
                    f"Re-export the model or update the coderecon-models-splade package."
                )
    def load(self) -> None:
        """Load ONNX session + tokenizer (lazy, auto-detect GPU)."""
        global _gpu_active  # noqa: PLW0603
        if self._session is not None:
            return
        self._validate_model_batch_axis(self.onnx_path)
        # Query VRAM *before* session creation so we can configure
        # gpu_mem_limit on the first session.
        self._vram_bytes = _query_gpu_vram_bytes()
        self._session = self._make_gpu_session(vram_bytes=self._vram_bytes)
        active = self._session.get_providers()
        _gpu_active = any(p != "CPUExecutionProvider" for p in active)
        if _gpu_active:
            _ensure_cuda_lib_path()
            # Measure free VRAM *after* model load — this is what's
            # available for activation tensors.  Capped by the arena
            # limit (gpu_mem_limit) to stay consistent with how much
            # the CUDA EP can actually allocate.
            vram_used = _query_gpu_memory_used_bytes()
            if self._vram_bytes and vram_used is not None:
                limit = _arena_limit(self._vram_bytes)
                self._vram_free = max(0, limit - vram_used)
                log.info(
                    "splade.gpu_vram",
                    extra={
                        "total_mib": self._vram_bytes // BYTES_PER_MB,
                        "free_mib": self._vram_free // BYTES_PER_MB,
                    },
                )
        log.info("splade.loaded", extra={"providers": active, "gpu": _gpu_active})
        self._tokenizer = Tokenizer.from_file(str(self.tokenizer_path))
        self._tokenizer.enable_truncation(max_length=512)
        self._tokenizer.enable_padding()
    def _encode_batch(
        self,
        texts: list[str],
        session: ort.InferenceSession | None = None,
        *,
        pre_encodings: list[Any] | None = None,
    ) -> list[dict[int, float]]:
        """Run a batch of texts through the ONNX model → sparse vectors.
        The ONNX model has SPLADE pooling (ReLU → log1p → max-over-seq)
        baked into the graph, outputting (batch, vocab_size) directly.
        *session* overrides the default session (used by CPU fallback).
        *pre_encodings* supplies already-tokenized encodings to avoid
        redundant tokenization when the caller has pre-tokenized.
        """
        sess = session or self._session
        if sess is None or self._tokenizer is None:
            raise RuntimeError("SPLADE model not loaded: call load() first")
        encodings = pre_encodings if pre_encodings is not None else self._tokenizer.encode_batch(texts)
        ids = np.array([e.ids for e in encodings], dtype=np.int64)
        mask = np.array([e.attention_mask for e in encodings], dtype=np.int64)
        tids = np.zeros_like(ids)
        (raw,) = sess.run(
            None,
            {
                "input_ids": ids,
                "attention_mask": mask,
                "token_type_ids": tids,
            },
        )
        # SPLADE pooling: ReLU → log1p → max-over-sequence
        pooled = np.log1p(np.maximum(raw, 0)).max(axis=1) if raw.ndim == 3 else raw
        results: list[dict[int, float]] = []
        for row in pooled:
            nz = np.nonzero(row)[0]
            results.append({int(idx): float(row[idx]) for idx in nz})
        return results
    def _get_cpu_session(self) -> ort.InferenceSession:
        """Lazily create a CPU-only ONNX session for OOM fallback."""
        if self._cpu_session is None:
            opts = ort.SessionOptions()
            opts.enable_mem_pattern = False
            opts.enable_mem_reuse = False
            opts.enable_cpu_mem_arena = False
            # Suppress BFC arena fallback warnings — the CPU arena
            # intentionally falls back to system malloc when a single
            # allocation exceeds the arena's free capacity.
            opts.log_severity_level = 3  # Error
            self._cpu_session = ort.InferenceSession(
                str(self.onnx_path),
                sess_options=opts,
                providers=["CPUExecutionProvider"],
            )
        return self._cpu_session
    def _encode_batch_safe(
        self,
        texts: list[str],
        *,
        pre_encodings: list[Any] | None = None,
        _session_rebuilt: bool = False,
    ) -> list[dict[int, float]]:
        """Encode with OOM/shape-mismatch recovery.

        On a CUDA OOM error the BFC arena's internal free-lists may be
        fragmented.  Retrying on the *same* session often cascades into
        repeated failures even for smaller batches.

        On CPU, ONNX models with static internal batch dimensions cause
        shape-mismatch errors for batch > 1.  The same halving strategy
        converges to batch=1 which always succeeds.

        Strategy:
        1. Try the batch on the current session.
        2. On OOM/shape-mismatch → halve the batch and retry.
        3. On GPU: create a fresh session **once** for the entire
           recovery tree (subsequent halves reuse it).
        4. If a single item still fails on GPU → CPU fallback.
        """
        try:
            return self._encode_batch(texts, pre_encodings=pre_encodings)
        except (RuntimeError, MemoryError, OrtRuntimeException, OrtFail) as exc:
            err_msg = str(exc).lower()
            is_oom = (
                "out of memory" in err_msg
                or "failed to allocate memory" in err_msg
                or "smaller than requested" in err_msg
            )
            # ONNX buffer reuse fails when batch/sequence dims change
            # between runs.  Treat as transient and halve → CPU-fallback.
            is_shape = "shape mismatch" in err_msg
            if not (is_oom or is_shape):
                raise
            log.warning(
                "splade.encode_retry",
                extra={"batch_size": len(texts), "error": str(exc)[:200]},
            )
            if _gpu_active and not _session_rebuilt:
                # Replace the current session with a fresh one (resets BFC arena).
                # Only rebuild once per recovery tree — subsequent halves
                # reuse the fresh session to avoid O(log N) model reloads.
                self._safe_destroy_session()
                self._refresh_vram_free()
                self._session = self._make_gpu_session(vram_bytes=self._vram_bytes)
                _session_rebuilt = True
            # Record half the OOM batch size as the ceiling — this is
            # the size that the halving recovery will actually try next,
            # so the outer loop can jump straight to a working size.
            half = max(1, len(texts) // 2)
            if self._oom_batch_ceiling is None or half < self._oom_batch_ceiling:
                self._oom_batch_ceiling = half
                log.info(
                    "splade.oom_ceiling",
                    extra={"failed_at": len(texts), "ceiling": half},
                )
            if len(texts) > 1:
                mid = len(texts) // 2
                left_enc = pre_encodings[:mid] if pre_encodings is not None else None
                right_enc = pre_encodings[mid:] if pre_encodings is not None else None
                return self._encode_batch_safe(
                    texts[:mid],
                    pre_encodings=left_enc,
                    _session_rebuilt=_session_rebuilt,
                ) + self._encode_batch_safe(
                    texts[mid:],
                    pre_encodings=right_enc,
                    _session_rebuilt=_session_rebuilt,
                )
            if _gpu_active:
                # Single item OOM on GPU — fall back to CPU
                log.warning("splade.cpu_fallback", extra={"text_len": len(texts[0])})
                return self._encode_batch(
                    texts,
                    session=self._get_cpu_session(),
                    pre_encodings=pre_encodings,
                )
            raise
    def encode_documents(
        self,
        texts: list[str],
        *,
        progress_cb: Callable[[int, int], None] | None = None,
    ) -> list[dict[int, float]]:
        """Encode document texts → sparse vectors (batched ONNX inference).

        Tokenizes once up-front and carries the encodings through to
        inference, avoiding redundant re-tokenization.  Sorts by token
        length so similar-length texts share a batch (minimising pad
        waste).  Batch size is computed per-chunk from the longest
        sequence in that chunk:

        * **GPU:** quadratic attention model sized to VRAM with measured
          model overhead.
        * **CPU:** L3-cache-friendly tensor budget.

        OOM errors are caught and recovered by halving the batch (with
        a single session rebuild), with a final CPU fallback for single
        items.

        *progress_cb(encoded, total)* is called after each batch with
        the cumulative number of items encoded so far.
        """
        self.load()
        if not texts:
            return []
        if self._tokenizer is None:
            raise RuntimeError("SPLADE tokenizer not loaded after load()")
        # Tokenize once — used for sorting AND passed into _encode_batch
        all_encodings = self._tokenizer.encode_batch(texts)
        tok_lengths = [len(enc.ids) for enc in all_encodings]
        # Sort by token count → similar lengths in each batch → less padding
        sorted_indices = sorted(range(len(texts)), key=lambda i: tok_lengths[i])
        ordered_vecs: list[tuple[int, dict[int, float]]] = []
        pos = 0
        batch_num = 0
        encode_t0 = time.monotonic()
        # Track the seq length the current GPU session was sized for.
        # Only rebuild when the longest sequence in the next batch
        # exceeds the session's capacity — consecutive batches with
        # similar lengths reuse the same session (avoids ~0.5s per
        # rebuild; ORT #11627 fragmentation only occurs when shapes
        # actually change).
        _session_seq_len: int = 0
        while pos < len(sorted_indices):
            remaining = len(sorted_indices) - pos
            # The longest sequence in a candidate batch is at the end
            # (items are sorted ascending by length).
            if _gpu_active:
                # Peek at the longest sequence in the candidate window
                # to get a conservative estimate (worst-case padding).
                peek_end = min(remaining, 512)
                longest_seq = tok_lengths[sorted_indices[pos + peek_end - 1]]
                # Rebuild the session only when the longest sequence
                # exceeds what the current session was sized for.
                # This avoids ~0.5s session-rebuild overhead per batch
                # when consecutive batches have similar token lengths
                # (common for doc chunks that cluster near max length).
                if longest_seq > _session_seq_len or self._session is None:
                    if self._session is not None:
                        self._safe_destroy_session()
                        self._refresh_vram_free()
                    self._session = self._make_gpu_session(
                        vram_bytes=self._vram_bytes,
                    )
                    _session_seq_len = longest_seq
                if self._vram_free is not None and self._vram_free > 0:
                    bs = min(
                        remaining,
                        _compute_gpu_batch_size(longest_seq, self._vram_free),
                    )
                else:
                    # No VRAM info — conservative fallback: 1 item.
                    bs = 1
                # Respect OOM watermark — never exceed a size that
                # already failed at this seq length or longer.
                if self._oom_batch_ceiling is not None:
                    bs = min(bs, self._oom_batch_ceiling)
            else:
                cpu_cap = _max_batch_size_cpu()
                peek_end = min(remaining, cpu_cap)
                longest_seq = tok_lengths[sorted_indices[pos + peek_end - 1]]
                bs = min(remaining, _compute_cpu_batch_size(longest_seq))
            batch_idx = sorted_indices[pos : pos + bs]
            batch_texts = [texts[i] for i in batch_idx]
            batch_enc = [all_encodings[i] for i in batch_idx]
            bt0 = time.monotonic()
            batch_vecs = self._encode_batch_safe(batch_texts, pre_encodings=batch_enc)
            bt1 = time.monotonic()
            batch_num += 1
            log.info(
                "splade.batch batch=%d size=%d pos=%d/%d longest_tok=%d elapsed=%.3fs cumul=%.1fs",
                batch_num, bs, pos, len(sorted_indices),
                tok_lengths[batch_idx[-1]],
                bt1 - bt0, bt1 - encode_t0,
            )
            for orig_idx, vec in zip(batch_idx, batch_vecs, strict=True):
                ordered_vecs.append((orig_idx, vec))
            pos += bs
            if progress_cb is not None:
                progress_cb(pos, len(sorted_indices))
        # Restore original order
        ordered_vecs.sort(key=lambda x: x[0])
        return [vec for _, vec in ordered_vecs]
    def encode_queries(self, texts: list[str]) -> list[dict[int, float]]:
        """Encode query texts → sparse vectors.
        For splade-mini there is no separate query encoder; the same
        model is used for both documents and queries.
        """
        return self.encode_documents(texts)
def sparse_dot(a: dict[int, float], b: dict[int, float]) -> float:
    """Dot product of two sparse vectors."""
    if len(a) > len(b):
        a, b = b, a
    total = 0.0
    for idx, val in a.items():
        if idx in b:
            total += val * b[idx]
    return total

# ── Batch index + storage ────────────────────────────────────────

_encoder_singleton: SpladeEncoder | None = None

def _cleanup_encoder() -> None:
    """Release the GPU session before process exit.

    The BFC arena destructor SIGABRTs if the CUDA context is already
    partially torn down at interpreter shutdown.  Releasing the session
    explicitly via atexit runs while CUDA is still fully initialised.
    """
    import gc
    global _encoder_singleton
    if _encoder_singleton is not None:
        _encoder_singleton._session = None
        _encoder_singleton._cpu_session = None
        _encoder_singleton = None
        gc.collect()

def _get_encoder() -> SpladeEncoder:
    """Get or create the singleton encoder."""
    global _encoder_singleton
    if _encoder_singleton is None:
        import atexit
        _encoder_singleton = SpladeEncoder()
        atexit.register(_cleanup_encoder)
    return _encoder_singleton

def _vec_to_json(vec: dict[int, float]) -> str:
    """Compact JSON serialisation of a sparse vector."""
    return json.dumps({str(k): round(v, 4) for k, v in vec.items()})

def _json_to_vec(blob: str) -> dict[int, float]:
    """Deserialise a sparse vector from JSON."""
    raw = json.loads(blob)
    return {int(k): float(v) for k, v in raw.items()}

import struct

_PAIR_FMT = "If"  # uint32 term_id + float32 weight
_PAIR_SIZE = struct.calcsize(_PAIR_FMT)

def _vec_to_blob(vec: dict[int, float]) -> bytes:
    """Pack a sparse vector as binary: sequence of (uint32, float32) pairs."""
    parts = []
    for k, v in vec.items():
        parts.append(struct.pack(_PAIR_FMT, k, v))
    return b"".join(parts)

def _blob_to_vec(data: bytes) -> dict[int, float]:
    """Unpack a binary sparse vector to dict."""
    n_pairs = len(data) // _PAIR_SIZE
    result: dict[int, float] = {}
    for i in range(n_pairs):
        tid, w = struct.unpack_from(_PAIR_FMT, data, i * _PAIR_SIZE)
        result[tid] = w
    return result

# ── Re-exports for backward compatibility ────────────────────────

from coderecon.index.search.splade_db import (  # noqa: E402, F401
    backfill_scaffold_text,
    index_splade_vectors,
    load_all_vectors_fast,
    retrieve_splade,
)
from coderecon.index.search.splade_index import SpladeIndex  # noqa: E402, F401
from coderecon.index.search.splade_scaffold import (  # noqa: E402, F401
    _compact_sig,
    _path_to_phrase,
    build_def_scaffold,
    build_scaffolds_for_defs,
    word_split,
)
