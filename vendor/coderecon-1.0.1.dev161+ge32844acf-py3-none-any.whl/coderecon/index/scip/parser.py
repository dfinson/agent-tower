"""SCIP index file parser.

Reads .scip protobuf files and yields structured occurrence data
for import into the ref_facts schema.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

import structlog

from coderecon.index.scip.proto import (
    Document,
    Index,
    Occurrence,
    PositionEncoding,
    SymbolRole,
)

log = structlog.get_logger(__name__)


@dataclass(frozen=True, slots=True)
class ParsedOccurrence:
    """A single SCIP occurrence mapped to file-relative coordinates."""

    relative_path: str
    start_line: int  # 0-indexed
    start_col: int  # 0-indexed (byte offset for UTF-8 indexers)
    end_line: int  # 0-indexed
    end_col: int  # 0-indexed
    symbol: str  # SCIP symbol string (used as join key during import only)
    is_definition: bool
    is_import: bool


@dataclass(slots=True)
class ParsedDocument:
    """Parsed SCIP document with all occurrences."""

    relative_path: str
    language: str
    position_encoding: int = 0  # 0=Unspecified, 1=UTF8, 2=UTF16, 3=UTF32
    definitions: list[ParsedOccurrence] = field(default_factory=list)
    references: list[ParsedOccurrence] = field(default_factory=list)


@dataclass(slots=True)
class ScipIndexStats:
    """Statistics from parsing a SCIP index."""

    file_count: int = 0
    total_occurrences: int = 0
    definitions: int = 0
    references: int = 0


def _decode_range(range_values: list[int]) -> tuple[int, int, int, int]:
    """Decode SCIP range encoding to (start_line, start_col, end_line, end_col).

    SCIP range format:
    - 4 elements: [startLine, startCol, endLine, endCol]
    - 3 elements: [startLine, startCol, endCol] (endLine == startLine)
    """
    if len(range_values) == 4:
        return range_values[0], range_values[1], range_values[2], range_values[3]
    elif len(range_values) == 3:
        return range_values[0], range_values[1], range_values[0], range_values[2]
    else:
        raise ValueError(f"Invalid SCIP range: expected 3 or 4 elements, got {len(range_values)}")


def parse_scip_file(scip_path: Path) -> tuple[list[ParsedDocument], ScipIndexStats]:
    """Parse a .scip protobuf file into structured documents.

    Returns:
        Tuple of (documents, stats).
    """
    data = scip_path.read_bytes()
    index = Index()
    index.ParseFromString(data)

    stats = ScipIndexStats()
    documents: list[ParsedDocument] = []

    for doc in index.documents:
        parsed_doc = _parse_document(doc)
        if parsed_doc.definitions or parsed_doc.references:
            documents.append(parsed_doc)
            stats.file_count += 1
            stats.definitions += len(parsed_doc.definitions)
            stats.references += len(parsed_doc.references)
            stats.total_occurrences += len(parsed_doc.definitions) + len(parsed_doc.references)

    log.debug(
        "scip.parse_complete",
        extra={
            "path": str(scip_path),
            "files": stats.file_count,
            "defs": stats.definitions,
            "refs": stats.references,
        },
    )
    return documents, stats


def _parse_document(doc: Document) -> ParsedDocument:
    """Parse a single SCIP Document into a ParsedDocument."""
    parsed = ParsedDocument(
        relative_path=doc.relative_path,
        language=doc.language,
        position_encoding=doc.position_encoding,
    )

    for occ in doc.occurrences:
        if not occ.symbol or occ.symbol.startswith("local "):
            # Skip local symbols — they don't cross file boundaries
            continue

        if len(occ.range) < 3:
            continue

        try:
            start_line, start_col, end_line, end_col = _decode_range(list(occ.range))
        except ValueError:
            continue

        is_def = bool(occ.symbol_roles & SymbolRole.Definition)
        is_import = bool(occ.symbol_roles & SymbolRole.Import)

        parsed_occ = ParsedOccurrence(
            relative_path=doc.relative_path,
            start_line=start_line,
            start_col=start_col,
            end_line=end_line,
            end_col=end_col,
            symbol=occ.symbol,
            is_definition=is_def,
            is_import=is_import,
        )

        if is_def:
            parsed.definitions.append(parsed_occ)
        else:
            parsed.references.append(parsed_occ)

    return parsed


def iter_external_symbols(scip_path: Path) -> Iterator[tuple[str, str | None]]:
    """Yield (symbol_string, documentation) pairs for external symbols.

    External symbols are referenced but defined outside the indexed project.
    """
    data = scip_path.read_bytes()
    index = Index()
    index.ParseFromString(data)

    for sym_info in index.external_symbols:
        doc_text = sym_info.documentation[0] if sym_info.documentation else None
        yield sym_info.symbol, doc_text
