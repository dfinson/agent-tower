"""Generated SCIP protobuf bindings.

Re-exports from scip_pb2 for convenient access. The .proto source is from
https://github.com/sourcegraph/scip/blob/main/scip.proto
"""

from coderecon.index.scip.proto.scip_pb2 import (  # noqa: F401
    Descriptor,
    Diagnostic,
    Document,
    Index,
    Language,
    Metadata,
    Occurrence,
    Package,
    PositionEncoding,
    ProtocolVersion,
    Relationship,
    Severity,
    Signature,
    Symbol,
    SymbolInformation,
    SymbolRole,
    SyntaxKind,
    TextEncoding,
    ToolInfo,
)

__all__ = [
    "Descriptor",
    "Diagnostic",
    "Document",
    "Index",
    "Language",
    "Metadata",
    "Occurrence",
    "Package",
    "PositionEncoding",
    "ProtocolVersion",
    "Relationship",
    "Severity",
    "Signature",
    "Symbol",
    "SymbolInformation",
    "SymbolRole",
    "SyntaxKind",
    "TextEncoding",
    "ToolInfo",
]
