"""SCIP indexer tool detection, download, and management.

Handles auto-detection of which SCIP indexers are applicable for a repo
based on build tool markers, and manages indexer binaries in ~/.recon/tools/.
Auto-provisions tools on first use — no user intervention required.
"""

from __future__ import annotations

import os
import platform
import shutil
import stat
import subprocess
import tempfile
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    pass

log = structlog.get_logger(__name__)

# Tools directory for SCIP indexers
TOOLS_DIR = Path.home() / ".recon" / "tools"

# Platform detection for binary downloads
_SYSTEM = platform.system().lower()  # linux, darwin, windows
_ARCH = platform.machine().lower()  # x86_64, aarch64, arm64
# Normalize arch names used in release URLs
_ARCH_NORMALIZED = {
    "x86_64": "x86_64", "amd64": "x86_64",
    "aarch64": "aarch64", "arm64": "aarch64",
}.get(_ARCH, _ARCH)


@dataclass(frozen=True, slots=True)
class ScipTool:
    """Definition of a SCIP indexer tool."""

    name: str  # e.g. "scip-go"
    languages: tuple[str, ...]  # language names from _core/languages it covers
    markers: tuple[str, ...]  # filenames that indicate this tool is needed
    binary_name: str  # name of the executable
    install_type: str  # "binary", "npm", "dotnet", "go"
    # Dependency detection commands — if any returns non-zero, tool is unavailable
    prerequisites: tuple[str, ...] = ()
    # Per-language refresh granularity
    refresh_granularity: str = "full_project"
    # Install source — meaning depends on install_type:
    #   "go"     → Go module path (for `go install`)
    #   "npm"    → npm package name (for `npm install -g`)
    #   "binary" → GitHub repo slug "owner/repo" (for release downloads)
    #   "dotnet" → dotnet tool package name
    install_source: str = ""
    # Pinned version (tag/semver)
    install_version: str = ""
    # Docker image for container fallback when native prerequisites are
    # missing.  Empty string means no Docker fallback is available.
    # Images MUST be verified to exist on the registry before adding.
    docker_image: str = ""
    # Explicit entrypoint for Docker images that set CMD instead of
    # ENTRYPOINT.  When non-empty, the wrapper uses --entrypoint.
    # Leave empty for images whose ENTRYPOINT is already the tool binary.
    docker_entrypoint: str = ""


# Registry of all known SCIP indexers
SCIP_TOOLS: tuple[ScipTool, ...] = (
    ScipTool(
        name="scip-go",
        languages=("go",),
        markers=("go.mod", "go.work"),
        binary_name="scip-go",
        install_type="go",
        prerequisites=("go",),
        refresh_granularity="per_package",
        install_source="github.com/scip-code/scip-go/cmd/scip-go",
        install_version="v0.2.4",
        docker_image="sourcegraph/scip-go:latest",
        docker_entrypoint="scip-go",
    ),
    ScipTool(
        name="scip-typescript",
        languages=("javascript",),
        markers=("tsconfig.json", "package.json", "deno.json"),
        binary_name="scip-typescript",
        install_type="npm",
        prerequisites=("node",),
        refresh_granularity="per_project",
        install_source="@sourcegraph/scip-typescript",
        install_version="0.4.0",
        docker_image="sourcegraph/scip-typescript:v0.4.0",
    ),
    ScipTool(
        name="scip-python",
        languages=("python",),
        markers=("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt"),
        binary_name="scip-python",
        install_type="npm",
        prerequisites=("node",),
        refresh_granularity="per_file",
        install_source="@sourcegraph/scip-python",
        install_version="0.6.6",
        docker_image="sourcegraph/scip-python:v0.6.6",
        docker_entrypoint="scip-python",
    ),
    ScipTool(
        name="scip-java",
        languages=("java", "kotlin", "scala", "groovy"),
        markers=("pom.xml", "build.gradle", "build.gradle.kts", "build.sbt"),
        binary_name="scip-java",
        install_type="binary",
        prerequisites=("java",),
        refresh_granularity="full_project",
        install_source="sourcegraph/scip-java",
        install_version="",  # Uses coursier — handled specially
        docker_image="sourcegraph/scip-java:latest",
        docker_entrypoint="scip-java",
    ),
    ScipTool(
        name="rust-analyzer",
        languages=("rust",),
        markers=("Cargo.toml",),
        binary_name="rust-analyzer",
        install_type="binary",
        prerequisites=("cargo",),
        refresh_granularity="full_project",
        install_source="rust-lang/rust-analyzer",
        install_version="",  # Uses rustup component
        docker_image="sourcegraph/scip-rust:latest",
        docker_entrypoint="rust-analyzer",
    ),
    ScipTool(
        name="scip-dotnet",
        languages=("csharp", "fsharp", "vbnet"),
        markers=(),  # Detected by file extensions .csproj, .fsproj, .vbproj, .sln
        binary_name="scip-dotnet",
        install_type="dotnet",
        prerequisites=("dotnet",),
        refresh_granularity="full_project",
        install_source="scip-dotnet",
        install_version="",
        docker_image="sourcegraph/scip-dotnet:latest",
        docker_entrypoint="scip-dotnet",
    ),
    ScipTool(
        name="scip-ruby",
        languages=("ruby",),
        markers=("Gemfile",),
        binary_name="scip-ruby",
        install_type="binary",
        prerequisites=(),  # Pre-built native binary, no runtime needed
        refresh_granularity="full_project",
        install_source="sourcegraph/scip-ruby",
        install_version="scip-ruby-v0.4.7",
        docker_image="sourcegraph/scip-ruby:0.4.7",
        docker_entrypoint="scip-ruby",
    ),
    ScipTool(
        name="scip-php",
        languages=("php",),
        markers=("composer.json",),
        binary_name="scip-php",
        install_type="composer",
        prerequisites=("php", "composer"),
        refresh_granularity="full_project",
        install_source="davidrjenni/scip-php",
        install_version="",
        docker_image="davidrjenni/scip-php:main",
        docker_entrypoint="scip-php",
    ),
    ScipTool(
        name="dart-analyzer",
        languages=("dart",),
        markers=("pubspec.yaml",),
        binary_name="dart",
        install_type="binary",
        prerequisites=("dart",),
        refresh_granularity="per_file",
        install_source="",  # dart SDK bundled — prerequisite is the runtime itself
        install_version="",
        # No verified Docker image available
    ),
    ScipTool(
        name="scip-ocaml",
        languages=("ocaml",),
        markers=("dune-project", "dune"),
        binary_name="scip-ocaml",
        install_type="binary",
        prerequisites=("ocamlfind",),
        refresh_granularity="per_file",
        install_source="",
        install_version="",
        # No verified Docker image available
    ),
    ScipTool(
        name="scip-clang",
        languages=("c_cpp", "objc"),
        markers=("compile_commands.json", "CMakeLists.txt"),
        binary_name="scip-clang",
        install_type="binary",
        prerequisites=(),
        refresh_granularity="full_project",
        install_source="sourcegraph/scip-clang",
        install_version="v0.4.0",
        docker_image="sourcegraph/scip-clang:latest",
        # Image has ENTRYPOINT=[scip-clang] — no override needed.
    ),
)


class ScipToolRegistry:
    """Registry for discovering and managing SCIP indexer tools."""

    def __init__(self, tools_dir: Path | None = None) -> None:
        self._tools_dir = tools_dir or TOOLS_DIR
        self._tools_by_name: dict[str, ScipTool] = {t.name: t for t in SCIP_TOOLS}

    @property
    def tools_dir(self) -> Path:
        return self._tools_dir

    def detect_applicable_tools(self, repo_root: Path) -> list[ScipTool]:
        """Detect which SCIP tools are applicable for a repo based on markers.

        Scans repo_root for marker files (case-insensitive) and returns
        tools whose markers match.
        """
        applicable: list[ScipTool] = []
        # Build set of files in repo root (lowercase for case-insensitive match)
        try:
            root_files = {f.name.lower() for f in repo_root.iterdir() if f.is_file()}
        except OSError:
            return []

        for tool in SCIP_TOOLS:
            if not tool.markers:
                # Tools without markers need special detection (e.g. scip-dotnet)
                if tool.name == "scip-dotnet" and self._detect_dotnet_project(repo_root):
                    applicable.append(tool)
                continue

            for marker in tool.markers:
                if marker.lower() in root_files:
                    applicable.append(tool)
                    break

        return applicable

    def _detect_dotnet_project(self, repo_root: Path) -> bool:
        """Detect .NET projects by scanning for .csproj/.fsproj/.vbproj/.sln files."""
        dotnet_extensions = {".csproj", ".fsproj", ".vbproj", ".sln"}
        skip_dirs = {".", ".git", "node_modules", ".venv", "__pycache__", "bin", "obj"}
        try:
            for root, dirs, files in os.walk(repo_root):
                # Skip hidden/vendored directories
                dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith(".")]
                for fname in files:
                    if Path(fname).suffix.lower() in dotnet_extensions:
                        return True
        except OSError:
            pass
        return False

    def is_tool_available(self, tool: ScipTool) -> bool:
        """Check if a tool's binary is available (in PATH or tools_dir)."""
        # Check tools dir first
        tool_path = self._tools_dir / tool.binary_name
        if tool_path.exists() and os.access(tool_path, os.X_OK):
            return True

        # Check system PATH
        if shutil.which(tool.binary_name) is not None:
            return True

        return False

    def check_prerequisites(self, tool: ScipTool) -> bool:
        """Check if tool prerequisites are satisfied.

        Native prerequisites (runtimes on PATH) are checked first.  If any
        native prerequisite is missing, Docker is accepted as fallback
        when ``tool.docker_image`` is set and ``docker`` is on PATH.
        """
        native_ok = all(shutil.which(p) is not None for p in tool.prerequisites)
        if native_ok:
            return True
        # Native prereqs missing — Docker fallback?
        if tool.docker_image and shutil.which("docker"):
            return True
        return False

    def get_tool_path(self, tool: ScipTool, repo_root: Path | None = None) -> Path | None:
        """Get the path to a tool's binary, or None if not available."""
        # Prefer tools dir
        tool_path = self._tools_dir / tool.binary_name
        if tool_path.exists() and os.access(tool_path, os.X_OK):
            return tool_path

        # For composer tools, check project-local vendor/bin/
        if tool.install_type == "composer" and repo_root:
            vendor_path = repo_root / "vendor" / "bin" / tool.binary_name
            if vendor_path.exists() and os.access(vendor_path, os.X_OK):
                return vendor_path

        # Fall back to system PATH
        system_path = shutil.which(tool.binary_name)
        if system_path:
            # rust-analyzer may exist as a rustup proxy that fails if the
            # component is not installed.  Verify it actually works.
            if tool.name == "rust-analyzer":
                try:
                    subprocess.run(
                        [system_path, "--version"],
                        capture_output=True, timeout=10,
                    ).check_returncode()
                except Exception:
                    return None
            return Path(system_path)

        return None

    def ensure_tools_dir(self) -> None:
        """Create the tools directory if it doesn't exist."""
        self._tools_dir.mkdir(parents=True, exist_ok=True)

    # ── Auto-provisioning ───────────────────────────────────────────────────

    def install_tool(self, tool: ScipTool, repo_root: Path | None = None) -> Path | None:
        """Auto-install a SCIP tool. Returns path to binary or None on failure.

        Dispatches to the appropriate installer based on tool.install_type.
        If native install fails or has no install_source, falls back to a
        Docker wrapper when ``tool.docker_image`` is set.
        """
        self.ensure_tools_dir()

        # Try native install first if we have a source and prerequisites
        path: Path | None = None
        if tool.install_source:
            native_ok = all(shutil.which(p) is not None for p in tool.prerequisites)
            if native_ok:
                try:
                    if tool.install_type == "go":
                        path = self._install_via_go(tool)
                    elif tool.install_type == "npm":
                        path = self._install_via_npm(tool)
                    elif tool.install_type == "dotnet":
                        path = self._install_via_dotnet(tool)
                    elif tool.install_type == "binary":
                        path = self._install_binary(tool)
                    elif tool.install_type == "composer":
                        path = self._install_via_composer(tool, repo_root)
                    else:
                        log.warning("scip.unknown_install_type", extra={
                            "tool": tool.name, "install_type": tool.install_type,
                        })
                except Exception as e:
                    log.warning("scip.install_failed", extra={"tool": tool.name, "error": str(e)})

        if path is not None:
            return path

        # Native install unavailable or failed — try Docker wrapper
        if tool.docker_image and shutil.which("docker"):
            return self._create_docker_wrapper(tool)

        return None

    def _install_via_go(self, tool: ScipTool) -> Path | None:
        """Install via `go install`."""
        version = tool.install_version or "latest"
        module_path = f"{tool.install_source}@{version}"

        log.info("scip.installing", extra={"tool": tool.name, "method": "go install", "pkg": module_path})

        env = os.environ.copy()
        env["GOBIN"] = str(self._tools_dir)

        result = subprocess.run(
            ["go", "install", module_path],
            capture_output=True, text=True, timeout=300, env=env,
        )
        if result.returncode != 0:
            log.warning("scip.go_install_failed", extra={
                "tool": tool.name, "stderr": result.stderr[-500:],
            })
            return None

        installed_path = self._tools_dir / tool.binary_name
        if installed_path.exists():
            return installed_path
        return None

    def _install_via_npm(self, tool: ScipTool) -> Path | None:
        """Install via npm into tools_dir/node_modules/.bin/."""
        pkg = tool.install_source
        version = tool.install_version
        spec = f"{pkg}@{version}" if version else pkg

        log.info("scip.installing", extra={"tool": tool.name, "method": "npm", "pkg": spec})

        # Install into a dedicated node_modules inside tools_dir
        npm_prefix = self._tools_dir / "npm"
        npm_prefix.mkdir(parents=True, exist_ok=True)

        result = subprocess.run(
            ["npm", "install", "--prefix", str(npm_prefix), spec],
            capture_output=True, text=True, timeout=300,
        )
        if result.returncode != 0:
            log.warning("scip.npm_install_failed", extra={
                "tool": tool.name, "stderr": result.stderr[-500:],
            })
            return None

        # Find the binary in node_modules/.bin
        bin_path = npm_prefix / "node_modules" / ".bin" / tool.binary_name
        if bin_path.exists():
            # Symlink into tools_dir for uniform lookup
            link_path = self._tools_dir / tool.binary_name
            link_path.unlink(missing_ok=True)
            link_path.symlink_to(bin_path)
            return link_path
        return None

    def _install_via_dotnet(self, tool: ScipTool) -> Path | None:
        """Install via `dotnet tool install`."""
        pkg = tool.install_source

        log.info("scip.installing", extra={"tool": tool.name, "method": "dotnet tool", "pkg": pkg})

        result = subprocess.run(
            ["dotnet", "tool", "install", "--tool-path", str(self._tools_dir), pkg],
            capture_output=True, text=True, timeout=300,
        )
        if result.returncode != 0:
            # May already be installed — try update
            result = subprocess.run(
                ["dotnet", "tool", "update", "--tool-path", str(self._tools_dir), pkg],
                capture_output=True, text=True, timeout=300,
            )
            if result.returncode != 0:
                log.warning("scip.dotnet_install_failed", extra={
                    "tool": tool.name, "stderr": result.stderr[-500:],
                })
                return None

        installed_path = self._tools_dir / tool.binary_name
        if installed_path.exists():
            return installed_path
        return None

    def _install_via_composer(self, tool: ScipTool, repo_root: Path | None = None) -> Path | None:
        """Install a composer-based SCIP tool.

        Strategy:
        1. If vendor/bin/<binary> exists in the project, use it directly.
        2. Run `composer require --dev <package>` in the project.
        3. If composer unavailable/fails, fall back to Docker wrapper.
        """
        pkg = tool.install_source

        # 1. Already installed as project dependency?
        if repo_root:
            vendor_bin = repo_root / "vendor" / "bin" / tool.binary_name
            if vendor_bin.exists() and os.access(vendor_bin, os.X_OK):
                return vendor_bin

        # 2. Try composer require in the project
        if repo_root and shutil.which("composer"):
            log.info("scip.installing", extra={"tool": tool.name, "method": "composer", "pkg": pkg})
            result = subprocess.run(
                ["composer", "require", "--dev", "--no-interaction", "--quiet", pkg],
                capture_output=True, text=True, timeout=300,
                cwd=str(repo_root),
            )
            if result.returncode == 0:
                vendor_bin = repo_root / "vendor" / "bin" / tool.binary_name
                if vendor_bin.exists():
                    return vendor_bin

        # 3. Fall back to Docker wrapper
        if shutil.which("docker"):
            return self._create_docker_wrapper(tool)

        log.warning("scip.composer_install_failed", extra={
            "tool": tool.name, "error": "no composer or docker available",
        })
        return None

    def _create_docker_wrapper(self, tool: ScipTool) -> Path | None:
        """Create a shell wrapper that invokes the tool via Docker.

        When ``docker_entrypoint`` is set, the wrapper uses
        ``--entrypoint`` so that ``"$@"`` becomes arguments to the tool
        binary rather than replacing the container's CMD.
        """
        image = tool.docker_image
        if not image:
            return None
        wrapper_path = self._tools_dir / tool.binary_name
        # Mount the host cwd at the *same* path inside the container so that
        # absolute output paths (e.g. .recon/scip/tool.scip) work unchanged.
        ep_flag = f' --entrypoint {tool.docker_entrypoint}' if tool.docker_entrypoint else ''
        script = f"""#!/bin/sh
exec docker run --rm{ep_flag} -v "$(pwd):$(pwd)" -w "$(pwd)" {image} "$@"
"""
        try:
            wrapper_path.write_text(script)
            wrapper_path.chmod(wrapper_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            log.info("scip.installed_docker_wrapper", extra={"tool": tool.name, "path": str(wrapper_path)})
            return wrapper_path
        except OSError as e:
            log.warning("scip.docker_wrapper_failed", extra={"tool": tool.name, "error": str(e)})
            return None

    def _install_binary(self, tool: ScipTool) -> Path | None:
        """Install pre-built binary from GitHub releases or tool-specific methods."""
        # rust-analyzer: use rustup component
        if tool.name == "rust-analyzer":
            return self._install_rust_analyzer()

        # scip-java: use coursier
        if tool.name == "scip-java":
            return self._install_scip_java()

        # Generic GitHub release download
        if tool.install_source:
            return self._install_from_github_release(tool)

        return None

    def _install_rust_analyzer(self) -> Path | None:
        """Install rust-analyzer via rustup."""
        log.info("scip.installing", extra={"tool": "rust-analyzer", "method": "rustup"})

        result = subprocess.run(
            ["rustup", "component", "add", "rust-analyzer"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            log.warning("scip.rustup_failed", extra={"stderr": result.stderr[-500:]})
            return None

        # rustup installs into cargo bin dir
        ra_path = shutil.which("rust-analyzer")
        if ra_path:
            return Path(ra_path)
        return None

    def _install_scip_java(self) -> Path | None:
        """Install scip-java via coursier bootstrap."""
        log.info("scip.installing", extra={"tool": "scip-java", "method": "coursier"})

        cs_path = shutil.which("cs") or shutil.which("coursier")
        if not cs_path:
            # Try to bootstrap coursier
            cs_path = self._bootstrap_coursier()
            if not cs_path:
                log.warning("scip.coursier_unavailable")
                return None

        dest = self._tools_dir / "scip-java"
        result = subprocess.run(
            [cs_path, "bootstrap", "--standalone",
             "com.sourcegraph:scip-java_2.13:latest.release",
             "-M", "com.sourcegraph.scip_java.ScipJava",
             "-o", str(dest)],
            capture_output=True, text=True, timeout=300,
        )
        if result.returncode != 0:
            log.warning("scip.scip_java_install_failed", extra={
                "stderr": result.stderr[-500:],
            })
            return None

        dest.chmod(dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        return dest if dest.exists() else None

    def _bootstrap_coursier(self) -> str | None:
        """Download coursier CLI if not available."""
        cs_dest = self._tools_dir / "cs"
        if cs_dest.exists():
            return str(cs_dest)

        if _SYSTEM == "linux":
            url = "https://github.com/coursier/coursier/releases/latest/download/cs-x86_64-pc-linux.gz"
        elif _SYSTEM == "darwin":
            suffix = "aarch64-apple-darwin" if _ARCH_NORMALIZED == "aarch64" else "x86_64-apple-darwin"
            url = f"https://github.com/coursier/coursier/releases/latest/download/cs-{suffix}.gz"
        else:
            return None

        try:
            import gzip
            with tempfile.NamedTemporaryFile(delete=False, suffix=".gz") as tmp:
                urllib.request.urlretrieve(url, tmp.name)
                with gzip.open(tmp.name, "rb") as gz:
                    cs_dest.write_bytes(gz.read())
                os.unlink(tmp.name)
            cs_dest.chmod(cs_dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            return str(cs_dest)
        except Exception as e:
            log.debug("scip.coursier_bootstrap_failed", extra={"error": str(e)})
            return None

    def _install_from_github_release(self, tool: ScipTool) -> Path | None:
        """Download a pre-built binary from GitHub releases."""
        repo = tool.install_source  # e.g. "sourcegraph/scip-ruby"
        version = tool.install_version

        # Resolve "latest" if no version pinned
        if not version:
            version = self._resolve_latest_github_release(repo)
            if not version:
                log.warning("scip.no_release_found", extra={"tool": tool.name, "repo": repo})
                return None

        asset_name = self._guess_asset_name(tool, version)
        if not asset_name:
            log.warning("scip.no_asset_pattern", extra={"tool": tool.name})
            return None

        # Strip leading 'v' for URL construction if present in tag
        tag = version
        url = f"https://github.com/{repo}/releases/download/{tag}/{asset_name}"

        log.info("scip.downloading", extra={"tool": tool.name, "url": url})

        try:
            dest = self._tools_dir / tool.binary_name
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                urllib.request.urlretrieve(url, tmp.name)
                tmp_path = Path(tmp.name)

            # Handle compressed archives
            if asset_name.endswith(".tar.gz") or asset_name.endswith(".tgz"):
                import tarfile
                with tarfile.open(str(tmp_path), "r:gz") as tar:
                    # Find the binary inside
                    for member in tar.getmembers():
                        if member.name.endswith(tool.binary_name) or member.name == tool.binary_name:
                            f = tar.extractfile(member)
                            if f:
                                dest.write_bytes(f.read())
                                break
                    else:
                        # Extract first executable-looking file
                        for member in tar.getmembers():
                            if member.isfile() and member.mode & stat.S_IXUSR:
                                f = tar.extractfile(member)
                                if f:
                                    dest.write_bytes(f.read())
                                    break
                tmp_path.unlink(missing_ok=True)
            elif asset_name.endswith(".gz"):
                import gzip
                with gzip.open(str(tmp_path), "rb") as gz:
                    dest.write_bytes(gz.read())
                tmp_path.unlink(missing_ok=True)
            elif asset_name.endswith(".zip"):
                import zipfile
                with zipfile.ZipFile(str(tmp_path)) as zf:
                    for name in zf.namelist():
                        if name.endswith(tool.binary_name) or name == tool.binary_name:
                            dest.write_bytes(zf.read(name))
                            break
                    else:
                        # Take first file
                        for name in zf.namelist():
                            if not name.endswith("/"):
                                dest.write_bytes(zf.read(name))
                                break
                tmp_path.unlink(missing_ok=True)
            else:
                # Plain binary
                shutil.move(str(tmp_path), str(dest))

            dest.chmod(dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            return dest if dest.exists() else None

        except Exception as e:
            log.warning("scip.download_failed", extra={"tool": tool.name, "error": str(e)})
            return None

    def _github_api_headers(self) -> dict[str, str]:
        """Build GitHub API headers with auth if available."""
        headers = {"Accept": "application/vnd.github.v3+json"}
        token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN") or ""
        if not token:
            try:
                token = subprocess.run(
                    ["gh", "auth", "token"],
                    capture_output=True, text=True, timeout=5,
                ).stdout.strip()
            except Exception:
                pass
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _resolve_latest_github_release(self, repo: str) -> str | None:
        """Get the latest release tag from GitHub API."""
        import json
        headers = self._github_api_headers()

        # Try formal releases first
        url = f"https://api.github.com/repos/{repo}/releases/latest"
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read())
                tag = data.get("tag_name")
                if tag:
                    return tag
        except Exception:
            pass

        # Fallback: list all releases (includes drafts/prereleases)
        url = f"https://api.github.com/repos/{repo}/releases?per_page=1"
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read())
                if data and isinstance(data, list):
                    return data[0].get("tag_name")
        except Exception:
            pass

        # Last resort: latest tag (no release required)
        url = f"https://api.github.com/repos/{repo}/tags?per_page=1"
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read())
                if data and isinstance(data, list):
                    return data[0].get("name")
        except Exception:
            pass

        return None

    def _guess_asset_name(self, tool: ScipTool, version: str) -> str | None:
        """Guess the release asset filename for the current platform."""
        system = _SYSTEM
        arch = _ARCH_NORMALIZED

        # Common patterns per tool
        if tool.name == "scip-ruby":
            if system == "linux":
                return f"scip-ruby-{arch}-linux"
            elif system == "darwin":
                return f"scip-ruby-{arch}-darwin"
        elif tool.name == "scip-php":
            if system == "linux":
                return f"scip-php-{arch}-linux"
            elif system == "darwin":
                return f"scip-php-{arch}-darwin"
        elif tool.name == "scip-clang":
            if system == "linux":
                return f"scip-clang-x86_64-linux"
            elif system == "darwin":
                return f"scip-clang-{arch}-macos"

        # Generic fallback: try common patterns
        name = tool.binary_name
        v = version.lstrip("v")
        patterns = [
            f"{name}-{system}-{arch}",
            f"{name}-{arch}-{system}",
            f"{name}_{system}_{arch}.tar.gz",
            f"{name}-{v}-{system}-{arch}.tar.gz",
        ]
        # Return first pattern — callers handle 404 gracefully
        return patterns[0] if patterns else None


def detect_scip_tools(repo_root: Path) -> list[tuple[ScipTool, Path | None]]:
    """Detect applicable SCIP tools and their availability for a repo.

    Auto-installs tools that are detected as needed but not yet available.
    Returns list of (tool, binary_path_or_none) tuples.
    """
    registry = ScipToolRegistry()
    applicable = registry.detect_applicable_tools(repo_root)
    result: list[tuple[ScipTool, Path | None]] = []

    for tool in applicable:
        if not registry.check_prerequisites(tool):
            log.debug(
                "scip.tool_prereqs_missing",
                extra={"tool": tool.name, "prereqs": tool.prerequisites},
            )
            result.append((tool, None))
            continue

        path = registry.get_tool_path(tool, repo_root)

        # Auto-provision if not available
        if path is None:
            log.info("scip.auto_provisioning", extra={"tool": tool.name})
            path = registry.install_tool(tool, repo_root)
            if path:
                log.info("scip.installed", extra={"tool": tool.name, "path": str(path)})

        result.append((tool, path))

    return result
