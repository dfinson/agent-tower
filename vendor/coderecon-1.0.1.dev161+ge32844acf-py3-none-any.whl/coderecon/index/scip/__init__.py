"""SCIP (Source Code Intelligence Protocol) integration.

Automatic import of compiler-grade semantic resolution into the existing
ref_facts schema. Runs as part of the indexing pipeline before Pass 1.5.

Submodules:
- proto: Generated protobuf bindings for SCIP format
- parser: Read and iterate SCIP index files
- tools: Indexer detection, download, and execution
- runner: Orchestrate tool execution and import
- importer: Map SCIP occurrences → ref_facts by position
- incremental: Handle file-change invalidation
"""

from coderecon.index.scip.importer import import_scip_index
from coderecon.index.scip.incremental import reset_scip_refs_for_files
from coderecon.index.scip.tools import ScipToolRegistry, detect_scip_tools
from coderecon.index.scip.runner import ensure_scip_current

__all__ = [
    "detect_scip_tools",
    "ensure_scip_current",
    "import_scip_index",
    "reset_scip_refs_for_files",
    "ScipToolRegistry",
]
