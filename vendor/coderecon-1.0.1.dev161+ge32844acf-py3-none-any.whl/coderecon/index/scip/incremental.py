"""Incremental SCIP support.

Handles resetting SCIP-sourced PROVEN refs on file changes and
scheduling background refresh for full-project languages.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import structlog
from sqlalchemy import text

if TYPE_CHECKING:
    from coderecon.index.db import Database

log = structlog.get_logger(__name__)


def reset_scip_refs_for_files(db: Database, file_ids: list[int]) -> int:
    """Reset SCIP-sourced PROVEN refs in changed files to UNKNOWN.

    For incremental reindex: when files change, their SCIP-resolved refs
    may be stale. Reset them so tree-sitter passes can re-resolve what they
    can, and background SCIP refresh will upgrade them back to PROVEN later.

    Only resets refs that were set by SCIP (ref_tier='proven' AND
    target_def_uid starts with 'ext::' or was set in the same position-match
    pattern). We use ref_tier='proven' + certainty='certain' as the marker.

    Returns the number of refs reset.
    """
    if not file_ids:
        return 0

    with db.session() as session:
        # Reset proven refs in changed files back to unknown
        # These will be re-resolved by SCIP on next full run or by
        # tree-sitter passes immediately
        placeholders = ", ".join(f":fid{i}" for i in range(len(file_ids)))
        params = {f"fid{i}": fid for i, fid in enumerate(file_ids)}

        result = session.execute(
            text(f"""
                UPDATE ref_facts
                SET ref_tier = 'unknown',
                    target_def_uid = NULL,
                    certainty = 'certain'
                WHERE file_id IN ({placeholders})
                  AND ref_tier = 'proven'
                  AND target_def_uid IS NOT NULL
            """),
            params,
        )
        reset_count = result.rowcount
        session.commit()

    if reset_count > 0:
        log.debug(
            "scip.incremental_reset",
            extra={"file_ids": len(file_ids), "refs_reset": reset_count},
        )

    return reset_count
