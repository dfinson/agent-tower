"""SCIP indexer execution and orchestration.

Runs SCIP indexers for detected languages and imports results into the
ref_facts schema. This is the main entry point called from the pipeline.

Two modes:
- ``ensure_scip_current`` — full-project run for all detected tools
- ``run_scip_incremental`` — partial run scoped to changed files for tools
  whose ``refresh_granularity`` supports it (per_file, per_package)
"""

from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

from coderecon.index.scip.importer import import_scip_index
from coderecon.index.scip.tools import ScipTool, ScipToolRegistry, detect_scip_tools

if TYPE_CHECKING:
    from coderecon.index.db import Database

log = structlog.get_logger(__name__)


def _ensure_compile_commands(repo_root: Path) -> Path | None:
    """Ensure compile_commands.json exists for C/C++ projects.

    If missing, attempts to generate it via CMake.
    Returns the path to compile_commands.json or None.
    """
    # Check common locations
    for candidate in [
        repo_root / "compile_commands.json",
        repo_root / "build" / "compile_commands.json",
    ]:
        if candidate.exists():
            return candidate

    # Try CMake generation
    cmake_file = repo_root / "CMakeLists.txt"
    if cmake_file.exists() and shutil.which("cmake"):
        build_dir = repo_root / "build"
        log.info("scip.generating_compdb", extra={"method": "cmake"})
        try:
            result = subprocess.run(
                ["cmake", "-B", str(build_dir), "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON"],
                cwd=str(repo_root),
                capture_output=True, text=True, timeout=120,
            )
            compdb = build_dir / "compile_commands.json"
            if result.returncode == 0 and compdb.exists():
                return compdb
        except Exception as e:
            log.debug("scip.compdb_generation_failed", extra={"error": str(e)})

    return None


class ScipBuildError(Exception):
    """Raised when a SCIP indexer fails to generate an index."""

    def __init__(self, tool: str, message: str, returncode: int | None = None) -> None:
        self.tool = tool
        self.returncode = returncode
        super().__init__(f"SCIP {tool} failed: {message}")


@dataclass(slots=True)
class ScipRunResult:
    """Result of a single SCIP indexer run."""

    tool_name: str
    language: str
    success: bool = False
    scip_path: Path | None = None
    refs_matched: int = 0
    refs_external: int = 0
    elapsed_sec: float = 0.0
    error: str | None = None


@dataclass(slots=True)
class ScipImportResult:
    """Aggregate result from all SCIP operations in one pipeline run."""

    results: list[ScipRunResult] = field(default_factory=list)
    total_refs_matched: int = 0
    total_refs_external: int = 0

    @property
    def any_success(self) -> bool:
        return any(r.success for r in self.results)


def _get_scip_output_dir(repo_root: Path) -> Path:
    """Get the directory where SCIP index files are stored."""
    from coderecon._core.recon_dir import ensure_recon_dir
    scip_dir = ensure_recon_dir(repo_root) / "scip"
    scip_dir.mkdir(exist_ok=True)
    return scip_dir


def _build_indexer_command(tool: ScipTool, tool_path: Path, repo_root: Path, output_path: Path) -> list[str]:
    """Build the command line for a SCIP indexer.

    Each tool has its own invocation pattern.
    """
    if tool.name == "scip-go":
        return [str(tool_path), "--output", str(output_path), "--module-version", "HEAD"]
    elif tool.name == "scip-typescript":
        return [
            str(tool_path),
            "index",
            "--output", str(output_path),
            "--infer-tsconfig",
        ]
    elif tool.name == "scip-python":
        return [
            str(tool_path),
            "index",
            "--output", str(output_path),
            "--project-name", repo_root.name,
        ]
    elif tool.name == "scip-java":
        # scip-java wraps the build system
        return [str(tool_path), "index", "--output", str(output_path)]
    elif tool.name == "rust-analyzer":
        return [str(tool_path), "scip", str(repo_root), "--output", str(output_path)]
    elif tool.name == "scip-dotnet":
        # Find the first .sln or .csproj
        sln_files = list(repo_root.glob("*.sln"))
        if sln_files:
            target = str(sln_files[0])
        else:
            csproj_files = list(repo_root.glob("**/*.csproj"))
            target = str(csproj_files[0]) if csproj_files else "."
        return [str(tool_path), "index", target, "--output", str(output_path)]
    elif tool.name == "scip-ruby":
        return [str(tool_path), "--index-file", str(output_path), "."]
    elif tool.name == "scip-php":
        return [str(tool_path), "index", "--output", str(output_path)]
    elif tool.name == "scip-clang":
        compdb = _ensure_compile_commands(repo_root)
        cmd = [str(tool_path), "--output", str(output_path)]
        if compdb:
            cmd.append(f"--compdb-path={compdb}")
        return cmd
    elif tool.name == "scip-ocaml":
        return [str(tool_path), "index", "--output", str(output_path)]
    elif tool.name == "dart-analyzer":
        return [str(tool_path), "analyze", "--scip-output", str(output_path)]
    else:
        return [str(tool_path), "--output", str(output_path)]


# ---------------------------------------------------------------------------
# Partial / incremental indexer commands
# ---------------------------------------------------------------------------

def _tool_language_extensions(tool: ScipTool) -> frozenset[str]:
    """Return the union of file extensions for all languages a tool covers."""
    from coderecon._core.languages._util import LANGUAGES_BY_NAME

    exts: set[str] = set()
    for lang_name in tool.languages:
        lang = LANGUAGES_BY_NAME.get(lang_name)
        if lang:
            exts.update(lang.extensions)
    return frozenset(exts)


def _changed_paths_for_tool(
    tool: ScipTool,
    changed_paths: list[str],
) -> list[str]:
    """Filter *changed_paths* to those whose extension matches *tool*."""
    exts = _tool_language_extensions(tool)
    return [p for p in changed_paths if os.path.splitext(p)[1].lower() in exts]


def _go_package_patterns(changed_go_paths: list[str]) -> list[str]:
    """Derive Go package patterns from changed ``.go`` file paths.

    Given ``["cmd/server/main.go", "internal/db/conn.go"]`` returns
    ``["./cmd/server/...", "./internal/db/..."]``.
    """
    dirs: set[str] = set()
    for p in changed_go_paths:
        parent = os.path.dirname(p)
        if parent:
            dirs.add(f"./{parent}/...")
        else:
            dirs.add("./...")
    return sorted(dirs)


def _build_partial_indexer_command(
    tool: ScipTool,
    tool_path: Path,
    repo_root: Path,
    output_path: Path,
    changed_paths: list[str],
) -> list[str] | None:
    """Build a partial-indexer command scoped to *changed_paths*.

    Returns ``None`` if the tool has no partial mode and must fall back to
    a full-project run.
    """
    if tool.name == "scip-python":
        # --target-only accepts a single path.  Use the deepest common
        # ancestor directory of all changed Python files so the indexer
        # analyses the minimal subtree.
        dirs = {os.path.dirname(p) or "." for p in changed_paths}
        target = os.path.commonpath(list(dirs)) if dirs else "."
        # commonpath returns "" when paths share no common prefix
        # (e.g. "src/a" vs "lib/b") — fall back to repo root.
        if not target:
            target = "."
        return [
            str(tool_path),
            "index",
            "--output", str(output_path),
            "--project-name", repo_root.name,
            "--target-only", target,
        ]

    if tool.name == "scip-go":
        patterns = _go_package_patterns(changed_paths)
        return [
            str(tool_path),
            "--output", str(output_path),
            "--module-version", "HEAD",
            *patterns,
        ]

    # Tools with per_file / per_project granularity that don't (yet) have a
    # concrete partial CLI flag fall back to full-project runs.
    return None


async def _run_scip_indexer(
    tool: ScipTool,
    tool_path: Path,
    repo_root: Path,
    output_path: Path,
    timeout_sec: float = 600.0,
    cmd_override: list[str] | None = None,
) -> None:
    """Run a SCIP indexer subprocess.

    Raises ScipBuildError if the indexer fails.
    """
    cmd = cmd_override or _build_indexer_command(tool, tool_path, repo_root, output_path)

    log.info("scip.indexer_start", extra={"tool": tool.name, "cmd": cmd[0]})

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=str(repo_root),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_sec)
    except asyncio.TimeoutError:
        proc.kill()
        raise ScipBuildError(tool.name, f"timed out after {timeout_sec}s")
    except FileNotFoundError:
        raise ScipBuildError(tool.name, f"binary not found: {cmd[0]}")
    except OSError as e:
        raise ScipBuildError(tool.name, str(e))

    if proc.returncode != 0:
        error_msg = stderr.decode(errors="replace").strip()[-500:]  # Last 500 chars
        raise ScipBuildError(tool.name, error_msg, returncode=proc.returncode)

    if not output_path.exists():
        raise ScipBuildError(tool.name, "indexer completed but no output file produced")


def _source_changed_since(repo_root: Path, tool: ScipTool, last_import_time: float) -> bool:
    """Check if any source files for this tool's languages have changed since last import.

    Walks the repo tree skipping PRUNABLE_DIRS (node_modules, .venv, .git, etc.)
    to avoid false positives from dependency installs or VCS internals.
    """
    from coderecon._core.excludes import PRUNABLE_DIRS
    from coderecon._core.languages import LANGUAGES_BY_NAME

    extensions: set[str] = set()
    for lang_name in tool.languages:
        lang = LANGUAGES_BY_NAME.get(lang_name)
        if lang:
            extensions.update(lang.extensions)

    try:
        for dirpath, dirnames, filenames in os.walk(repo_root):
            # Prune ignored directories in-place
            dirnames[:] = [
                d for d in dirnames if d not in PRUNABLE_DIRS
            ]
            for fname in filenames:
                if os.path.splitext(fname)[1] in extensions:
                    fpath = os.path.join(dirpath, fname)
                    try:
                        if os.stat(fpath).st_mtime > last_import_time:
                            return True
                    except OSError:
                        continue
    except OSError:
        return True  # Assume changed on error

    return False


def _get_last_import_time(db: Database, language: str) -> float | None:
    """Get the timestamp of the last successful SCIP import for a language."""
    from sqlalchemy import text

    with db.session() as session:
        row = session.execute(
            text("SELECT MAX(imported_at) FROM scip_imports WHERE language = :lang"),
            {"lang": language},
        ).scalar()
        return row if row else None


def _get_tool_last_import_time(db: Database, tool: ScipTool) -> float | None:
    """Get the earliest last-import time across all languages a tool covers.

    Returns None if ANY language has never been imported (meaning the tool
    needs to run). Returns the minimum imported_at if all languages have records.
    """
    from sqlalchemy import text

    with db.session() as session:
        for lang in tool.languages:
            row = session.execute(
                text("SELECT MAX(imported_at) FROM scip_imports WHERE language = :lang"),
                {"lang": lang},
            ).scalar()
            if not row:
                return None  # At least one language never imported
        # All languages have records — return earliest so we re-run if ANY is stale
        placeholders = ", ".join(f":l{i}" for i in range(len(tool.languages)))
        params = {f"l{i}": lang for i, lang in enumerate(tool.languages)}
        row = session.execute(
            text(f"""
                SELECT MIN(max_ts) FROM (
                    SELECT MAX(imported_at) as max_ts FROM scip_imports
                    WHERE language IN ({placeholders})
                    GROUP BY language
                )
            """),
            params,
        ).scalar()
        return row if row else None


async def ensure_scip_current(
    db: Database,
    repo_root: Path,
    worktree_id: int = 1,
) -> ScipImportResult:
    """Generate and import SCIP data for all detected languages.

    This is the main entry point called from the indexing pipeline.
    Best-effort: failures are logged and skipped, never blocking.

    Each tool runs once and produces a single SCIP file covering all its
    languages. The import is then performed once per language present in
    the SCIP output (using each document's actual language field).
    """
    result = ScipImportResult()
    tools_with_paths = detect_scip_tools(repo_root)

    if not tools_with_paths:
        return result

    scip_dir = _get_scip_output_dir(repo_root)

    for tool, tool_path in tools_with_paths:
        if tool_path is None:
            for lang in tool.languages:
                result.results.append(ScipRunResult(
                    tool_name=tool.name,
                    language=lang,
                    success=False,
                    error="tool not installed",
                ))
            continue

        start_time = time.time()

        # Staleness check at the tool level (not per-language)
        last_import = _get_tool_last_import_time(db, tool)
        if last_import and not _source_changed_since(repo_root, tool, last_import):
            log.debug("scip.skip_unchanged", extra={"tool": tool.name})
            for lang in tool.languages:
                result.results.append(ScipRunResult(
                    tool_name=tool.name, language=lang, success=True, elapsed_sec=0.0,
                ))
            continue

        # Run the indexer once for this tool
        output_path = scip_dir / f"{tool.name}.scip"

        try:
            await _run_scip_indexer(tool, tool_path, repo_root, output_path)
        except ScipBuildError as e:
            log.warning(
                "scip.generation_failed",
                extra={"tool": tool.name, "error": str(e)},
            )
            for lang in tool.languages:
                result.results.append(ScipRunResult(
                    tool_name=tool.name, language=lang,
                    error=str(e), elapsed_sec=time.time() - start_time,
                ))
            continue

        # Import the SCIP data — one import call per tool, records per-language
        # Pass start_time as imported_at so files modified during indexing
        # are detected as stale on the next run (avoids TOCTOU gap).
        try:
            import_stats = import_scip_index(
                db, output_path, tool.languages, worktree_id,
                imported_at=start_time, repo_root=repo_root,
            )
            elapsed = time.time() - start_time
            for lang in tool.languages:
                result.results.append(ScipRunResult(
                    tool_name=tool.name, language=lang, success=True,
                    scip_path=output_path,
                    refs_matched=import_stats.refs_matched,
                    refs_external=import_stats.refs_external,
                    elapsed_sec=elapsed,
                ))
            result.total_refs_matched += import_stats.refs_matched
            result.total_refs_external += import_stats.refs_external
        except Exception as e:
            log.warning(
                "scip.import_failed",
                extra={"tool": tool.name, "error": str(e)},
            )
            for lang in tool.languages:
                result.results.append(ScipRunResult(
                    tool_name=tool.name, language=lang,
                    error=f"import failed: {e}",
                    elapsed_sec=time.time() - start_time,
                ))

    if result.any_success:
        log.info(
            "scip.import_complete",
            extra={
                "refs_matched": result.total_refs_matched,
                "refs_external": result.total_refs_external,
                "tools": [r.tool_name for r in result.results if r.success],
            },
        )

    return result


async def run_scip_incremental(
    db: Database,
    repo_root: Path,
    changed_paths: list[str],
    worktree_id: int = 1,
) -> ScipImportResult:
    """Run SCIP indexers scoped to *changed_paths* for tools that support it.

    Only tools with ``refresh_granularity`` other than ``full_project`` are
    considered.  For each, the changed paths are filtered to matching
    extensions and a partial command is built.  Tools that don't have a
    concrete partial CLI flag fall back to full-project runs.

    Tools with ``full_project`` granularity are skipped — they should be
    handled separately by the caller (via ``ensure_scip_current``).

    Returns ``ScipImportResult`` covering only the tools that were run.
    """
    result = ScipImportResult()
    tools_with_paths = detect_scip_tools(repo_root)

    if not tools_with_paths:
        return result

    scip_dir = _get_scip_output_dir(repo_root)

    for tool, tool_path in tools_with_paths:
        # Skip full-project tools — those run via ensure_scip_current
        if tool.refresh_granularity == "full_project":
            continue

        if tool_path is None:
            continue  # best-effort; no need to record failures for partial runs

        # Filter changed_paths to this tool's language extensions
        tool_paths = _changed_paths_for_tool(tool, changed_paths)
        if not tool_paths:
            continue

        start_time = time.time()
        output_path = scip_dir / f"{tool.name}-incremental.scip"

        # Build partial command; fall back to full-project if tool doesn't
        # have a partial CLI
        cmd_override = _build_partial_indexer_command(
            tool, tool_path, repo_root, output_path, tool_paths,
        )

        log.info(
            "scip.incremental_start",
            tool=tool.name,
            changed_files=len(tool_paths),
            partial=cmd_override is not None,
        )

        try:
            await _run_scip_indexer(
                tool, tool_path, repo_root, output_path,
                cmd_override=cmd_override,
            )
        except ScipBuildError as e:
            log.warning(
                "scip.incremental_failed",
                tool=tool.name,
                error=str(e),
            )
            for lang in tool.languages:
                result.results.append(ScipRunResult(
                    tool_name=tool.name, language=lang,
                    error=str(e), elapsed_sec=time.time() - start_time,
                ))
            continue

        try:
            import_stats = import_scip_index(
                db, output_path, tool.languages, worktree_id,
                imported_at=start_time, repo_root=repo_root,
                record_import=False,  # partial run — don't poison staleness check
            )
            elapsed = time.time() - start_time
            for lang in tool.languages:
                result.results.append(ScipRunResult(
                    tool_name=tool.name, language=lang, success=True,
                    scip_path=output_path,
                    refs_matched=import_stats.refs_matched,
                    refs_external=import_stats.refs_external,
                    elapsed_sec=elapsed,
                ))
            result.total_refs_matched += import_stats.refs_matched
            result.total_refs_external += import_stats.refs_external
        except Exception as e:
            log.warning(
                "scip.incremental_import_failed",
                tool=tool.name,
                error=str(e),
            )
            for lang in tool.languages:
                result.results.append(ScipRunResult(
                    tool_name=tool.name, language=lang,
                    error=f"import failed: {e}",
                    elapsed_sec=time.time() - start_time,
                ))

    if result.any_success:
        log.info(
            "scip.incremental_complete",
            refs_matched=result.total_refs_matched,
            refs_external=result.total_refs_external,
            tools=[r.tool_name for r in result.results if r.success],
        )

    return result
