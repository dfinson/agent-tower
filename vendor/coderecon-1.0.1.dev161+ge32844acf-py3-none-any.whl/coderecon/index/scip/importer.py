"""SCIP → ref_facts import mapper.

Maps SCIP occurrences to existing ref_facts rows by position, then sets
target_def_uid and ref_tier=PROVEN. This is the core of the SCIP integration.

Design constraints (from design-scip-integration.md):
- Map by position, never store SCIP symbol strings in the DB
- In-repo defs: match to existing def_facts by (file_id, start_line, start_col)
- External defs: generate ext::<lang>::<package>::<qualified_name> def_uid
- Never block on SCIP failures
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

import structlog
from sqlalchemy import text

from coderecon.index.scip.parser import (
    ParsedDocument,
    ParsedOccurrence,
    parse_scip_file,
)

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from coderecon.index.db import Database

log = structlog.get_logger(__name__)


@dataclass(slots=True)
class ImportStats:
    """Statistics from a SCIP import operation."""

    file_count: int = 0
    occurrence_count: int = 0
    refs_matched: int = 0
    refs_external: int = 0
    defs_matched: int = 0
    defs_created_external: int = 0


def import_scip_index(
    db: Database,
    scip_path: Path,
    languages: tuple[str, ...] | str,
    worktree_id: int = 1,
    imported_at: float | None = None,
    repo_root: Path | None = None,
    *,
    record_import: bool = True,
) -> ImportStats:
    """Import a SCIP index file into the ref_facts schema.

    This is the main import entry point. It:
    1. Parses the SCIP protobuf file
    2. Normalizes column offsets to UTF-8 byte offsets (from UTF-16/UTF-32)
    3. Resolves file paths to file_ids (filtered by worktree_id)
    4. Maps SCIP definition occurrences to existing def_facts by position
    5. Maps SCIP reference occurrences to existing ref_facts by position
    6. Sets target_def_uid + ref_tier=PROVEN on matched refs
    7. Creates synthetic external def_facts for stdlib/dependency symbols
       (using each document's actual language for the ext:: prefix)
    8. Records import metadata in scip_imports table (one row per language)

    Args:
        db: Database instance
        scip_path: Path to .scip protobuf file
        languages: Language(s) covered by this import (for scip_imports records)
        worktree_id: Active worktree ID to scope file lookups
        imported_at: Timestamp to record as import time. Use the time BEFORE
            the indexer ran so any files modified during indexing are detected
            as stale on the next run. Defaults to time.time() if not provided.
        repo_root: Repository root for reading source files when column
            encoding conversion is needed (UTF-16/UTF-32 → byte offset).
        record_import: Whether to record this import in the ``scip_imports``
            table.  Set to ``False`` for partial/incremental runs that don't
            cover the full project — otherwise the timestamp poisons the
            staleness check for subsequent full-project runs.

    Returns ImportStats with counts of what was matched/created.
    """
    # Normalize languages to tuple
    if isinstance(languages, str):
        languages = (languages,)

    documents, parse_stats = parse_scip_file(scip_path)
    if not documents:
        return ImportStats()

    # Normalize columns to byte offsets if encoding is non-UTF8
    if repo_root is not None:
        documents = _normalize_columns_to_bytes(documents, repo_root)

    stats = ImportStats(
        file_count=parse_stats.file_count,
        occurrence_count=parse_stats.total_occurrences,
    )

    with db.session() as session:
        # Step 1: Build path→file_id mapping (scoped to worktree)
        path_to_file_id = _resolve_file_ids(session, documents, worktree_id)

        # Step 2: Build SCIP symbol → def_uid mapping from definition occurrences
        symbol_to_def_uid = _map_definitions(session, documents, path_to_file_id, stats)

        # Step 3: Create external defs (using per-document language)
        _create_external_defs(session, documents, symbol_to_def_uid, worktree_id, stats)

        # Step 4: Map reference occurrences → ref_facts and set target_def_uid
        _map_references(session, documents, path_to_file_id, symbol_to_def_uid, stats)

        # Step 5: Record import metadata — one row per language
        # Use caller-provided timestamp (pre-indexer) to avoid TOCTOU:
        # files modified during indexing will have mtime > imported_at
        # and be detected as stale on the next run.
        #
        # Skipped for partial/incremental imports: their timestamp would
        # make the full-project staleness check think the entire language
        # was freshly indexed, suppressing the next full run.
        if record_import:
            ts = imported_at if imported_at is not None else time.time()
            for i, lang in enumerate(languages):
                # Record aggregate stats only on the first language row to avoid
                # double-counting when a single tool covers multiple languages.
                session.execute(
                    text("""
                        INSERT INTO scip_imports (language, scip_path, imported_at,
                            file_count, occurrence_count, refs_matched, refs_external)
                        VALUES (:lang, :path, :ts, :files, :occs, :matched, :external)
                    """),
                    {
                        "lang": lang,
                        "path": str(scip_path),
                        "ts": ts,
                        "files": stats.file_count if i == 0 else 0,
                        "occs": stats.occurrence_count if i == 0 else 0,
                        "matched": stats.refs_matched if i == 0 else 0,
                        "external": stats.refs_external if i == 0 else 0,
                    },
                )
        session.commit()

    log.info(
        "scip.import_stats",
        extra={
            "languages": languages,
            "files": stats.file_count,
            "refs_matched": stats.refs_matched,
            "refs_external": stats.refs_external,
            "defs_matched": stats.defs_matched,
            "defs_external": stats.defs_created_external,
        },
    )
    return stats


# --- Column encoding conversion ---

_UTF8 = 1  # UTF8CodeUnitOffsetFromLineStart
_UTF16 = 2  # UTF16CodeUnitOffsetFromLineStart
_UTF32 = 3  # UTF32CodeUnitOffsetFromLineStart


def _utf16_col_to_byte_col(line_text: str, utf16_col: int) -> int:
    """Convert a UTF-16 code unit offset to a UTF-8 byte offset on a line."""
    utf16_units = 0
    for i, ch in enumerate(line_text):
        if utf16_units >= utf16_col:
            return len(line_text[:i].encode("utf-8"))
        # Supplementary characters (above U+FFFF) use 2 UTF-16 code units
        utf16_units += 2 if ord(ch) > 0xFFFF else 1
    return len(line_text.encode("utf-8"))


def _utf32_col_to_byte_col(line_text: str, codepoint_col: int) -> int:
    """Convert a UTF-32 (codepoint) offset to a UTF-8 byte offset on a line."""
    # Python str index == codepoint index
    prefix = line_text[:codepoint_col]
    return len(prefix.encode("utf-8"))


def _convert_col(line_text: str, col: int, encoding: int) -> int:
    """Convert a column offset to byte offset given the position encoding."""
    if encoding == _UTF8:
        return col
    elif encoding == _UTF16 or encoding == 0:
        # Unspecified (0) defaults to UTF-16 per SCIP spec
        return _utf16_col_to_byte_col(line_text, col)
    elif encoding == _UTF32:
        return _utf32_col_to_byte_col(line_text, col)
    return col


def _normalize_columns_to_bytes(
    documents: list[ParsedDocument], repo_root: Path
) -> list[ParsedDocument]:
    """Convert all occurrence columns from their source encoding to byte offsets.

    Only processes documents with non-UTF8 encoding. For UTF8-encoded documents
    (encoding=1), columns are already byte offsets and are returned unchanged.
    For Unspecified (0) or UTF16 (2) or UTF32 (3), reads the source file and
    converts each occurrence's columns.
    """
    from dataclasses import replace

    result: list[ParsedDocument] = []
    for doc in documents:
        if doc.position_encoding == _UTF8:
            result.append(doc)
            continue

        # Read the source file to get line content for conversion
        file_path = repo_root / doc.relative_path
        try:
            source_lines = file_path.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError):
            # Can't read file — fall through with raw columns (best effort)
            result.append(doc)
            continue

        # Check if all lines involved are ASCII (fast path: no conversion needed)
        needs_conversion = False
        for occ in (*doc.definitions, *doc.references):
            if occ.start_line < len(source_lines):
                line = source_lines[occ.start_line]
                if not line.isascii():
                    needs_conversion = True
                    break

        if not needs_conversion:
            result.append(doc)
            continue

        # Convert columns for this document
        enc = doc.position_encoding
        new_defs: list[ParsedOccurrence] = []
        for occ in doc.definitions:
            if occ.start_line < len(source_lines):
                line = source_lines[occ.start_line]
                new_start_col = _convert_col(line, occ.start_col, enc)
                end_line_text = source_lines[occ.end_line] if occ.end_line < len(source_lines) else ""
                new_end_col = _convert_col(end_line_text, occ.end_col, enc)
            else:
                new_start_col = occ.start_col
                new_end_col = occ.end_col
            new_defs.append(replace(occ, start_col=new_start_col, end_col=new_end_col))

        new_refs: list[ParsedOccurrence] = []
        for occ in doc.references:
            if occ.start_line < len(source_lines):
                line = source_lines[occ.start_line]
                new_start_col = _convert_col(line, occ.start_col, enc)
                end_line_text = source_lines[occ.end_line] if occ.end_line < len(source_lines) else ""
                new_end_col = _convert_col(end_line_text, occ.end_col, enc)
            else:
                new_start_col = occ.start_col
                new_end_col = occ.end_col
            new_refs.append(replace(occ, start_col=new_start_col, end_col=new_end_col))

        new_doc = ParsedDocument(
            relative_path=doc.relative_path,
            language=doc.language,
            position_encoding=_UTF8,  # Now normalized to byte offsets
            definitions=new_defs,
            references=new_refs,
        )
        result.append(new_doc)

    return result


# --- File ID resolution ---


def _resolve_file_ids(session, documents: list[ParsedDocument], worktree_id: int) -> dict[str, int]:
    """Map SCIP relative_path values to file_ids in the DB.

    Scoped to a specific worktree_id to avoid ambiguity when the same path
    exists in multiple worktrees.
    """
    paths = [doc.relative_path for doc in documents]
    if not paths:
        return {}

    path_to_file_id: dict[str, int] = {}

    # Batch query for file_ids, filtered by worktree
    for chunk_start in range(0, len(paths), 500):
        chunk = paths[chunk_start : chunk_start + 500]
        placeholders = ", ".join(f":p{i}" for i in range(len(chunk)))
        params: dict[str, int | str] = {f"p{i}": p for i, p in enumerate(chunk)}
        params["wt"] = worktree_id
        rows = session.execute(
            text(f"SELECT id, path FROM files WHERE worktree_id = :wt AND path IN ({placeholders})"),
            params,
        ).fetchall()
        for file_id, path in rows:
            path_to_file_id[path] = file_id

    return path_to_file_id


def _map_definitions(
    session,
    documents: list[ParsedDocument],
    path_to_file_id: dict[str, int],
    stats: ImportStats,
) -> dict[str, str]:
    """Map SCIP definition occurrences to existing def_facts by position.

    Returns mapping of SCIP symbol string → def_uid for use in reference resolution.
    """
    symbol_to_def_uid: dict[str, str] = {}

    for doc in documents:
        file_id = path_to_file_id.get(doc.relative_path)
        if file_id is None:
            continue

        for defn in doc.definitions:
            # SCIP uses 0-indexed lines; our DB uses 1-indexed lines, 0-indexed cols
            db_line = defn.start_line + 1
            db_col = defn.start_col

            # Match to existing def_fact by position
            row = session.execute(
                text("""
                    SELECT def_uid FROM def_facts
                    WHERE file_id = :fid AND start_line = :line AND start_col = :col
                    LIMIT 1
                """),
                {"fid": file_id, "line": db_line, "col": db_col},
            ).fetchone()

            if row:
                symbol_to_def_uid[defn.symbol] = row[0]
                stats.defs_matched += 1
            # If no exact position match, try matching by line only (wider tolerance)
            else:
                row = session.execute(
                    text("""
                        SELECT def_uid, name FROM def_facts
                        WHERE file_id = :fid AND start_line = :line
                    """),
                    {"fid": file_id, "line": db_line},
                ).fetchall()
                if len(row) == 1:
                    # Unambiguous: only one def on this line
                    symbol_to_def_uid[defn.symbol] = row[0][0]
                    stats.defs_matched += 1

    return symbol_to_def_uid


def _extract_qualified_name(symbol: str) -> tuple[str, str]:
    """Extract package name and qualified name from a SCIP symbol string.

    SCIP symbol format: <scheme> ' ' <manager> ' ' <package_name> ' ' <version> ' ' <descriptors>+
    We extract the package_name and descriptor names joined by '.' for the
    external def_uid.

    Returns (package_name, qualified_name).
    """
    # Split into: scheme, manager, package_name, version, descriptors
    parts = symbol.split(" ", 4)
    if len(parts) < 5:
        # Fallback: use the whole symbol (stripped)
        fallback = symbol.replace(" ", ".").replace("/", ".").rstrip(".#()")
        return ("_", fallback)

    package_name = parts[2] if parts[2] != "." else "_"
    descriptor_part = parts[4]

    # Extract names from descriptors (strip suffix chars: / # . () [])
    names: list[str] = []
    current = ""
    i = 0
    while i < len(descriptor_part):
        ch = descriptor_part[i]
        if ch in "/#.!:":
            if current:
                names.append(current)
            current = ""
        elif ch == "(":
            if current:
                names.append(current)
            current = ""
            # Skip to closing ).
            while i < len(descriptor_part) and descriptor_part[i] != ")":
                i += 1
            if i < len(descriptor_part) and i + 1 < len(descriptor_part) and descriptor_part[i + 1] == ".":
                i += 1  # Skip the trailing .
        elif ch == "[":
            # Skip type parameters
            while i < len(descriptor_part) and descriptor_part[i] != "]":
                i += 1
        elif ch == "`":
            # Escaped identifier
            i += 1
            while i < len(descriptor_part) and descriptor_part[i] != "`":
                current += descriptor_part[i]
                i += 1
        else:
            current += ch
        i += 1

    if current:
        names.append(current)

    qualified = ".".join(names) if names else symbol[:100]
    return (package_name, qualified)


def _create_external_defs(
    session,
    documents: list[ParsedDocument],
    symbol_to_def_uid: dict[str, str],
    worktree_id: int,
    stats: ImportStats,
) -> None:
    """Create synthetic def_facts for symbols not found in the repo.

    These represent stdlib/dependency definitions that refs point to.
    Uses ext::<lang>::<package>::<qualified_name> as the def_uid, where lang is
    derived from the SCIP document that references the symbol and package is
    from the SCIP symbol's package field.
    """
    # Build symbol → language mapping from the documents that reference them
    symbol_language: dict[str, str] = {}
    all_ref_symbols: set[str] = set()
    for doc in documents:
        for ref in doc.references:
            if ref.symbol not in symbol_to_def_uid:
                all_ref_symbols.add(ref.symbol)
                # Use the document's language (first occurrence wins)
                if ref.symbol not in symbol_language and doc.language:
                    symbol_language[ref.symbol] = doc.language

    if not all_ref_symbols:
        return

    # We need a file_id for external defs — use a sentinel external file
    # Scoped to the active worktree
    row = session.execute(
        text("SELECT id FROM files WHERE path = '__external__' AND worktree_id = :wt LIMIT 1"),
        {"wt": worktree_id},
    ).fetchone()
    if row:
        external_file_id = row[0]
    else:
        session.execute(
            text("INSERT INTO files (path, worktree_id) VALUES ('__external__', :wt)"),
            {"wt": worktree_id},
        )
        row = session.execute(text("SELECT last_insert_rowid()")).fetchone()
        external_file_id = row[0]

    # Batch-create external defs
    for symbol in all_ref_symbols:
        package, qualified = _extract_qualified_name(symbol)
        lang = symbol_language.get(symbol, "unknown")
        def_uid = f"ext::{lang}::{package}::{qualified}"

        # Skip if already exists
        existing = session.execute(
            text("SELECT 1 FROM def_facts WHERE def_uid = :uid LIMIT 1"),
            {"uid": def_uid},
        ).fetchone()
        if existing:
            symbol_to_def_uid[symbol] = def_uid
            continue

        # Extract simple name from qualified
        simple_name = qualified.rsplit(".", 1)[-1] if "." in qualified else qualified

        session.execute(
            text("""
                INSERT OR IGNORE INTO def_facts
                    (def_uid, file_id, unit_id, kind, name, qualified_name,
                     lexical_path, start_line, start_col, end_line, end_col, is_external)
                VALUES (:uid, :fid, 1, 'function', :name, :qname,
                        :lpath, 0, 0, 0, 0, 1)
            """),
            {
                "uid": def_uid,
                "fid": external_file_id,
                "name": simple_name,
                "qname": qualified,
                "lpath": qualified,
            },
        )
        symbol_to_def_uid[symbol] = def_uid
        stats.defs_created_external += 1

    stats.refs_external = len(all_ref_symbols)


def _map_references(
    session,
    documents: list[ParsedDocument],
    path_to_file_id: dict[str, int],
    symbol_to_def_uid: dict[str, str],
    stats: ImportStats,
) -> None:
    """Map SCIP reference occurrences to ref_facts and set target_def_uid.

    For each SCIP reference occurrence:
    1. Look up the ref_fact by (file_id, start_line, start_col)
    2. Resolve the SCIP symbol to a def_uid via symbol_to_def_uid
    3. UPDATE ref_facts SET target_def_uid, ref_tier='proven', certainty='certain'
    """
    batch_updates: list[dict] = []

    for doc in documents:
        file_id = path_to_file_id.get(doc.relative_path)
        if file_id is None:
            continue

        for ref in doc.references:
            target_uid = symbol_to_def_uid.get(ref.symbol)
            if target_uid is None:
                continue

            # SCIP 0-indexed → DB 1-indexed lines
            db_line = ref.start_line + 1
            db_col = ref.start_col

            batch_updates.append({
                "fid": file_id,
                "line": db_line,
                "col": db_col,
                "target": target_uid,
            })

    if not batch_updates:
        return

    # Batch update ref_facts
    # Process in chunks to avoid SQLite variable limits
    matched = 0
    for chunk_start in range(0, len(batch_updates), 500):
        chunk = batch_updates[chunk_start : chunk_start + 500]
        for params in chunk:
            result = session.execute(
                text("""
                    UPDATE ref_facts
                    SET target_def_uid = :target,
                        ref_tier = 'proven',
                        certainty = 'certain'
                    WHERE file_id = :fid
                      AND start_line = :line
                      AND start_col = :col
                      AND target_def_uid IS NULL
                """),
                params,
            )
            matched += result.rowcount

    stats.refs_matched = matched
