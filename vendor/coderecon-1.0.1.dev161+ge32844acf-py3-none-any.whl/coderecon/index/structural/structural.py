"""Structural indexer — parallel file processing and fact persistence."""

from __future__ import annotations

import os
import re
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from coderecon.index.db import Database
    from coderecon.index.db.database import BulkWriter

from coderecon._core.languages import is_test_file
from coderecon.config.constants import MS_PER_SEC
from coderecon.index.structural.extract import (
    _extract_file,
)
from coderecon.index.structural.helpers import (
    BatchResult,
    ExtractionResult,
    _apply_worktree_uid_remap,
)
from coderecon.index.structural.resolve import (
    _augment_declared_modules,
    _resolve_import_paths,
    _resolve_xref_target,
)
from coderecon.index.structural.resolve import (
    resolve_all_imports as _resolve_all_imports_impl,
)
from coderecon.index.models import (
    DefFact,
    DefNamePart,
    DocCrossRef,
    DynamicAccessSite,
    EndpointFact,
    File,
    ImportFact,
    InterfaceImplFact,
    LocalBindFact,
    MemberAccessFact,
    ReceiverShapeFact,
    RefFact,
    ScopeFact,
    TypeAnnotationFact,
    TypeMemberFact,
)

log = structlog.get_logger(__name__)

# Canonical list of per-file fact tables (keyed by file_id).
_FILE_FACT_TABLES: tuple[type, ...] = (
    DefFact, RefFact, LocalBindFact, ImportFact, DynamicAccessSite,
    TypeAnnotationFact, TypeMemberFact, MemberAccessFact, InterfaceImplFact,
    ReceiverShapeFact, EndpointFact, ScopeFact,
)

class StructuralIndexer:
    """Extracts facts from source files using Tree-sitter.
    This is the Tier 1 (syntactic) indexing layer. It provides:
    - DefFact extraction (function/class/method definitions)
    - RefFact extraction (identifier occurrences)
    - ScopeFact extraction (lexical scopes)
    - ImportFact extraction (import statements)
    - LocalBindFact extraction (same-file bindings)
    - DynamicAccessSite extraction (dynamic access telemetry)
    Files whose language has no tree-sitter grammar (e.g., F#, VB.NET, Erlang)
    are gracefully skipped by this indexer. They will still be searchable via
    the lexical (Tantivy) index.
    Usage::
        indexer = StructuralIndexer(db, repo_path)
        result = indexer.index_files(file_paths, context_id=1, worktree_id=wt_id)
    """
    def __init__(self, db: Database, repo_path: Path | str) -> None:
        self.db = db
        self.repo_path = Path(repo_path)
    def extract_files(
        self,
        file_paths: list[str],
        context_id: int,
        workers: int = 1,
        *,
        repo_root: Path | str | None = None,
    ) -> list[ExtractionResult]:
        """Extract facts from files without persisting.
        Returns ExtractionResult list that can be passed to
        index_files(_extractions=...) for persistence.
        Each result includes content_text and symbol_names for
        unified single-pass indexing (lexical + structural).
        ``repo_root`` overrides the default ``self.repo_path`` for file
        reading.  Pass the worktree checkout directory when indexing a
        git worktree so files are read from the correct location.
        """
        effective_root = Path(repo_root) if repo_root is not None else self.repo_path
        if workers > 1 and len(file_paths) > 1:
            return self._parallel_extract(file_paths, context_id, workers, repo_root=effective_root)
        return self._sequential_extract(file_paths, context_id, repo_root=effective_root)
    def index_files(
        self,
        file_paths: list[str],
        context_id: int,
        file_id_map: dict[str, int] | None = None,
        workers: int = 1,
        *,
        worktree_id: int,
        is_main_worktree: bool = True,
        _extractions: list[ExtractionResult] | None = None,
        repo_root: Path | str | None = None,
    ) -> BatchResult:
        """Index a batch of files.
        If _extractions is provided, uses pre-computed extraction results
        instead of extracting from disk. This enables single-pass indexing
        where the coordinator extracts once and reuses results for both
        Tantivy staging and structural fact persistence.
        """
        start = time.monotonic()
        result = BatchResult()
        effective_root = Path(repo_root) if repo_root is not None else self.repo_path
        if _extractions is not None:
            extractions = _extractions
        elif workers > 1:
            extractions = self._parallel_extract(file_paths, context_id, workers)
        else:
            extractions = self._sequential_extract(file_paths, context_id)
        # Augment declared_module for languages needing config file resolution
        # (Go → go.mod, Rust → Cargo.toml). Tree-sitter gives Go only the
        # short package name; the full import path needs go.mod context.
        self._augment_declared_modules(extractions, repo_root=effective_root, worktree_id=worktree_id)
        # Resolve import source_literal → target file path (all languages).
        # Must run after _augment_declared_modules so Go/Rust declared_modules
        # are fully resolved.  Populates import_dict["resolved_path"].
        self._resolve_import_paths(extractions, repo_root=effective_root, worktree_id=worktree_id)
        # Batch-upsert all File records in a single transaction.
        if file_id_map is None:
            file_id_map = {}
        file_id_map = self._ensure_file_ids_batch(
            extractions, context_id, worktree_id, file_id_map,
        )
        # Remap def_uid / import_uid to include worktree_id so that two
        # worktrees indexing the same file don't collide on PK constraints.
        for extraction in extractions:
            if not extraction.error:
                _apply_worktree_uid_remap(
                    extraction, worktree_id, is_main_worktree=is_main_worktree
                )
        with self.db.bulk_writer() as writer:
            for extraction in extractions:
                result.files_processed += 1
                if extraction.error:
                    result.errors.append(f"{extraction.file_path}: {extraction.error}")
                    continue
                if extraction.skipped_no_grammar:
                    result.files_skipped_no_grammar += 1
                    continue
                file_id = file_id_map.get(extraction.file_path)
                if file_id is None:
                    result.errors.append(f"{extraction.file_path}: File ID not found")
                    continue
                _persist_single_extraction(writer, extraction, file_id, result, self)
        result.duration_ms = int((time.monotonic() - start) * MS_PER_SEC)
        return result
    def _augment_declared_modules(self, extractions: list[ExtractionResult], *, repo_root: Path | None = None, worktree_id: int) -> None:
        """Post-process declared_module for languages needing config files."""
        _augment_declared_modules(self.db, repo_root or self.repo_path, extractions, worktree_id=worktree_id)
    def _resolve_xref_target(self, writer: BulkWriter, target_name: str) -> str | None:
        """Resolve a cross-ref target name to a def_uid."""
        return _resolve_xref_target(writer, target_name)
    def _resolve_import_paths(self, extractions: list[ExtractionResult], *, repo_root: Path | None = None, worktree_id: int) -> None:
        """Resolve import source_literal to target file path."""
        _resolve_import_paths(self.db, repo_root or self.repo_path, extractions, worktree_id=worktree_id)
    def resolve_all_imports(self, *, worktree_id: int) -> int:
        """Re-resolve all unresolved import paths using the complete DB."""
        return _resolve_all_imports_impl(self.db, self.repo_path, worktree_id=worktree_id)
    def _sequential_extract(
        self, file_paths: list[str], unit_id: int, repo_root: Path | None = None
    ) -> list[ExtractionResult]:
        """Extract facts sequentially."""
        root = str(repo_root if repo_root is not None else self.repo_path)
        results = []
        for path in file_paths:
            result = _extract_file(path, root, unit_id)
            results.append(result)
        return results
    def _parallel_extract(
        self, file_paths: list[str], unit_id: int, workers: int, repo_root: Path | None = None
    ) -> list[ExtractionResult]:
        """Extract facts in parallel using process pool."""
        results = []
        root = str(repo_root if repo_root is not None else self.repo_path)
        with ProcessPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(_extract_file, path, root, unit_id): path
                for path in file_paths
            }
            for future in as_completed(futures):
                try:
                    result = future.result()
                    results.append(result)
                except (OSError, UnicodeDecodeError, RuntimeError, ValueError) as e:
                    path = futures[future]
                    results.append(ExtractionResult(file_path=path, error=str(e)))
        return results
    def _ensure_file_ids_batch(
        self,
        extractions: list[ExtractionResult],
        context_id: int,
        worktree_id: int,
        file_id_map: dict[str, int],
    ) -> dict[str, int]:
        """Batch-upsert File records for all extractions in one transaction.

        Returns updated file_id_map with path → file.id mappings.
        """
        import time as _time
        from sqlalchemy import text as _sa_text
        from sqlmodel import col, select

        # Collect file metadata from extractions
        file_records: dict[str, dict] = {}
        for extraction in extractions:
            if extraction.file_path in file_id_map:
                continue
            if extraction.error:
                ps = "failed"
            elif extraction.skipped_no_grammar:
                ps = "skipped"
            else:
                ps = "ok"
            file_records[extraction.file_path] = {
                "path": extraction.file_path,
                "content_hash": extraction.content_hash,
                "line_count": extraction.line_count,
                "language_family": extraction.language_family,
                "declared_module": extraction.declared_module if not extraction.error else None,
                "indexed_at": _time.time(),
                "worktree_id": worktree_id,
                "parse_status": ps,
                "is_test": is_test_file(extraction.file_path),
            }

        if not file_records:
            return file_id_map

        paths = list(file_records.keys())

        with self.db.session() as session:
            # Fetch existing files in one query
            existing_files = list(session.exec(
                select(File).where(
                    col(File.path).in_(paths),
                    File.worktree_id == worktree_id,
                )
            ).all())
            existing_map = {f.path: f for f in existing_files}

            # Update existing records
            for path, rec in file_records.items():
                existing = existing_map.get(path)
                if existing and existing.id is not None:
                    _changed = False
                    if existing.declared_module != rec["declared_module"]:
                        existing.declared_module = rec["declared_module"]
                        _changed = True
                    if rec["parse_status"] is not None and existing.parse_status != rec["parse_status"]:
                        existing.parse_status = rec["parse_status"]
                        _changed = True
                    if rec["content_hash"] is not None and existing.content_hash != rec["content_hash"]:
                        existing.content_hash = rec["content_hash"]
                        existing.line_count = rec["line_count"]
                        _changed = True
                    if _changed:
                        session.add(existing)
                    file_id_map[path] = existing.id

            # Insert new records in bulk
            new_records = [rec for path, rec in file_records.items() if path not in existing_map]
            if new_records:
                table = File.__table__  # type: ignore[attr-defined]
                session.execute(table.insert(), new_records)
                session.flush()
                # Fetch IDs for newly inserted files
                new_paths = [rec["path"] for rec in new_records]
                new_files = list(session.exec(
                    select(File).where(
                        col(File.path).in_(new_paths),
                        File.worktree_id == worktree_id,
                    )
                ).all())
                for f in new_files:
                    if f.id is not None:
                        file_id_map[f.path] = f.id

            session.commit()

        # Verify all paths got IDs
        for path in paths:
            if path not in file_id_map:
                raise RuntimeError(f"Failed to allocate file id for {path!r}")

        return file_id_map

    def _ensure_file_id(
        self,
        file_path: str,
        content_hash: str | None,
        line_count: int,
        _context_id: int,
        language_family: str | None = None,
        declared_module: str | None = None,
        *,
        worktree_id: int,
        parse_status: str | None = None,
    ) -> int:
        """Ensure file exists in database and return its ID."""
        import time
        with self.db.session() as session:
            from sqlmodel import select
            stmt = select(File).where(
                File.path == file_path,
                File.worktree_id == worktree_id,
            )
            existing = session.exec(stmt).first()
            if existing and existing.id is not None:
                _changed = False
                if existing.declared_module != declared_module:
                    existing.declared_module = declared_module
                    _changed = True
                if parse_status is not None and existing.parse_status != parse_status:
                    existing.parse_status = parse_status
                    _changed = True
                if content_hash is not None and existing.content_hash != content_hash:
                    existing.content_hash = content_hash
                    existing.line_count = line_count
                    _changed = True
                if _changed:
                    session.add(existing)
                    session.commit()
                return existing.id
            file = File(
                path=file_path,
                content_hash=content_hash,
                line_count=line_count,
                language_family=language_family,
                declared_module=declared_module,
                indexed_at=time.time(),
                worktree_id=worktree_id,
                parse_status=parse_status,
            )
            session.add(file)
            session.commit()
            session.refresh(file)
            if file.id is None:
                raise RuntimeError(f"Failed to allocate file id for {file_path!r}")
            return file.id
    def extract_single(self, file_path: str, unit_id: int = 0) -> ExtractionResult:
        """Extract facts from a single file without storing."""
        return _extract_file(file_path, str(self.repo_path), unit_id)
def index_context(
    db: Database,
    repo_path: Path | str,
    context_id: int,
    file_paths: list[str],
    workers: int = os.cpu_count() or 1,
    *,
    worktree_id: int,
) -> BatchResult:
    """Convenience function to index all files in a context."""
    indexer = StructuralIndexer(db, repo_path)
    return indexer.index_files(file_paths, context_id, workers=workers, worktree_id=worktree_id)


def _split_def_name(name: str) -> list[str]:
    """Split a definition name into lowercase constituent parts (≥3 chars)."""
    parts = re.split(r"[_\W]+", name)
    out: list[str] = []
    for p in parts:
        if not p:
            continue
        sub = re.sub(r"(?<!^)(?=[A-Z])", " ", p).lower().split()
        out.extend(sub)
    return [part for part in out if len(part) >= 3]


def _normalize_batch(records: list[dict]) -> list[dict]:
    """Ensure all dicts in a batch have identical key sets for executemany."""
    if not records:
        return records
    all_keys = set()
    for r in records:
        all_keys.update(r.keys())
    for r in records:
        for k in all_keys:
            r.setdefault(k, None)
    return records


def _persist_single_extraction(
    writer: Any,
    extraction: ExtractionResult,
    file_id: int,
    result: BatchResult,
    indexer: StructuralIndexer,
) -> None:
    """Persist all facts from a single extraction into the database."""
    # Delete existing facts for idempotent re-indexing
    for fact_model in _FILE_FACT_TABLES:
        writer.delete_where(fact_model, "file_id = :fid", {"fid": file_id})
    writer.delete_where(DocCrossRef, "source_file_id = :fid", {"fid": file_id})
    # Build local_scope_id -> db_scope_id mapping
    # Pre-allocate IDs client-side to avoid 2 statements per scope.
    scope_id_map: dict[int, int] = {}
    if extraction.scopes:
        from sqlalchemy import text as _sa_text
        max_id_row = writer.conn.execute(
            _sa_text("SELECT COALESCE(MAX(scope_id), 0) FROM scope_facts")
        ).fetchone()
        next_id = (max_id_row[0] if max_id_row else 0) + 1
        scope_batch: list[dict] = []
        for scope_dict in extraction.scopes:
            local_id = scope_dict.pop("local_scope_id")
            parent_local_id = scope_dict.pop("parent_local_scope_id")
            assigned_id = next_id
            next_id += 1
            scope_dict["scope_id"] = assigned_id
            scope_dict["file_id"] = file_id
            scope_dict["parent_scope_id"] = (
                scope_id_map[parent_local_id]
                if parent_local_id is not None and parent_local_id in scope_id_map
                else None
            )
            scope_id_map[local_id] = assigned_id
            scope_batch.append(scope_dict)
        writer.insert_many(ScopeFact, _normalize_batch(scope_batch))
        result.scopes_extracted += len(scope_batch)
    # --- Batch defs ---
    name_parts_batch: list[dict[str, str]] = []
    for def_dict in extraction.defs:
        def_dict["file_id"] = file_id
        def_uid = def_dict.get("def_uid")
        def_name = def_dict.get("name")
        if def_uid and def_name:
            parts = set(_split_def_name(def_name))
            for part in parts:
                name_parts_batch.append({"part": part, "def_uid": def_uid})
    if extraction.defs:
        writer.insert_many(DefFact, _normalize_batch(extraction.defs))
        result.defs_extracted += len(extraction.defs)
    if name_parts_batch:
        writer.insert_many_or_ignore(DefNamePart, name_parts_batch)
    # --- Batch refs ---
    refs_batch: list[dict] = []
    for ref_dict in extraction.refs:
        ref_dict["file_id"] = file_id
        local_sid = ref_dict.pop("local_scope_id", None)
        ref_dict["scope_id"] = scope_id_map.get(local_sid) if local_sid else None
        refs_batch.append(ref_dict)
    if refs_batch:
        writer.insert_many(RefFact, _normalize_batch(refs_batch))
        result.refs_extracted += len(refs_batch)
    # --- Batch imports ---
    imports_batch: list[dict] = []
    seen_import_uids: set[str] = set()
    for import_dict in extraction.imports:
        uid = import_dict.get("import_uid")
        if isinstance(uid, str) and uid:
            if uid in seen_import_uids:
                continue
            seen_import_uids.add(uid)
        import_dict["file_id"] = file_id
        import_dict.pop("_start_line", None)
        import_dict.pop("_start_col", None)
        imports_batch.append(import_dict)
    if imports_batch:
        writer.insert_many(ImportFact, _normalize_batch(imports_batch))
        result.imports_extracted += len(imports_batch)
    # --- Batch local binds ---
    binds_batch: list[dict] = []
    for bind_dict in extraction.binds:
        bind_dict["file_id"] = file_id
        local_sid = bind_dict.pop("local_scope_id", None)
        bind_dict["scope_id"] = scope_id_map.get(local_sid) if local_sid else None
        binds_batch.append(bind_dict)
    if binds_batch:
        writer.insert_many(LocalBindFact, _normalize_batch(binds_batch))
        result.binds_extracted += len(binds_batch)
    # --- Batch dynamic access sites ---
    if extraction.dynamic_sites:
        for dyn_dict in extraction.dynamic_sites:
            dyn_dict["file_id"] = file_id
        writer.insert_many(DynamicAccessSite, _normalize_batch(extraction.dynamic_sites))
        result.dynamic_sites_extracted += len(extraction.dynamic_sites)
    # --- Batch type annotations ---
    if extraction.type_annotations:
        for ann_dict in extraction.type_annotations:
            ann_dict["file_id"] = file_id
        writer.insert_many(TypeAnnotationFact, _normalize_batch(extraction.type_annotations))
        result.type_annotations_extracted += len(extraction.type_annotations)
    # --- Batch type members ---
    if extraction.type_members:
        for mem_dict in extraction.type_members:
            mem_dict["file_id"] = file_id
        writer.insert_many(TypeMemberFact, _normalize_batch(extraction.type_members))
        result.type_members_extracted += len(extraction.type_members)
    # --- Batch member accesses ---
    if extraction.member_accesses:
        for acc_dict in extraction.member_accesses:
            acc_dict["file_id"] = file_id
        writer.insert_many(MemberAccessFact, _normalize_batch(extraction.member_accesses))
        result.member_accesses_extracted += len(extraction.member_accesses)
    # --- Batch interface impls ---
    if extraction.interface_impls:
        for impl_dict in extraction.interface_impls:
            impl_dict["file_id"] = file_id
        writer.insert_many(InterfaceImplFact, _normalize_batch(extraction.interface_impls))
        result.interface_impls_extracted += len(extraction.interface_impls)
    # --- Batch receiver shapes ---
    if extraction.receiver_shapes:
        for shape_dict in extraction.receiver_shapes:
            shape_dict["file_id"] = file_id
        writer.insert_many(ReceiverShapeFact, _normalize_batch(extraction.receiver_shapes))
        result.receiver_shapes_extracted += len(extraction.receiver_shapes)
    # Detect and insert EndpointFacts
    if extraction.content_text and extraction.language:
        from coderecon.index.analysis.endpoint_detection import (
            detect_endpoints_in_source,
        )
        endpoints = detect_endpoints_in_source(
            extraction.content_text, extraction.language
        )
        if endpoints:
            func_defs = [
                d for d in extraction.defs
                if d.get("kind") in ("function", "method")
            ]
            ep_batch: list[dict] = []
            for ep in endpoints:
                handler_uid = None
                for d in func_defs:
                    if d["start_line"] <= ep.line <= d["end_line"]:
                        handler_uid = d["def_uid"]
                ep_batch.append({
                    "file_id": file_id,
                    "kind": ep.kind,
                    "http_method": ep.http_method,
                    "url_pattern": ep.url_pattern,
                    "handler_def_uid": handler_uid,
                    "start_line": ep.line,
                    "end_line": ep.line,
                    "framework": ep.framework,
                })
            if ep_batch:
                writer.insert_many(EndpointFact, _normalize_batch(ep_batch))
    # Extract and insert DocCrossRefs from docstrings
    if extraction.defs:
        from coderecon.index.analysis.docstring_xref import (
            extract_cross_refs,
        )
        xref_batch: list[dict] = []
        for def_dict in extraction.defs:
            docstring = def_dict.get("docstring")
            if not docstring:
                continue
            raw_refs = extract_cross_refs(
                docstring, start_line=def_dict["start_line"]
            )
            if not raw_refs:
                continue
            for ref in raw_refs:
                target_uid = indexer._resolve_xref_target(
                    writer, ref.target_name
                )
                if target_uid:
                    xref_batch.append({
                        "source_file_id": file_id,
                        "source_def_uid": def_dict.get("def_uid"),
                        "source_line": ref.source_line,
                        "raw_text": ref.raw_text,
                        "target_def_uid": target_uid,
                        "confidence": ref.confidence,
                    })
        if xref_batch:
            writer.insert_many(DocCrossRef, _normalize_batch(xref_batch))
