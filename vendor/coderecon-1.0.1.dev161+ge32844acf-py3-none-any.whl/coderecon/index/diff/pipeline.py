"""Structural diff pipeline — compute diff from git refs without MCP/daemon.

This module provides the transport-agnostic diff pipeline that can be used
by both the MCP tool layer and the standalone review SDK.
"""

from __future__ import annotations

import contextlib
import re
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

from coderecon._core.languages import detect_language_family, has_grammar
from coderecon.adapters.git.models import _DELTA_CHAR_MAP
from coderecon.index.diff.engine import compute_structural_diff
from coderecon.index.diff.enrichment import enrich_diff
from coderecon.index.diff.models import (
    AnalysisScope,
    ChangedFile,
    DefSnapshot,
    SemanticDiffResult,
)
from coderecon.index.diff.sources import (
    snapshots_from_blob,
    snapshots_from_index,
)

if TYPE_CHECKING:
    from coderecon.adapters.git.ops import GitOps
    from coderecon.index.db import Database

log = structlog.get_logger(__name__)

_PREVIEW_MAX_LINES = 5


def run_structural_diff(
    db: Database,
    git_ops: GitOps,
    repo_root: Path,
    *,
    worktree_id: int,
    base: str = "HEAD",
    target: str | None = None,
    paths: list[str] | None = None,
) -> SemanticDiffResult:
    """Compute a structural diff between two git states.

    This is the low-level entry point used by the lite review SDK and
    internally by the MCP tool layer. No dependency on fastmcp, daemon,
    or any heavy infrastructure.

    Args:
        db: Database instance with indexed structural facts.
        git_ops: GitOps instance for the repository.
        repo_root: Repository root path.
        base: Base ref (commit, branch, tag).
        target: Target ref (None = working tree).
        paths: Optional path filter.
    """
    from coderecon.adapters.git._internal.planners import DiffPlanner

    planner = DiffPlanner(git_ops._access)
    plan = planner.plan(base=base, target=target, staged=False)
    diff_result = planner.execute(plan)
    # Extract changed files from numstat
    changed_files: list[ChangedFile] = []
    hunks: dict[str, list[tuple[int, int]]] = {}
    for status_char, _adds, _dels, file_path in diff_result.numstat:
        if paths and file_path not in paths:
            continue
        status = _DELTA_CHAR_MAP.get(status_char, "modified")
        lang = detect_language_family(file_path)
        file_has_grammar = bool(lang and has_grammar(lang))
        changed_files.append(ChangedFile(file_path, status, file_has_grammar, language=lang))
    # Extract hunks from unified diff text
    _HUNK_RE = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@", re.MULTILINE)
    current_file: str | None = None
    for line in diff_result.diff_text.splitlines():
        if line.startswith("+++ b/"):
            current_file = line[6:]
            if current_file not in hunks:
                hunks[current_file] = []
        elif line.startswith("+++ /dev/null"):
            current_file = None
        elif current_file:
            m = _HUNK_RE.match(line)
            if m:
                start = int(m.group(1))
                count = int(m.group(2)) if m.group(2) else 1
                end = start + count - 1
                if end >= start:
                    hunks[current_file].append((start, end))
    # Build snapshots for each file
    base_facts: dict[str, list[DefSnapshot]] = {}
    target_facts: dict[str, list[DefSnapshot]] = {}
    # Resolve base ref for blob parsing
    base_sha = plan.base_sha
    # Single session for all index lookups + enrichment
    with db.session() as session:
        for cf in changed_files:
            if not cf.has_grammar:
                continue
            # Target: current index state
            target_facts[cf.path] = snapshots_from_index(session, cf.path)
            # Base: parse from git blob (CPU, no DB)
            if base_sha and cf.status != "added":
                base_facts[cf.path] = snapshots_from_blob(git_ops._access, base_sha, cf.path)
            else:
                base_facts[cf.path] = []
        # Run engine
        raw = compute_structural_diff(base_facts, target_facts, changed_files, hunks)
        # Enrich (reuse same session)
        result = enrich_diff(raw, session, repo_root, worktree_id=worktree_id)
    # Annotate with change previews from the actual patch lines
    _annotate_change_previews(result, diff_result.diff_text)
    result.base_description = base or "HEAD"
    result.target_description = target or "working tree"
    # Build analysis scope
    files_parsed = len([cf for cf in changed_files if cf.has_grammar])
    files_no_grammar = len([cf for cf in changed_files if not cf.has_grammar])
    languages = sorted({cf.language for cf in changed_files if cf.language})
    # Detect worktree dirty state (target is worktree when target param is None)
    worktree_dirty: bool | None = None
    if target is None:
        with contextlib.suppress(Exception):
            worktree_dirty = git_ops.status() != {}
    result.scope = AnalysisScope(
        base_sha=plan.base_sha,
        target_sha=plan.target_sha,
        worktree_dirty=worktree_dirty,
        mode="git",
        entity_id_scheme="def_uid_v1",
        files_parsed=files_parsed,
        files_no_grammar=files_no_grammar,
        languages_analyzed=languages,
    )
    return result


def _annotate_change_previews(
    result: SemanticDiffResult,
    diff_text: str,
) -> None:
    """Annotate structural changes with a text preview of what changed."""
    try:
        patch_lines = _extract_patch_lines(diff_text)
    except (ValueError, IndexError):
        return
    for change in result.structural_changes:
        if change.change not in ("body_changed", "signature_changed"):
            continue
        file_lines = patch_lines.get(change.path)
        if not file_lines:
            continue
        relevant: list[str] = []
        for origin, lineno, content in file_lines:
            if change.start_line <= lineno <= change.end_line:
                relevant.append(f"{origin} {content}")
                if len(relevant) >= _PREVIEW_MAX_LINES:
                    break
        if relevant:
            change.change_preview = "\n".join(relevant)
        if change.nested_changes:
            for nc in change.nested_changes:
                if nc.change not in ("body_changed", "signature_changed"):
                    continue
                nc_lines = patch_lines.get(nc.path)
                if not nc_lines:
                    continue
                nc_relevant: list[str] = []
                for origin, lineno, content in nc_lines:
                    if nc.start_line <= lineno <= nc.end_line:
                        nc_relevant.append(f"{origin} {content}")
                        if len(nc_relevant) >= _PREVIEW_MAX_LINES:
                            break
                if nc_relevant:
                    nc.change_preview = "\n".join(nc_relevant)


def _extract_patch_lines(
    diff_text: str,
) -> dict[str, list[tuple[str, int, str]]]:
    """Extract per-file patch lines from unified diff text."""
    hunk_re = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")
    result: dict[str, list[tuple[str, int, str]]] = {}
    current_file: str | None = None
    old_lineno = 0
    new_lineno = 0
    for line in diff_text.splitlines():
        if line.startswith("+++ b/"):
            current_file = line[6:]
            if current_file not in result:
                result[current_file] = []
        elif line.startswith("+++ /dev/null"):
            current_file = None
        elif current_file:
            m = hunk_re.match(line)
            if m:
                old_lineno = int(m.group(1))
                new_lineno = int(m.group(2))
            elif line.startswith("+"):
                result[current_file].append(("+", new_lineno, line[1:]))
                new_lineno += 1
            elif line.startswith("-"):
                result[current_file].append(("-", old_lineno, line[1:]))
                old_lineno += 1
            elif line.startswith(" "):
                old_lineno += 1
                new_lineno += 1
    return result
