"""Per-process compiled tree-sitter Query cache.

Tree-sitter ``Query`` objects are pure compiled artifacts of a
``Language`` and a query S-expression text. Compiling them is non-trivial
and was previously paid on every file extraction. Caching by
``(id(language), query_text)`` amortises the compile cost across all
files a worker processes within its lifetime.

The cache is process-local on purpose: ``Language`` objects are not
shareable across process boundaries, and each worker in
``ProcessPoolExecutor`` re-imports its grammars anyway.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from tree_sitter import Query as _TSQuery

if TYPE_CHECKING:
    import tree_sitter

_CACHE: dict[tuple[int, str], _TSQuery] = {}


def get_query(language: tree_sitter.Language, query_text: str) -> _TSQuery:
    """Return a cached compiled Query, or compile and cache one."""
    key = (id(language), query_text)
    cached = _CACHE.get(key)
    if cached is not None:
        return cached
    compiled = _TSQuery(language, query_text)
    _CACHE[key] = compiled
    return compiled


def clear() -> None:
    """Drop all cached queries (for tests)."""
    _CACHE.clear()
