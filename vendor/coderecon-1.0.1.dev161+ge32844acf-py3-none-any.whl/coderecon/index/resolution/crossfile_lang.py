"""Cross-file DB-backed resolution passes for Go, Rust, and Java.

Also contains the resolution pass registry and ``run_pass_1_5`` orchestrator.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import text
from sqlmodel import col, select

from coderecon.index.resolution.crossfile import (
    CrossFileResolutionStats,
    ResolutionPassFn,
    _build_file_filter,
    _build_unit_filter,
    resolve_namespace_refs,
    resolve_same_namespace_refs,
    resolve_star_import_refs,
)
from coderecon.index.models import (
    Certainty,
    File,
    ImportFact,
    RefTier,
    Role,
)

if TYPE_CHECKING:
    from coderecon.index.db import Database


def resolve_go_dot_import_refs(
    db: Database,
    unit_id: int | None,
    file_ids: list[int] | None = None,
    worktree_id: int = 0,
) -> CrossFileResolutionStats:
    """Upgrade UNKNOWN refs using Go dot-import evidence (DB-backed).

    For each file with ``import . "pkg"``, resolves the source package
    to a project file, and upgrades matching UNKNOWN refs to STRONG.
    """
    stats = CrossFileResolutionStats()
    file_filter, file_binds = _build_file_filter(file_ids)
    ref_unit_filter, ref_unit_binds = _build_unit_filter(unit_id, "rf")
    with db.session() as session:
        # Step 1: Find all dot imports (imported_name == "*" for go_import)
        dot_stmt = select(ImportFact).where(
            ImportFact.imported_name == "*",
            ImportFact.import_kind == "go_import",
        )
        if file_ids:
            dot_stmt = dot_stmt.where(col(ImportFact.file_id).in_(file_ids))
        if unit_id is not None:
            dot_stmt = dot_stmt.where(ImportFact.unit_id == unit_id)
        dot_imports = list(session.exec(dot_stmt).all())
        if not dot_imports:
            return stats
        # Step 2: Build package path -> file_id mapping for Go files
        file_stmt = select(File.id, File.path)
        if worktree_id:
            file_stmt = file_stmt.where(File.worktree_id == worktree_id)
        all_files: list[tuple[int | None, str]] = list(
            session.exec(file_stmt).all()
        )
        pkg_to_file_id: dict[str, int] = {}
        for fid, fpath in all_files:
            if fid is None or fpath is None:
                continue
            if fpath.endswith(".go") and not fpath.endswith("_test.go"):
                # Use directory as package path
                pkg_path = fpath.rsplit("/", 1)[0] if "/" in fpath else ""
                if pkg_path:
                    pkg_to_file_id[pkg_path] = fid
        # Step 3: Create temp mapping table
        session.execute(
            text(
                "CREATE TEMP TABLE IF NOT EXISTS _go_dot_map "
                "(importing_file_id INTEGER, source_file_id INTEGER)"
            )
        )
        session.execute(text("DELETE FROM _go_dot_map"))
        mappings: list[dict[str, int]] = []
        for dot_imp in dot_imports:
            source_literal = dot_imp.source_literal
            if not source_literal:
                continue
            # Try to find a matching Go file by package path suffix
            source_file_id = _find_go_package_file(source_literal, pkg_to_file_id)
            if source_file_id is not None:
                mappings.append(
                    {
                        "importing_file_id": dot_imp.file_id,
                        "source_file_id": source_file_id,
                    }
                )
        if not mappings:
            session.execute(text("DROP TABLE IF EXISTS _go_dot_map"))
            return stats
        for m in mappings:
            session.execute(
                text("INSERT INTO _go_dot_map VALUES (:importing_file_id, :source_file_id)"),
                m,
            )
        # Step 4: Count eligible refs - exported Go symbols are capitalized
        count_sql = text(f"""
            SELECT COUNT(DISTINCT rf.ref_id)
            FROM ref_facts rf
            JOIN _go_dot_map tsm ON tsm.importing_file_id = rf.file_id
            JOIN def_facts df ON df.file_id = tsm.source_file_id
                AND df.name = rf.token_text
                AND df.name GLOB '[A-Z]*'
            WHERE rf.ref_tier = :unknown_tier
                AND rf.role = :ref_role
                {file_filter}
                {ref_unit_filter}
        """)
        result = session.execute(
            count_sql,
            {
                "unknown_tier": RefTier.UNKNOWN.value,
                "ref_role": Role.REFERENCE.value,
                **file_binds,
                **ref_unit_binds,
            },
        )
        stats.refs_matched = result.scalar_one()
        if stats.refs_matched == 0:
            session.execute(text("DROP TABLE IF EXISTS _go_dot_map"))
            return stats
        # Step 5: Upgrade refs
        update_sql = text(f"""
            UPDATE ref_facts
            SET ref_tier = :strong_tier,
                certainty = :certain,
                target_def_uid = (
                    SELECT df.def_uid
                    FROM _go_dot_map tsm
                    JOIN def_facts df ON df.file_id = tsm.source_file_id
                        AND df.name = ref_facts.token_text
                        AND df.name GLOB '[A-Z]*'
                    WHERE tsm.importing_file_id = ref_facts.file_id
                    ORDER BY df.def_uid ASC
                    LIMIT 1
                )
            WHERE ref_id IN (
                SELECT DISTINCT rf.ref_id
                FROM ref_facts rf
                JOIN _go_dot_map tsm ON tsm.importing_file_id = rf.file_id
                JOIN def_facts df ON df.file_id = tsm.source_file_id
                    AND df.name = rf.token_text
                    AND df.name GLOB '[A-Z]*'
                WHERE rf.ref_tier = :unknown_tier
                    AND rf.role = :ref_role
                    {file_filter}
                    {ref_unit_filter}
            )
        """)
        update_result = session.execute(
            update_sql,
            {
                "strong_tier": RefTier.STRONG.value,
                "certain": Certainty.CERTAIN.value,
                "unknown_tier": RefTier.UNKNOWN.value,
                "ref_role": Role.REFERENCE.value,
                **file_binds,
                **ref_unit_binds,
            },
        )
        stats.refs_upgraded = update_result.rowcount  # type: ignore[attr-defined]
        session.execute(text("DROP TABLE IF EXISTS _go_dot_map"))
        session.commit()
    return stats


def _find_go_package_file(
    import_path: str,
    pkg_to_file_id: dict[str, int],
) -> int | None:
    """Resolve Go import path to a file_id via whole-segment suffix matching."""
    import_segments = [seg for seg in import_path.split("/") if seg]
    for pkg_path, fid in pkg_to_file_id.items():
        pkg_segments = [seg for seg in pkg_path.split("/") if seg]
        # Check if pkg_path is a suffix of import_path (segment-wise)
        if (
            len(pkg_segments) <= len(import_segments)
            and import_segments[-len(pkg_segments) :] == pkg_segments
        ):
            return fid
    return None


def resolve_rust_glob_import_refs(
    db: Database,
    unit_id: int | None,
    file_ids: list[int] | None = None,
    worktree_id: int = 0,
) -> CrossFileResolutionStats:
    """Upgrade UNKNOWN refs using Rust glob-import evidence (DB-backed).

    For each file with ``use crate::module::*;``, resolves the source module
    to a project file, and upgrades matching UNKNOWN refs to STRONG.
    """
    stats = CrossFileResolutionStats()
    file_filter, file_binds = _build_file_filter(file_ids)
    ref_unit_filter, ref_unit_binds = _build_unit_filter(unit_id, "rf")
    with db.session() as session:
        # Step 1: Find all glob imports (imported_name == "*" for rust_use)
        glob_stmt = select(ImportFact).where(
            ImportFact.imported_name == "*",
            ImportFact.import_kind == "rust_use",
        )
        if file_ids:
            glob_stmt = glob_stmt.where(col(ImportFact.file_id).in_(file_ids))
        if unit_id is not None:
            glob_stmt = glob_stmt.where(ImportFact.unit_id == unit_id)
        glob_imports = list(session.exec(glob_stmt).all())
        if not glob_imports:
            return stats
        # Step 2: Build module path -> file_id mapping for Rust files
        file_stmt = select(File.id, File.path)
        if worktree_id:
            file_stmt = file_stmt.where(File.worktree_id == worktree_id)
        all_files: list[tuple[int | None, str]] = list(
            session.exec(file_stmt).all()
        )
        module_to_file_id: dict[str, int] = {}
        for fid, fpath in all_files:
            if fid is None or fpath is None:
                continue
            if fpath.endswith(".rs"):
                # Convert path to Rust module path (e.g., src/lib.rs -> crate)
                module_path = _path_to_rust_module(fpath)
                if module_path:
                    module_to_file_id[module_path] = fid
        # Step 3: Create temp mapping table
        session.execute(
            text(
                "CREATE TEMP TABLE IF NOT EXISTS _rust_glob_map "
                "(importing_file_id INTEGER, source_file_id INTEGER)"
            )
        )
        session.execute(text("DELETE FROM _rust_glob_map"))
        mappings: list[dict[str, int]] = []
        for glob_imp in glob_imports:
            source_literal = glob_imp.source_literal
            if not source_literal:
                continue
            source_file_id = _find_rust_module_file(source_literal, module_to_file_id)
            if source_file_id is not None:
                mappings.append(
                    {
                        "importing_file_id": glob_imp.file_id,
                        "source_file_id": source_file_id,
                    }
                )
        if not mappings:
            session.execute(text("DROP TABLE IF EXISTS _rust_glob_map"))
            return stats
        for m in mappings:
            session.execute(
                text("INSERT INTO _rust_glob_map VALUES (:importing_file_id, :source_file_id)"),
                m,
            )
        # Step 4: Count eligible refs - public Rust symbols
        count_sql = text(f"""
            SELECT COUNT(DISTINCT rf.ref_id)
            FROM ref_facts rf
            JOIN _rust_glob_map tsm ON tsm.importing_file_id = rf.file_id
            JOIN def_facts df ON df.file_id = tsm.source_file_id
                AND df.name = rf.token_text
            WHERE rf.ref_tier = :unknown_tier
                AND rf.role = :ref_role
                {file_filter}
                {ref_unit_filter}
        """)
        result = session.execute(
            count_sql,
            {
                "unknown_tier": RefTier.UNKNOWN.value,
                "ref_role": Role.REFERENCE.value,
                **file_binds,
                **ref_unit_binds,
            },
        )
        stats.refs_matched = result.scalar_one()
        if stats.refs_matched == 0:
            session.execute(text("DROP TABLE IF EXISTS _rust_glob_map"))
            return stats
        # Step 5: Upgrade refs
        update_sql = text(f"""
            UPDATE ref_facts
            SET ref_tier = :strong_tier,
                certainty = :certain,
                target_def_uid = (
                    SELECT df.def_uid
                    FROM _rust_glob_map tsm
                    JOIN def_facts df ON df.file_id = tsm.source_file_id
                        AND df.name = ref_facts.token_text
                    WHERE tsm.importing_file_id = ref_facts.file_id
                    ORDER BY df.def_uid ASC
                    LIMIT 1
                )
            WHERE ref_id IN (
                SELECT DISTINCT rf.ref_id
                FROM ref_facts rf
                JOIN _rust_glob_map tsm ON tsm.importing_file_id = rf.file_id
                JOIN def_facts df ON df.file_id = tsm.source_file_id
                    AND df.name = rf.token_text
                WHERE rf.ref_tier = :unknown_tier
                    AND rf.role = :ref_role
                    {file_filter}
                    {ref_unit_filter}
            )
        """)
        update_result = session.execute(
            update_sql,
            {
                "strong_tier": RefTier.STRONG.value,
                "certain": Certainty.CERTAIN.value,
                "unknown_tier": RefTier.UNKNOWN.value,
                "ref_role": Role.REFERENCE.value,
                **file_binds,
                **ref_unit_binds,
            },
        )
        stats.refs_upgraded = update_result.rowcount  # type: ignore[attr-defined]
        session.execute(text("DROP TABLE IF EXISTS _rust_glob_map"))
        session.commit()
    return stats


def _path_to_rust_module(path: str) -> str | None:
    """Convert file path to Rust module path."""
    if not path.endswith(".rs"):
        return None
    # Remove .rs extension
    module = path[:-3]
    # Map lib.rs and mod.rs to parent directory, main.rs to crate
    if module.endswith("/lib") or module.endswith("/mod"):
        module = module.rsplit("/", 1)[0]
    elif module.endswith("/main"):
        return "crate"
    # Convert path separators to ::
    module = module.replace("/", "::").replace("\\", "::")
    # Handle src/ prefix
    if module.startswith("src::"):
        module = "crate::" + module[5:]
    return module


def _find_rust_module_file(
    source_literal: str,
    module_to_file_id: dict[str, int],
) -> int | None:
    """Resolve Rust use path to a file_id."""
    # Direct match
    if source_literal in module_to_file_id:
        return module_to_file_id[source_literal]
    # Try suffix matching
    for mod_path, fid in module_to_file_id.items():
        if mod_path.endswith(source_literal) or source_literal.endswith(mod_path.split("::")[-1]):
            return fid
    return None


def resolve_java_star_import_refs(
    db: Database,
    unit_id: int | None,
    file_ids: list[int] | None = None,
    worktree_id: int = 0,
) -> CrossFileResolutionStats:
    """Upgrade UNKNOWN refs using Java star-import evidence (DB-backed).

    For each file with ``import com.foo.*;``, resolves types from the
    imported package and upgrades matching UNKNOWN refs to STRONG.
    """
    stats = CrossFileResolutionStats()
    file_filter, file_binds = _build_file_filter(file_ids)
    ref_unit_filter, ref_unit_binds = _build_unit_filter(unit_id, "rf")
    def_unit_filter, def_unit_binds = _build_unit_filter(unit_id, "df")
    # Java type kinds to match
    java_type_kinds = "('class', 'interface', 'enum', 'record', 'annotation')"
    with db.session() as session:
        # Count refs that will be upgraded.
        count_sql = text(f"""
            SELECT COUNT(DISTINCT rf.ref_id)
            FROM ref_facts rf
            JOIN import_facts imf ON rf.file_id = imf.file_id
                AND imf.import_kind = 'java_import'
                AND imf.imported_name = '*'
            JOIN def_facts df ON df.name = rf.token_text
                AND df.namespace = imf.source_literal
                AND df.kind IN {java_type_kinds}
                {def_unit_filter}
            WHERE rf.ref_tier = :unknown_tier
                AND rf.role = :ref_role
                {file_filter}
                {ref_unit_filter}
        """)
        result = session.execute(
            count_sql,
            {
                "unknown_tier": RefTier.UNKNOWN.value,
                "ref_role": Role.REFERENCE.value,
                **file_binds,
                **ref_unit_binds,
                **def_unit_binds,
            },
        )
        stats.refs_matched = result.scalar_one()
        if stats.refs_matched == 0:
            return stats
        # Perform the upgrade
        update_sql = text(f"""
            UPDATE ref_facts
            SET ref_tier = :strong_tier,
                certainty = :certain,
                target_def_uid = (
                    SELECT df.def_uid
                    FROM import_facts imf
                    JOIN def_facts df ON df.name = ref_facts.token_text
                        AND df.namespace = imf.source_literal
                        AND df.kind IN {java_type_kinds}
                        {def_unit_filter}
                    WHERE imf.file_id = ref_facts.file_id
                        AND imf.import_kind = 'java_import'
                        AND imf.imported_name = '*'
                    ORDER BY df.def_uid ASC
                    LIMIT 1
                )
            WHERE ref_id IN (
                SELECT DISTINCT rf.ref_id
                FROM ref_facts rf
                JOIN import_facts imf ON rf.file_id = imf.file_id
                    AND imf.import_kind = 'java_import'
                    AND imf.imported_name = '*'
                JOIN def_facts df ON df.name = rf.token_text
                    AND df.namespace = imf.source_literal
                    AND df.kind IN {java_type_kinds}
                    {def_unit_filter}
                WHERE rf.ref_tier = :unknown_tier
                    AND rf.role = :ref_role
                    {file_filter}
                    {ref_unit_filter}
            )
        """)
        update_result = session.execute(
            update_sql,
            {
                "strong_tier": RefTier.STRONG.value,
                "certain": Certainty.CERTAIN.value,
                "unknown_tier": RefTier.UNKNOWN.value,
                "ref_role": Role.REFERENCE.value,
                **file_binds,
                **ref_unit_binds,
                **def_unit_binds,
            },
        )
        stats.refs_upgraded = update_result.rowcount  # type: ignore[attr-defined]
        session.commit()
    return stats


# ───────────────────────────────────────────────────────────────────────────
# Pass 3: Resolve ANCHORED refs via import-scoping, same-package, unique-name
# ───────────────────────────────────────────────────────────────────────────


def resolve_anchored_via_imports(
    db: Database,
    unit_id: int | None,
    file_ids: list[int] | None = None,
    worktree_id: int = 0,
) -> CrossFileResolutionStats:
    """Resolve unresolved refs by matching token to defs in imported files.

    For each unresolved ref (UNKNOWN or ANCHORED) with target_def_uid IS NULL,
    if the ref's token_text matches exactly one def in the set of files imported
    by the ref's file, resolve it.  This handles Java/Kotlin explicit imports,
    PHP use statements, and any language with resolved import paths.

    Strategy: resolve import path→file_id once into ``_imp_files``, then
    do a single multi-way join (ref → import map → def) with GROUP BY HAVING.
    """
    stats = CrossFileResolutionStats()
    file_filter, file_binds = _build_file_filter(file_ids)
    ref_unit_filter, ref_unit_binds = _build_unit_filter(unit_id, "r")
    base_binds = {
        "unknown_tier": RefTier.UNKNOWN.value,
        "anchored_tier": RefTier.ANCHORED.value,
        "ref_role": Role.REFERENCE.value,
        **file_binds,
        **ref_unit_binds,
    }

    with db.session() as session:
        # Early bail if no unresolved refs.
        unresolved = session.execute(text(f"""
            SELECT 1 FROM ref_facts r
            WHERE r.ref_tier IN (:unknown_tier, :anchored_tier)
                AND r.role = :ref_role
                AND r.target_def_uid IS NULL
                {file_filter}
                {ref_unit_filter}
            LIMIT 1
        """), base_binds).scalar()
        if not unresolved:
            session.commit()
            return stats

        # Step 1: Resolve import path → file_id once.
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _imp_files "
            "(importing_file_id INTEGER, imported_file_id INTEGER)"
        ))
        session.execute(text("DELETE FROM _imp_files"))
        session.execute(text("""
            INSERT INTO _imp_files (importing_file_id, imported_file_id)
            SELECT DISTINCT i.file_id, sf.id
            FROM import_facts i
            JOIN files sf ON sf.path = i.resolved_path
            WHERE i.resolved_path IS NOT NULL
              AND sf.worktree_id = :wt
        """), {"wt": worktree_id})
        session.execute(text(
            "CREATE INDEX IF NOT EXISTS _idx_imp_files "
            "ON _imp_files (importing_file_id)"
        ))

        # Step 2: Collect defs in distinct imported files (dedup by file).
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _file_defs "
            "(file_id INTEGER, name TEXT, def_uid TEXT)"
        ))
        session.execute(text("DELETE FROM _file_defs"))
        session.execute(text("""
            INSERT INTO _file_defs (file_id, name, def_uid)
            SELECT d.file_id, d.name, d.def_uid
            FROM def_facts d
            WHERE d.file_id IN (
                SELECT DISTINCT imported_file_id FROM _imp_files
            )
        """))
        session.execute(text(
            "CREATE INDEX IF NOT EXISTS _idx_file_defs "
            "ON _file_defs (file_id, name)"
        ))

        # Step 3: For each (importing_file, def_name), keep only unique defs.
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _import_unique_defs "
            "(importing_file_id INTEGER, def_name TEXT, def_uid TEXT)"
        ))
        session.execute(text("DELETE FROM _import_unique_defs"))
        session.execute(text("""
            INSERT INTO _import_unique_defs (importing_file_id, def_name, def_uid)
            SELECT imp.importing_file_id, fd.name, MIN(fd.def_uid)
            FROM _imp_files imp
            JOIN _file_defs fd ON fd.file_id = imp.imported_file_id
            GROUP BY imp.importing_file_id, fd.name
            HAVING MIN(fd.def_uid) = MAX(fd.def_uid)
        """))
        session.execute(text(
            "CREATE INDEX IF NOT EXISTS _idx_iud "
            "ON _import_unique_defs (importing_file_id, def_name)"
        ))

        # Step 4: Join unresolved refs against unique import defs.
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _resolve_batch "
            "(ref_id INTEGER PRIMARY KEY, target_def_uid TEXT)"
        ))
        session.execute(text("DELETE FROM _resolve_batch"))
        session.execute(text(f"""
            INSERT INTO _resolve_batch (ref_id, target_def_uid)
            SELECT r.ref_id, iud.def_uid
            FROM ref_facts r
            JOIN _import_unique_defs iud
                ON iud.importing_file_id = r.file_id
                AND iud.def_name = r.token_text
            WHERE r.ref_tier IN (:unknown_tier, :anchored_tier)
                AND r.role = :ref_role
                AND r.target_def_uid IS NULL
                {file_filter}
                {ref_unit_filter}
        """), base_binds)

        # Step 5: Bulk update.
        result = session.execute(text("""
            UPDATE ref_facts
            SET target_def_uid = (
                    SELECT rb.target_def_uid FROM _resolve_batch rb
                    WHERE rb.ref_id = ref_facts.ref_id
                ),
                ref_tier = :strong_tier,
                certainty = :uncertain
            WHERE ref_id IN (SELECT ref_id FROM _resolve_batch)
        """), {
            "strong_tier": RefTier.STRONG.value,
            "uncertain": Certainty.UNCERTAIN.value,
        })
        stats.refs_upgraded = result.rowcount  # type: ignore[attr-defined]

        session.execute(text("DROP TABLE IF EXISTS _imp_files"))
        session.execute(text("DROP TABLE IF EXISTS _file_defs"))
        session.execute(text("DROP TABLE IF EXISTS _import_unique_defs"))
        session.execute(text("DROP TABLE IF EXISTS _resolve_batch"))
        session.commit()
    return stats


def resolve_anchored_same_package(
    db: Database,
    unit_id: int | None,
    file_ids: list[int] | None = None,
    worktree_id: int = 0,
) -> CrossFileResolutionStats:
    """Resolve unresolved refs via same-directory (package) visibility.

    Handles Go (same dir = same package), Java (same dir = same package),
    Swift (same target = same module — approximated by same root dir),
    and similar languages where co-located files share visibility.

    Only resolves when exactly one def in the same directory matches.

    Strategy: materialize ``(dir, def_name, def_uid)`` (filtered to candidate
    names from unresolved refs), then join against refs via directory prefix.
    """
    stats = CrossFileResolutionStats()
    file_filter, file_binds = _build_file_filter(file_ids)
    ref_unit_filter, ref_unit_binds = _build_unit_filter(unit_id, "r")
    base_binds = {
        "unknown_tier": RefTier.UNKNOWN.value,
        "anchored_tier": RefTier.ANCHORED.value,
        "ref_role": Role.REFERENCE.value,
        "wt": worktree_id,
        **file_binds,
        **ref_unit_binds,
    }

    with db.session() as session:
        # Step 1: Materialize (dir, def_name, def_uid) filtered to names
        # that appear in unresolved refs (avoids full def_facts scan).
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _dir_defs "
            "(dir TEXT, def_name TEXT, def_uid TEXT)"
        ))
        session.execute(text("DELETE FROM _dir_defs"))
        session.execute(text(f"""
            INSERT INTO _dir_defs (dir, def_name, def_uid)
            SELECT DISTINCT
                SUBSTR(f.path, 1, LENGTH(f.path) - LENGTH(REPLACE(f.path, '/', ''))),
                d.name, d.def_uid
            FROM def_facts d
            JOIN files f ON f.id = d.file_id
            WHERE f.worktree_id = :wt
              AND d.name IN (
                SELECT DISTINCT r.token_text
                FROM ref_facts r
                WHERE r.ref_tier IN (:unknown_tier, :anchored_tier)
                    AND r.role = :ref_role
                    AND r.target_def_uid IS NULL
                    {file_filter}
                    {ref_unit_filter}
            )
        """), base_binds)
        session.execute(text(
            "CREATE INDEX IF NOT EXISTS _idx_dir_defs "
            "ON _dir_defs (dir, def_name)"
        ))

        # Step 2: Build resolution batch.
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _resolve_batch "
            "(ref_id INTEGER PRIMARY KEY, target_def_uid TEXT)"
        ))
        session.execute(text("DELETE FROM _resolve_batch"))
        session.execute(text(f"""
            INSERT INTO _resolve_batch (ref_id, target_def_uid)
            SELECT r.ref_id, MIN(dd.def_uid)
            FROM ref_facts r
            JOIN files rf ON rf.id = r.file_id
            JOIN _dir_defs dd ON dd.def_name = r.token_text
                AND dd.dir = SUBSTR(rf.path, 1, LENGTH(rf.path) - LENGTH(REPLACE(rf.path, '/', '')))
            WHERE r.ref_tier IN (:unknown_tier, :anchored_tier)
                AND r.role = :ref_role
                AND r.target_def_uid IS NULL
                {file_filter}
                {ref_unit_filter}
            GROUP BY r.ref_id
            HAVING COUNT(DISTINCT dd.def_uid) = 1
        """), base_binds)

        # Step 3: Bulk update.
        result = session.execute(text("""
            UPDATE ref_facts
            SET target_def_uid = (
                    SELECT rb.target_def_uid FROM _resolve_batch rb
                    WHERE rb.ref_id = ref_facts.ref_id
                ),
                ref_tier = :strong_tier,
                certainty = :uncertain
            WHERE ref_id IN (SELECT ref_id FROM _resolve_batch)
        """), {
            "strong_tier": RefTier.STRONG.value,
            "uncertain": Certainty.UNCERTAIN.value,
        })
        stats.refs_upgraded = result.rowcount  # type: ignore[attr-defined]

        session.execute(text("DROP TABLE IF EXISTS _dir_defs"))
        session.execute(text("DROP TABLE IF EXISTS _resolve_batch"))
        session.commit()
    return stats


def resolve_anchored_unique_name(
    db: Database,
    unit_id: int | None,
    file_ids: list[int] | None = None,
    worktree_id: int = 0,
) -> CrossFileResolutionStats:
    """Resolve unresolved refs where the token matches exactly one def in the project.

    Per SPEC §7.9 Tier 4 (Unique Name Match): if a name is globally unique
    across the project, the ref must point to that def regardless of imports.
    Confidence is UNCERTAIN since the match is positional rather than import-traced.

    Strategy: materialize the set of globally-unique def names once, then
    bulk-join against unresolved refs.
    """
    stats = CrossFileResolutionStats()
    file_filter, file_binds = _build_file_filter(file_ids)
    ref_unit_filter, ref_unit_binds = _build_unit_filter(unit_id, "r")

    with db.session() as session:
        # Step 1: Materialize globally unique names → def_uid.
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _unique_defs "
            "(name TEXT PRIMARY KEY, def_uid TEXT)"
        ))
        session.execute(text("DELETE FROM _unique_defs"))
        session.execute(text("""
            INSERT INTO _unique_defs (name, def_uid)
            SELECT d.name, MIN(d.def_uid)
            FROM def_facts d
            JOIN files f ON f.id = d.file_id
            WHERE f.worktree_id = :wt
            GROUP BY d.name
            HAVING COUNT(DISTINCT d.def_uid) = 1
        """), {"wt": worktree_id})

        # Step 2: Bulk update refs matching unique names.
        result = session.execute(text(f"""
            UPDATE ref_facts
            SET target_def_uid = (
                    SELECT ud.def_uid FROM _unique_defs ud
                    WHERE ud.name = ref_facts.token_text
                ),
                ref_tier = :strong_tier,
                certainty = :uncertain
            WHERE ref_id IN (
                SELECT r.ref_id
                FROM ref_facts r
                JOIN _unique_defs ud ON ud.name = r.token_text
                WHERE r.ref_tier IN (:unknown_tier, :anchored_tier)
                    AND r.role = :ref_role
                    AND r.target_def_uid IS NULL
                    {file_filter}
                    {ref_unit_filter}
            )
        """), {
            "unknown_tier": RefTier.UNKNOWN.value,
            "anchored_tier": RefTier.ANCHORED.value,
            "strong_tier": RefTier.STRONG.value,
            "ref_role": Role.REFERENCE.value,
            "uncertain": Certainty.UNCERTAIN.value,
            **file_binds,
            **ref_unit_binds,
        })
        stats.refs_upgraded = result.rowcount  # type: ignore[attr-defined]

        session.execute(text("DROP TABLE IF EXISTS _unique_defs"))
        session.commit()
    return stats


def resolve_import_chain(
    db: Database,
    unit_id: int | None,
    file_ids: list[int] | None = None,
    worktree_id: int = 0,
) -> CrossFileResolutionStats:
    """Resolve refs by narrowing candidates to defs reachable through import chains.

    For unresolved refs where multiple global defs exist, traces the file's
    import graph (resolved imports → their imports, 2 hops) to build a
    reachable file set, then resolves if exactly one matching def lives in
    that set.  Handles Python/JS/Java/Kotlin where import resolution is >50%.

    Strategy: resolve path→id once into ``_imp_files``, build 2-hop reachability
    via integer joins, then multi-way join refs × reachable files × defs
    (filtered to ambiguous names).
    """
    stats = CrossFileResolutionStats()
    file_filter, file_binds = _build_file_filter(file_ids)
    ref_unit_filter, ref_unit_binds = _build_unit_filter(unit_id, "r")
    base_binds = {
        "unknown_tier": RefTier.UNKNOWN.value,
        "anchored_tier": RefTier.ANCHORED.value,
        "ref_role": Role.REFERENCE.value,
        **file_binds,
        **ref_unit_binds,
    }

    with db.session() as session:
        # Step 0: Materialize ambiguous candidate names (>1 global def).
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _ambig_names "
            "(name TEXT PRIMARY KEY)"
        ))
        session.execute(text("DELETE FROM _ambig_names"))
        session.execute(text(f"""
            INSERT OR IGNORE INTO _ambig_names (name)
            SELECT DISTINCT r.token_text
            FROM ref_facts r
            WHERE r.ref_tier IN (:unknown_tier, :anchored_tier)
                AND r.role = :ref_role
                AND r.target_def_uid IS NULL
                {file_filter}
                {ref_unit_filter}
                AND r.token_text IN (
                    SELECT d.name FROM def_facts d
                    GROUP BY d.name
                    HAVING COUNT(DISTINCT d.def_uid) > 1
                )
        """), base_binds)

        count = session.execute(
            text("SELECT COUNT(*) FROM _ambig_names")
        ).scalar()
        if not count:
            session.execute(text("DROP TABLE IF EXISTS _ambig_names"))
            session.commit()
            return stats

        # Step 1: Resolve import path → file_id once.
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _imp_files "
            "(importing_file_id INTEGER, imported_file_id INTEGER)"
        ))
        session.execute(text("DELETE FROM _imp_files"))
        session.execute(text("""
            INSERT INTO _imp_files (importing_file_id, imported_file_id)
            SELECT DISTINCT i.file_id, sf.id
            FROM import_facts i
            JOIN files sf ON sf.path = i.resolved_path
            WHERE i.resolved_path IS NOT NULL
              AND sf.worktree_id = :wt
        """), {"wt": worktree_id})
        session.execute(text(
            "CREATE INDEX IF NOT EXISTS _idx_imp_files_src "
            "ON _imp_files (importing_file_id)"
        ))
        session.execute(text(
            "CREATE INDEX IF NOT EXISTS _idx_imp_files_dst "
            "ON _imp_files (imported_file_id)"
        ))

        # Step 2: Build 2-hop reachability via integer joins.
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _import_reach "
            "(source_file_id INTEGER, reachable_file_id INTEGER, "
            "UNIQUE(source_file_id, reachable_file_id))"
        ))
        session.execute(text("DELETE FROM _import_reach"))

        # Hop 1: direct.
        session.execute(text("""
            INSERT OR IGNORE INTO _import_reach (source_file_id, reachable_file_id)
            SELECT importing_file_id, imported_file_id FROM _imp_files
        """))

        # Hop 2: imports of directly imported files (integer join).
        session.execute(text("""
            INSERT OR IGNORE INTO _import_reach (source_file_id, reachable_file_id)
            SELECT DISTINCT r.source_file_id, imp2.imported_file_id
            FROM _import_reach r
            JOIN _imp_files imp2 ON imp2.importing_file_id = r.reachable_file_id
            WHERE imp2.imported_file_id != r.source_file_id
        """))

        session.execute(text(
            "CREATE INDEX IF NOT EXISTS _idx_import_reach "
            "ON _import_reach (source_file_id)"
        ))

        # Step 3: Collect defs in distinct reachable files (dedup by file).
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _reach_file_defs "
            "(file_id INTEGER, name TEXT, def_uid TEXT)"
        ))
        session.execute(text("DELETE FROM _reach_file_defs"))
        session.execute(text("""
            INSERT INTO _reach_file_defs (file_id, name, def_uid)
            SELECT d.file_id, d.name, d.def_uid
            FROM def_facts d
            JOIN _ambig_names an ON an.name = d.name
            WHERE d.file_id IN (
                SELECT DISTINCT reachable_file_id FROM _import_reach
            )
        """))
        session.execute(text(
            "CREATE INDEX IF NOT EXISTS _idx_rfd "
            "ON _reach_file_defs (file_id, name)"
        ))

        # Step 4: For each (source_file, def_name), keep only unique defs.
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _reach_unique_defs "
            "(source_file_id INTEGER, def_name TEXT, def_uid TEXT)"
        ))
        session.execute(text("DELETE FROM _reach_unique_defs"))
        session.execute(text("""
            INSERT INTO _reach_unique_defs (source_file_id, def_name, def_uid)
            SELECT ir.source_file_id, rfd.name, MIN(rfd.def_uid)
            FROM _import_reach ir
            JOIN _reach_file_defs rfd ON rfd.file_id = ir.reachable_file_id
            GROUP BY ir.source_file_id, rfd.name
            HAVING MIN(rfd.def_uid) = MAX(rfd.def_uid)
        """))
        session.execute(text(
            "CREATE INDEX IF NOT EXISTS _idx_rud "
            "ON _reach_unique_defs (source_file_id, def_name)"
        ))

        # Step 5: Join unresolved refs against unique reachable defs.
        session.execute(text(
            "CREATE TEMP TABLE IF NOT EXISTS _resolve_batch "
            "(ref_id INTEGER PRIMARY KEY, target_def_uid TEXT)"
        ))
        session.execute(text("DELETE FROM _resolve_batch"))
        session.execute(text(f"""
            INSERT INTO _resolve_batch (ref_id, target_def_uid)
            SELECT r.ref_id, rud.def_uid
            FROM ref_facts r
            JOIN _reach_unique_defs rud
                ON rud.source_file_id = r.file_id
                AND rud.def_name = r.token_text
            WHERE r.ref_tier IN (:unknown_tier, :anchored_tier)
                AND r.role = :ref_role
                AND r.target_def_uid IS NULL
                {file_filter}
                {ref_unit_filter}
        """), base_binds)

        # Step 6: Bulk update.
        result = session.execute(text("""
            UPDATE ref_facts
            SET target_def_uid = (
                    SELECT rb.target_def_uid FROM _resolve_batch rb
                    WHERE rb.ref_id = ref_facts.ref_id
                ),
                ref_tier = :strong_tier,
                certainty = :uncertain
            WHERE ref_id IN (SELECT ref_id FROM _resolve_batch)
        """), {
            "strong_tier": RefTier.STRONG.value,
            "uncertain": Certainty.UNCERTAIN.value,
        })
        stats.refs_upgraded = result.rowcount  # type: ignore[attr-defined]

        session.execute(text("DROP TABLE IF EXISTS _ambig_names"))
        session.execute(text("DROP TABLE IF EXISTS _imp_files"))
        session.execute(text("DROP TABLE IF EXISTS _import_reach"))
        session.execute(text("DROP TABLE IF EXISTS _reach_file_defs"))
        session.execute(text("DROP TABLE IF EXISTS _reach_unique_defs"))
        session.execute(text("DROP TABLE IF EXISTS _resolve_batch"))
        session.commit()
    return stats


# Resolution Registry — add new passes to _RESOLUTION_PASSES below.

_RESOLUTION_PASSES: list[ResolutionPassFn] = []


def _register_resolution_passes() -> None:
    """Populate the resolution pass registry.

    Called at module load time after all resolution functions are defined.
    """
    _RESOLUTION_PASSES.clear()
    _RESOLUTION_PASSES.extend([
        resolve_namespace_refs,  # C# namespace-using
        resolve_same_namespace_refs,  # C# same/parent namespace visibility
        resolve_star_import_refs,  # Python from X import *
        resolve_go_dot_import_refs,  # Go import . "pkg"
        resolve_rust_glob_import_refs,  # Rust use module::*
        resolve_java_star_import_refs,  # Java import pkg.*
        resolve_anchored_via_imports,  # Unique match in imported files
        resolve_import_chain,  # 2-hop import chain narrowing
        resolve_anchored_same_package,  # Unique match in same dir
        resolve_anchored_unique_name,  # Globally unique name
    ])


def run_pass_1_5(
    db: Database,
    unit_id: int | None = None,
    file_ids: list[int] | None = None,
    *,
    worktree_id: int,
) -> list[CrossFileResolutionStats]:
    """Run all registered Pass 1.5 cross-file resolution passes sequentially.

    Each language-specific pass runs with its own DB session.
    Passes are run sequentially because SQLite is single-writer —
    parallel execution only adds busy-wait contention overhead.
    """
    if not _RESOLUTION_PASSES:
        _register_resolution_passes()
    return [fn(db, unit_id, file_ids, worktree_id) for fn in _RESOLUTION_PASSES]
