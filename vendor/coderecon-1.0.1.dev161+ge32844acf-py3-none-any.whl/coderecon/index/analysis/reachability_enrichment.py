"""Pre-reachability enrichment passes — improve import_facts resolution.

These passes run before compute_reachability_full to patch gaps in
import_facts.resolved_path that the main resolver couldn't handle.
They operate directly on the SQLite database and are idempotent.

Enrichments:
  1. JS re-export graph: propagate resolved_path through barrel files
  2. Rust mod-tree: resolve 'crate::x::y' paths via mod declarations
  3. Swift Package.swift: map module imports to source directories
  4. Ruby lib-prefix: resolve 'sidekiq/x' to 'lib/sidekiq/x.rb'
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import TYPE_CHECKING

import structlog
from sqlalchemy import text as sa_text

if TYPE_CHECKING:
    from coderecon.index.db.database import Database

log = structlog.get_logger(__name__)


def _synth_uid(file_id: int, resolved_path: str, kind: str) -> str:
    """Generate a deterministic UID for synthetic import_facts."""
    raw = f"{kind}:{file_id}:{resolved_path}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def enrich_imports_for_reachability(db: Database, repo_root: Path, *, worktree_id: int) -> dict[str, int]:
    """Run all enrichment passes. Returns dict of pass_name -> rows_fixed."""
    results = {}
    results["js_reexport"] = _enrich_js_reexports(db, worktree_id=worktree_id)
    results["rust_mod_tree"] = _enrich_rust_mod_tree(db, repo_root)
    results["swift_package"] = _enrich_swift_package(db, repo_root)
    results["ruby_lib_prefix"] = _enrich_ruby_lib_prefix(db, worktree_id=worktree_id)
    total = sum(results.values())
    if total:
        log.info("reachability.enrichment.complete", results=results)
    return results


# ─── JS Re-export Graph ────────────────────────────────────────────────────


def _enrich_js_reexports(db: Database, *, worktree_id: int) -> int:
    """Propagate resolved_path through JS/TS barrel re-exports.

    When a test file imports from a barrel (index.ts), and that barrel has
    js_reexport entries pointing to actual source files, insert synthetic
    import_facts so the test file "sees" those source files.

    This is transitive: barrel A re-exports from barrel B which re-exports
    from source C → test should see C.
    """
    with db.session() as session:
        # Find all js_reexport rows with resolved targets
        reexport_rows = session.execute(sa_text("""
            SELECT i.file_id, i.resolved_path
            FROM import_facts i
            WHERE i.import_kind = 'js_reexport'
              AND i.resolved_path IS NOT NULL
              AND i.resolved_path != ''
        """)).all()

        if not reexport_rows:
            return 0

        # Build barrel file_id → set of transitively-reachable source file paths
        # First, get file_id for each barrel file
        barrel_targets: dict[int, set[str]] = {}
        for file_id, resolved_path in reexport_rows:
            barrel_targets.setdefault(file_id, set()).add(resolved_path)

        # Build transitive closure: if barrel A re-exports from barrel B,
        # and B re-exports from C, A should include C.
        # Map file paths to file_ids
        path_to_fid: dict[str, int] = {}
        rows = session.execute(
            sa_text("SELECT id, path FROM files WHERE worktree_id = :wt"),
            {"wt": worktree_id},
        ).all()
        for fid, path in rows:
            path_to_fid[path] = fid

        # Iterate until stable (handles chained barrels)
        changed = True
        iterations = 0
        max_iter = len(barrel_targets) + 1
        while changed and iterations < max_iter:
            changed = False
            iterations += 1
            for barrel_fid, targets in list(barrel_targets.items()):
                expanded: set[str] = set()
                for target_path in targets:
                    target_fid = path_to_fid.get(target_path)
                    if target_fid and target_fid in barrel_targets:
                        # This target is itself a barrel — include ITS targets
                        for transitive in barrel_targets[target_fid]:
                            if transitive not in targets:
                                expanded.add(transitive)
                if expanded:
                    barrel_targets[barrel_fid] |= expanded
                    changed = True

        # Now: for each test file that imports from a barrel file,
        # insert synthetic import_facts pointing to the barrel's transitive targets.
        test_barrel_imports = session.execute(sa_text("""
            SELECT i.file_id, i.resolved_path, i.unit_id
            FROM import_facts i
            JOIN files f ON f.id = i.file_id
            WHERE f.is_test = 1
              AND f.worktree_id = :wt
              AND i.resolved_path IS NOT NULL
              AND i.import_kind IN ('js_import', 'js_require', 'js_dynamic_import')
        """), {"wt": worktree_id}).all()

        inserted = 0
        for test_file_id, barrel_path, unit_id in test_barrel_imports:
            barrel_fid = path_to_fid.get(barrel_path)
            if barrel_fid is None or barrel_fid not in barrel_targets:
                continue
            for source_path in barrel_targets[barrel_fid]:
                # Check if this import already exists
                exists = session.execute(sa_text("""
                    SELECT 1 FROM import_facts
                    WHERE file_id = :fid AND resolved_path = :rp
                    LIMIT 1
                """), {"fid": test_file_id, "rp": source_path}).first()
                if exists:
                    continue
                # Insert synthetic import pointing to the transitive source
                uid = _synth_uid(test_file_id, source_path, "js_reexport")
                session.execute(sa_text("""
                    INSERT INTO import_facts
                        (import_uid, file_id, unit_id, imported_name, source_literal,
                         resolved_path, import_kind, certainty,
                         start_line, start_col, end_line, end_col)
                    VALUES (:uid, :fid, :uid2, '*', :src, :rp,
                            'js_reexport_synthetic', 'LOW', 0, 0, 0, 0)
                """), {"uid": uid, "fid": test_file_id, "uid2": unit_id,
                       "src": barrel_path, "rp": source_path})
                inserted += 1

        if inserted:
            session.commit()
        return inserted


# ─── Rust Mod-Tree Walker ──────────────────────────────────────────────────


def _enrich_rust_mod_tree(db: Database, repo_root: Path) -> int:
    """Resolve Rust 'use crate::x::y' imports via mod declarations.

    NOTE: Disabled. Resolving to module-level files (mod.rs) without
    knowing which specific file defines the target type/function causes
    the CTE's scoping to become MORE restrictive (adds wrong files to scope
    while the fallback clause stops firing). This actually DECREASES
    reachability because:
    1. 'clap::Parser' → src/lib.rs (Parser is re-exported, not defined there)
    2. 'clap::error::ErrorKind' → error/mod.rs (ErrorKind is in a child file)

    Proper resolution requires type-aware indexing (SCIP) to resolve through
    re-exports and find the actual defining file.

    Returns 0 (no-op).
    """
    return 0
    with db.session() as session:
        # Find unresolved rust_use imports IN TEST FILES ONLY
        # Resolving source-file imports would restrict the recursive CTE's
        # fallback scoping, potentially reducing reachability.
        unresolved = session.execute(sa_text("""
            SELECT i.rowid, i.source_literal, i.file_id
            FROM import_facts i
            JOIN files f ON f.id = i.file_id
            WHERE i.import_kind = 'rust_use'
              AND (i.resolved_path IS NULL OR i.resolved_path = '')
              AND i.source_literal LIKE '%::%'
              AND f.is_test = 1
        """)).all()

        if not unresolved:
            return 0

        # Build the module tree from existing declared_modules
        # declared_module for Rust files = crate_name::module::path (or just crate_name for roots)
        mod_map: dict[str, str] = {}  # module_path → file_path
        rows = session.execute(sa_text("""
            SELECT f.path, f.declared_module
            FROM files f
            WHERE f.declared_module IS NOT NULL
              AND f.declared_module != ''
        """)).all()
        for file_path, declared_module in rows:
            mod_map[declared_module] = file_path

        # Also map crate_name → lib.rs/main.rs
        crate_roots: dict[str, str] = {}
        for mod_path, file_path in mod_map.items():
            parts = mod_path.split("::")
            if len(parts) == 1:
                crate_roots[parts[0]] = file_path

        # Build file_id → declared_module mapping (for crate:: resolution)
        fid_to_module: dict[int, str] = {}
        fid_rows = session.execute(sa_text("""
            SELECT id, declared_module FROM files
            WHERE declared_module IS NOT NULL AND declared_module != ''
        """)).all()
        for fid, dm in fid_rows:
            fid_to_module[fid] = dm

        # Walk mod declarations in source files to find re-exports (pub use)
        # Build a pub_use map: module_path::symbol → actual_file
        all_files = session.execute(sa_text(
            "SELECT path FROM files WHERE path LIKE '%.rs'"
        )).all()
        all_file_set = {r[0] for r in all_files}

        # For each module in the tree, check if the source file
        # contains mod declarations that point to subdirectories
        _expand_mod_tree(mod_map, all_file_set, repo_root)

        # Now resolve unresolved imports
        fixed = 0
        for rowid, source_literal, file_id in unresolved:
            # Handle crate:: prefix by substituting with file's crate root
            effective_literal = source_literal
            if source_literal.startswith("crate::"):
                # Find this file's crate root from its declared_module
                file_mod = fid_to_module.get(file_id, "")
                if file_mod:
                    # Crate root is the first segment of declared_module
                    crate_name = file_mod.split("::")[0]
                    # For integration tests: crate:: refers to the test binary's root
                    # e.g., file=clap::tests::derive::app_name, crate::utils → clap::tests::derive::utils
                    # Find the longest prefix in mod_map that contains a lib.rs/main.rs
                    # Actually simpler: walk UP the file's module path to find a lib/main
                    crate_prefix = _find_crate_root_prefix(file_mod, mod_map)
                    if crate_prefix:
                        effective_literal = source_literal.replace(
                            "crate::", f"{crate_prefix}::", 1
                        )

            resolved = _resolve_rust_use(effective_literal, mod_map, crate_roots)
            if resolved and resolved in all_file_set:
                session.execute(sa_text("""
                    UPDATE import_facts SET resolved_path = :rp
                    WHERE rowid = :rowid
                """), {"rp": resolved, "rowid": rowid})
                fixed += 1

        if fixed:
            session.commit()
        return fixed


def _expand_mod_tree(
    mod_map: dict[str, str],
    all_files: set[str],
    repo_root: Path,
) -> None:
    """Expand the Rust module tree by scanning for mod declarations.

    For each known module file, look for `mod foo;` declarations and
    map those to the expected file paths (foo.rs or foo/mod.rs).
    """
    import re
    mod_decl_re = re.compile(r"^\s*(?:pub\s+)?mod\s+(\w+)\s*;", re.MULTILINE)

    to_scan = list(mod_map.items())
    visited: set[str] = set()

    while to_scan:
        mod_path, file_path = to_scan.pop()
        if file_path in visited:
            continue
        visited.add(file_path)

        full_path = repo_root / file_path
        try:
            content = full_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        file_dir = str(Path(file_path).parent)
        file_stem = Path(file_path).stem

        for m in mod_decl_re.finditer(content):
            child_name = m.group(1)
            child_mod = f"{mod_path}::{child_name}"

            if child_mod in mod_map:
                continue

            # Convention: mod foo; → dir/foo.rs or dir/foo/mod.rs
            # If current file is mod.rs or lib.rs/main.rs, children are siblings
            if file_stem in ("mod", "lib", "main"):
                child_file = f"{file_dir}/{child_name}.rs"
                child_dir_mod = f"{file_dir}/{child_name}/mod.rs"
            else:
                # File-based module: foo.rs → children in foo/child.rs
                parent_dir = f"{file_dir}/{file_stem}"
                child_file = f"{parent_dir}/{child_name}.rs"
                child_dir_mod = f"{parent_dir}/{child_name}/mod.rs"

            if child_file in all_files:
                mod_map[child_mod] = child_file
                to_scan.append((child_mod, child_file))
            elif child_dir_mod in all_files:
                mod_map[child_mod] = child_dir_mod
                to_scan.append((child_mod, child_dir_mod))


def _find_crate_root_prefix(file_mod: str, mod_map: dict[str, str]) -> str | None:
    """Find the crate root module prefix for a file.

    For `clap::tests::derive::app_name`, the crate root is the longest
    prefix whose file is a lib.rs or main.rs (or has no :: = is a crate root).

    Returns the prefix string, e.g. 'clap::tests::derive'.
    """
    parts = file_mod.split("::")
    # Walk from longest to shortest prefix
    for i in range(len(parts), 0, -1):
        prefix = "::".join(parts[:i])
        if prefix in mod_map:
            path = mod_map[prefix]
            stem = Path(path).stem
            if stem in ("lib", "main", "mod"):
                return prefix
    # Fallback: just the crate name (first segment)
    if parts[0] in mod_map:
        return parts[0]
    return None


def _resolve_rust_use(
    source_literal: str,
    mod_map: dict[str, str],
    crate_roots: dict[str, str],
) -> str | None:
    """Resolve a Rust use path to a file path.

    Tries progressively shorter prefixes:
    'clap::Parser' → try 'clap::Parser', then 'clap' (→ lib.rs)
    'crate::utils::get_help' → try full path, then 'crate::utils'
    """
    # Exact match
    if source_literal in mod_map:
        return mod_map[source_literal]

    # Try progressively shorter prefixes
    parts = source_literal.split("::")
    for i in range(len(parts) - 1, 0, -1):
        prefix = "::".join(parts[:i])
        if prefix in mod_map:
            return mod_map[prefix]

    # Try crate root
    if parts[0] in crate_roots:
        return crate_roots[parts[0]]

    return None


# ─── Swift Package.swift Mapping ───────────────────────────────────────────


def _enrich_swift_package(db: Database, repo_root: Path) -> int:
    """Map Swift module imports to source directories via Package.swift.

    NOTE: Swift module-level imports (e.g., `import Alamofire`) cannot be
    usefully enriched with synthetic import_facts because:
    1. The CTE's Base Case C pulls ALL defs from imported files, causing
       combinatorial explosion when pointing to dozens of source files.
    2. When no resolved imports exist, the CTE fallback already name-matches
       against ALL source defs — so adding resolved imports doesn't help.

    The real gap for Swift is def_uid resolution (matching ref token_text
    to qualified def lexical_paths), which requires type-aware indexing (SCIP).

    Returns 0 (no-op).
    """
    return 0


# ─── Ruby Lib-Prefix Resolution ───────────────────────────────────────────


def _enrich_ruby_lib_prefix(db: Database, *, worktree_id: int) -> int:
    """Resolve Ruby require paths by probing under lib/ prefix.

    Ruby's `require 'sidekiq/job_retry'` expects the file at
    `lib/sidekiq/job_retry.rb` (relative to the gem's load path,
    which is typically `lib/`).

    This pass finds unresolved ruby_require imports and probes:
    1. lib/<source_literal>.rb
    2. lib/<source_literal>/init.rb (rare but exists)
    """
    with db.session() as session:
        # Get all file paths for existence checking
        all_files = session.execute(
            sa_text("SELECT path FROM files WHERE worktree_id = :wt"),
            {"wt": worktree_id},
        ).all()
        all_file_set = {r[0] for r in all_files}

        # Find unresolved ruby_require imports
        unresolved = session.execute(sa_text("""
            SELECT i.rowid, i.source_literal
            FROM import_facts i
            WHERE i.import_kind = 'ruby_require'
              AND (i.resolved_path IS NULL OR i.resolved_path = '')
              AND i.source_literal IS NOT NULL
        """)).all()

        if not unresolved:
            return 0

        fixed = 0
        for rowid, source_literal in unresolved:
            resolved = None
            # Probe lib/<path>.rb
            candidate = f"lib/{source_literal}.rb"
            if candidate in all_file_set:
                resolved = candidate
            else:
                # Try without .rb extension assumption
                candidate = f"lib/{source_literal}"
                if candidate in all_file_set:
                    resolved = candidate

            if resolved:
                session.execute(sa_text("""
                    UPDATE import_facts SET resolved_path = :rp
                    WHERE rowid = :rowid
                """), {"rp": resolved, "rowid": rowid})
                fixed += 1

        if fixed:
            session.commit()
        return fixed
