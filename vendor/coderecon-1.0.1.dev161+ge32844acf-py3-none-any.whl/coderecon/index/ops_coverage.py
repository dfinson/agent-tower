"""Post-reindex coverage collection — inherent to every index/reindex operation.

Runs tests with coverage after each reindex and ingests results into
TestCoverageFact rows. Best-effort: never raises, logs on failure.

Two modes:
  - Incremental: uses import graph to discover affected tests for changed files.
  - Full: runs the entire test suite with coverage.

IMPORTANT: This runs while still inside the reindex operation, BEFORE the
freshness gate is released. We must bypass wait_for_freshness() in all paths
to avoid a 30s timeout deadlock in the daemon thread-pool path.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from coderecon.index.ops import IndexCoordinatorEngine

log = structlog.get_logger(__name__)


async def run_coverage_for_changed_files(
    engine: IndexCoordinatorEngine,
    changed_files: list[str],
    *,
    worktree: str = "main",
    timeout_sec: int = 60,
) -> int:
    """Run affected tests with coverage for a set of changed files.

    Returns the number of TestCoverageFact rows written, or 0 on failure/skip.
    Never raises.
    """
    if not changed_files:
        return 0

    try:
        # Query import graph directly — we're inside the reindex operation
        # so the freshness gate hasn't been released yet. Calling the public
        # get_affected_test_targets() would deadlock on wait_for_freshness().
        from coderecon.index.graph.import_graph import ImportGraph

        with engine.db.session() as session:
            graph = ImportGraph(session, worktree_id=engine.get_worktree_id(worktree))
            graph_result = graph.affected_tests(changed_files)

        if not graph_result.test_files:
            log.debug("post_reindex_coverage.no_affected_tests", changed=len(changed_files))
            return 0

        return await _run_and_ingest(
            engine,
            targets=[f"test:{f}" for f in graph_result.test_files],
            timeout_sec=timeout_sec,
        )
    except Exception:
        log.debug("post_reindex_coverage.failed", exc_info=True)
        return 0


async def run_coverage_full(
    engine: IndexCoordinatorEngine,
    *,
    timeout_sec: int = 600,
) -> int:
    """Run the full test suite with coverage.

    Returns the number of TestCoverageFact rows written, or 0 on failure/skip.
    Never raises.
    """
    try:
        return await _run_and_ingest(engine, targets=None, timeout_sec=timeout_sec)
    except Exception:
        log.debug("post_reindex_coverage.full_failed", exc_info=True)
        return 0


async def _run_and_ingest(
    engine: IndexCoordinatorEngine,
    targets: list[str] | None,
    *,
    timeout_sec: int = 60,
) -> int:
    """Run tests with coverage and ingest artifacts. Never raises."""
    from coderecon.testing.ops import TestOps

    # Resolve the effective repo root for this engine (supports worktrees)
    repo_root = engine.repo_root
    test_ops = TestOps(repo_root, engine)

    # Temporarily disable the freshness gate so that TestOps internal calls
    # to get_test_targets() / wait_for_freshness() don't block. We're inside
    # the reindex operation — the data IS fresh, but the gate hasn't been
    # released yet (mark_fresh happens after _index_sync returns).
    saved_gate = engine._freshness_gate
    engine._freshness_gate = None
    try:
        result = await test_ops.run(
            targets=targets,
            coverage=True,
            fail_fast=True,
            timeout_sec=timeout_sec,
        )
    finally:
        engine._freshness_gate = saved_gate

    if not result.run_status or not result.run_status.coverage:
        log.debug("post_reindex_coverage.no_artifacts", targets=targets)
        return 0

    from coderecon.testing.coverage import (
        merge,
        parse_artifact,
    )
    from coderecon.testing.coverage.models import CoverageParseError

    reports = []
    for cov in result.run_status.coverage:
        cov_path = cov.get("path", "")
        if not cov_path:
            continue
        try:
            fmt = cov.get("format")
            report = parse_artifact(
                Path(cov_path),
                format_id=fmt if fmt and fmt != "unknown" else None,
                base_path=repo_root,
            )
            reports.append(report)
        except (CoverageParseError, ValueError, KeyError, OSError):
            log.debug("post_reindex_coverage.parse_failed", path=cov_path, exc_info=True)

    if not reports:
        log.debug("post_reindex_coverage.no_reports")
        return 0

    from coderecon.index.analysis.coverage_ingestion import (
        ingest_coverage,
        ingest_coverage_per_test,
    )

    merged = merge(*reports) if len(reports) > 1 else reports[0]
    epoch = engine.current_epoch

    failed_ids: set[str] | None = None
    if result.run_status and result.run_status.failures:
        failed_ids = {
            f"{f.path}::{f.name}"
            for f in result.run_status.failures
        }

    written = 0

    # Attempt per-test ingestion for NATIVE_BATCH packs
    per_test_written = _try_per_test_ingestion(
        result.run_status.coverage,
        repo_root=repo_root,
        engine_db=engine.db.engine,
        epoch=epoch,
        worktree_id=engine.active_worktree_id,
        failed_ids=failed_ids,
    )
    written += per_test_written

    # For PER_FILE_BATCH: each artifact came from a specific target.
    # Attribute the aggregate report to that target's ID.
    if per_test_written == 0:
        # Fall back to per-target attribution if we have target info
        target_selectors = result.run_status.target_selectors or []
        if len(target_selectors) == 1 and len(reports) == 1:
            # Single target run — attribute to that target
            test_id_override = target_selectors[0]
            written += ingest_coverage(
                engine.db.engine, merged, epoch,
                worktree_id=engine.active_worktree_id,
                test_id_override=test_id_override,
                failed_test_ids=failed_ids,
            )
        elif len(target_selectors) == len(result.run_status.coverage):
            # One artifact per target — attribute each individually
            for i, cov in enumerate(result.run_status.coverage):
                cov_path = cov.get("path", "")
                if not cov_path or i >= len(target_selectors):
                    continue
                try:
                    fmt = cov.get("format")
                    report = parse_artifact(
                        Path(cov_path),
                        format_id=fmt if fmt and fmt != "unknown" else None,
                        base_path=repo_root,
                    )
                    written += ingest_coverage(
                        engine.db.engine, report, epoch,
                        worktree_id=engine.active_worktree_id,
                        test_id_override=target_selectors[i],
                        failed_test_ids=failed_ids,
                    )
                except (CoverageParseError, ValueError, KeyError, OSError):
                    log.debug(
                        "post_reindex_coverage.per_target_parse_failed",
                        path=cov_path, exc_info=True,
                    )
        else:
            # Multiple targets, single merged report — use suite-level ID
            written += ingest_coverage(
                engine.db.engine, merged, epoch,
                worktree_id=engine.active_worktree_id,
                failed_test_ids=failed_ids,
            )

    log.info("post_reindex_coverage.ingested", facts=written, targets=targets)

    # Calibrate static reachability edges with the new coverage data
    if written > 0:
        try:
            from coderecon.index.analysis.reachability import calibrate_with_coverage
            calibrated = calibrate_with_coverage(engine.db, epoch, worktree_id=engine.active_worktree_id)
            log.debug("post_reindex_coverage.calibrated", edges=calibrated)
        except Exception:
            log.debug("post_reindex_coverage.calibrate_failed", exc_info=True)

    return written


def _try_per_test_ingestion(
    coverage_dicts: list[dict],
    *,
    repo_root: Path,
    engine_db: object,
    epoch: int,
    worktree_id: int,
    failed_ids: set[str] | None,
) -> int:
    """Attempt to parse and ingest per-test coverage from NATIVE_BATCH artifacts.

    Returns number of facts written (0 if no per-test data available).
    """
    from coderecon.index.analysis.coverage_ingestion import ingest_coverage_per_test
    from coderecon.testing.coverage.parsers.coveragepy_context import (
        parse_coveragepy_context,
    )
    from coderecon.testing.coverage.parsers.jacoco_per_test import parse_jacoco_per_test
    from coderecon.testing.coverage.parsers.phpunit_per_test import parse_phpunit_per_test
    from coderecon.testing.coverage.parsers.simplecov_per_test import (
        parse_simplecov_per_test,
    )
    from coderecon.testing.emitters import PerTestStrategy, get_emitter

    total = 0

    for cov in coverage_dicts:
        pack_id = cov.get("pack_id", "")
        emitter = get_emitter(pack_id)
        if not emitter or emitter.per_test_strategy != PerTestStrategy.NATIVE_BATCH:
            continue

        cov_path = Path(cov.get("path", ""))
        if not cov_path.exists():
            continue

        per_test_reports: dict[str, object] = {}

        if pack_id == "python.pytest":
            # Look for .coverage DB alongside the lcov output
            coverage_db = cov_path.parent / ".coverage"
            if not coverage_db.exists():
                # Also check in parent's parent (coverage_dir/coverage/.coverage)
                coverage_db = cov_path.parent / ".coverage"
            per_test_reports = parse_coveragepy_context(coverage_db, base_path=repo_root)

        elif pack_id in ("java.maven", "java.gradle"):
            per_test_dir = cov_path / "per-test" if cov_path.is_dir() else cov_path.parent / "per-test"
            if per_test_dir.is_dir():
                per_test_reports = parse_jacoco_per_test(per_test_dir, base_path=repo_root)

        elif pack_id in ("ruby.rspec", "ruby.minitest"):
            resultset = cov_path / ".resultset.json" if cov_path.is_dir() else cov_path
            if resultset.exists():
                per_test_reports = parse_simplecov_per_test(resultset, base_path=repo_root)

        elif pack_id == "php.phpunit":
            per_test_dir = cov_path.parent / "per-test" if cov_path.is_file() else cov_path / "per-test"
            if per_test_dir.is_dir():
                per_test_reports = parse_phpunit_per_test(per_test_dir, base_path=repo_root)

        if per_test_reports:
            total += ingest_coverage_per_test(
                engine_db,  # type: ignore[arg-type]
                per_test_reports,  # type: ignore[arg-type]
                epoch,
                worktree_id=worktree_id,
                failed_test_ids=failed_ids,
            )

    return total
