"""Static test reachability — walk call graph from test defs to source defs.

Two-phase architecture:
  1. ``materialize_call_edges``: Scan ref_facts to build a flat caller→callee
     edge table (call_edges).  O(defs × avg_refs_per_def).
  2. ``compute_reachability_full``: Single batch recursive CTE over call_edges
     seeded from ALL test defs simultaneously.  O(graph_size × depth).

Incremental:
  - ``rematerialize_call_edges_for_files``: Update edges for changed files.
  - ``compute_reachability_incremental``: Batch CTE for affected test defs only.

Staleness:
  - ``mark_reachability_stale``: marks edges TO defs in changed files as stale.

Calibration:
  - ``calibrate_with_coverage``: intersect static edges with TestCoverageFact.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

import structlog
from sqlalchemy import text as sa_text

if TYPE_CHECKING:
    from coderecon.index.db.database import Database

log = structlog.get_logger(__name__)

# Maximum transitive depth for the iterative BFS walk.
# Depth 5 is the sweet spot: captures 90%+ of reachable nodes while keeping
# BFS fast even on dense graphs (e.g. okhttp: 36s at depth 5 vs 143s at 10).
_MAX_DEPTH = 5


# ═══════════════════════════════════════════════════════════════════════════
# Phase 1: Materialize call_edges
# ═══════════════════════════════════════════════════════════════════════════


def _backfill_file_scope_defs(session, *, worktree_id: int) -> int:
    """Create synthetic 'module' def_facts for test files with no defs.

    Many test files (TS describe/it, C++ TEST macros, Ruby DSL blocks)
    contain only anonymous callbacks or macro invocations — the tree-sitter
    extractor doesn't emit named defs for these.  Without at least one def,
    the file can't participate in call_edges or test_reachability_facts.

    Inserts a file-spanning 'module' def using a deterministic UID derived
    from the file path.  These are idempotent (INSERT OR IGNORE).

    Returns number of synthetic defs created.
    """
    import hashlib

    # Find test files with resolved refs but zero defs
    rows = session.execute(sa_text("""\
        SELECT DISTINCT f.id, f.path, r.unit_id
        FROM files f
        JOIN ref_facts r ON r.file_id = f.id
        WHERE f.is_test = 1
          AND f.worktree_id = :wt
          AND r.target_def_uid IS NOT NULL
          AND f.id NOT IN (SELECT DISTINCT file_id FROM def_facts)
        GROUP BY f.id
    """), {"wt": worktree_id}).fetchall()

    if not rows:
        return 0

    # Bulk insert synthetic module defs
    inserts = []
    for file_id, path, unit_id in rows:
        uid = hashlib.blake2b(
            f"__file_scope__:{path}".encode(), digest_size=8
        ).hexdigest()
        name = path.rsplit("/", 1)[-1] if "/" in path else path
        inserts.append({
            "def_uid": uid,
            "file_id": file_id,
            "unit_id": unit_id or 1,
            "kind": "module",
            "name": name,
            "qualified_name": path,
            "lexical_path": name,
            "start_line": 1,
            "start_col": 0,
            "end_line": 999999,
            "end_col": 0,
        })

    session.execute(
        sa_text("""\
            INSERT OR IGNORE INTO def_facts
                (def_uid, file_id, unit_id, kind, name, qualified_name,
                 lexical_path, start_line, start_col, end_line, end_col,
                 is_external)
            VALUES
                (:def_uid, :file_id, :unit_id, :kind, :name, :qualified_name,
                 :lexical_path, :start_line, :start_col, :end_line, :end_col,
                 0)
        """),
        inserts,
    )
    return len(inserts)


def materialize_call_edges(db: Database, *, worktree_id: int) -> int:
    """Populate call_edges table from resolved ref_facts for a worktree.

    Scans every def in the worktree and materializes resolved refs (target_def_uid set)
    within the def's line range as caller→callee edges.

    Only resolved refs are used — no fuzzy name matching. Resolution quality
    directly determines reachability quality.

    Returns number of edges inserted.
    """
    t0 = time.time()
    with db.session() as session:
        # Ensure every test file with refs has at least one def anchor
        backfilled = _backfill_file_scope_defs(session, worktree_id=worktree_id)
        if backfilled:
            log.info(
                "reachability.backfill_file_defs",
                extra={"synthetic_defs": backfilled},
            )

        # Delete call_edges only for defs in this worktree's files
        session.execute(
            sa_text(
                "DELETE FROM call_edges WHERE caller_def_uid IN ("
                "  SELECT d.def_uid FROM def_facts d"
                "  JOIN files f ON f.id = d.file_id"
                "  WHERE f.worktree_id = :wt"
                ") OR callee_def_uid IN ("
                "  SELECT d.def_uid FROM def_facts d"
                "  JOIN files f ON f.id = d.file_id"
                "  WHERE f.worktree_id = :wt"
                ")"
            ),
            {"wt": worktree_id},
        )

        # Resolved refs within def bodies → call edges (scoped to worktree)
        session.execute(sa_text("""\
            INSERT OR IGNORE INTO call_edges (caller_def_uid, callee_def_uid, edge_kind)
            SELECT DISTINCT d.def_uid, r.target_def_uid, 'resolved'
            FROM def_facts d
            JOIN files f ON f.id = d.file_id
            JOIN ref_facts r
              ON r.file_id = d.file_id
              AND r.start_line >= d.start_line
              AND r.start_line <= d.end_line
              AND r.target_def_uid IS NOT NULL
              AND r.role != 'DEFINITION'
              AND r.target_def_uid != d.def_uid
            WHERE f.worktree_id = :wt
              AND EXISTS (SELECT 1 FROM def_facts df2 WHERE df2.def_uid = r.target_def_uid)
        """), {"wt": worktree_id})

        # Top-level refs in test files — refs not inside any def body.
        session.execute(sa_text("""\
            INSERT OR IGNORE INTO call_edges (caller_def_uid, callee_def_uid, edge_kind)
            SELECT DISTINCT proxy.def_uid, r.target_def_uid, 'resolved'
            FROM ref_facts r
            JOIN files f ON f.id = r.file_id
            JOIN (
                SELECT df.file_id, MIN(df.def_uid) as def_uid
                FROM def_facts df
                JOIN files ff ON ff.id = df.file_id
                WHERE ff.worktree_id = :wt
                GROUP BY df.file_id
            ) proxy ON proxy.file_id = r.file_id
            WHERE f.is_test = 1
              AND f.worktree_id = :wt
              AND r.target_def_uid IS NOT NULL
              AND r.role != 'DEFINITION'
              AND r.target_def_uid != proxy.def_uid
              AND NOT EXISTS (
                SELECT 1 FROM def_facts d
                WHERE d.file_id = r.file_id
                  AND r.start_line >= d.start_line
                  AND r.start_line <= d.end_line
                  AND d.kind IN ('function', 'method')
              )
              AND EXISTS (
                SELECT 1 FROM def_facts df2
                WHERE df2.def_uid = r.target_def_uid
              )
        """), {"wt": worktree_id})

        # Prune edges from/to structurally-minified files
        pruned = _prune_minified_file_edges(session, worktree_id=worktree_id)

        count = session.execute(
            sa_text("SELECT COUNT(*) FROM call_edges")
        ).scalar() or 0
        session.commit()

    elapsed = time.time() - t0
    log.info(
        "reachability.materialize_edges.complete",
        extra={"edges": count, "pruned_minified": pruned, "elapsed_sec": round(elapsed, 1)},
    )
    return count


def _prune_minified_file_edges(session, *, worktree_id: int) -> int:
    """Detect files with minified-code signatures and delete their call edges.

    Human-written code requires at least one line per definition (the
    signature).  A file with >=100 defs averaging >=2 defs/line is
    structurally machine-generated (minified, bundled, or concatenated) —
    this is a physical constraint of code layout, not a tuning parameter.

    Returns number of edges pruned.
    """
    minified = session.execute(sa_text("""\
        SELECT d.file_id, f.path,
               COUNT(*) as def_count,
               MAX(d.end_line) as max_line,
               CAST(COUNT(*) AS REAL) / MAX(MAX(d.end_line), 1) as defs_per_line
        FROM def_facts d
        JOIN files f ON f.id = d.file_id
        WHERE f.worktree_id = :wt
        GROUP BY d.file_id
        HAVING def_count >= 100 AND defs_per_line >= 2
    """), {"wt": worktree_id}).fetchall()

    if not minified:
        return 0

    file_ids = [row[0] for row in minified]
    ph = ",".join(f":fid{i}" for i in range(len(file_ids)))
    params = {f"fid{i}": fid for i, fid in enumerate(file_ids)}

    pruned = session.execute(
        sa_text(
            f"DELETE FROM call_edges WHERE caller_def_uid IN ("
            f"  SELECT def_uid FROM def_facts WHERE file_id IN ({ph})"
            f") OR callee_def_uid IN ("
            f"  SELECT def_uid FROM def_facts WHERE file_id IN ({ph})"
            f")"
        ),
        params,
    ).rowcount

    if pruned > 0:
        for _fid, path, def_count, max_line, defs_per_line in minified:
            log.warning(
                "reachability.prune_minified_file",
                extra={
                    "path": path,
                    "defs": def_count,
                    "lines": max_line,
                    "defs_per_line": round(defs_per_line, 1),
                },
            )

    return pruned


def rematerialize_call_edges_for_files(db: Database, file_ids: list[int], *, worktree_id: int) -> int:
    """Re-materialize call_edges for defs in the given files.

    Used during incremental reindex: delete old edges where caller or callee
    is in changed files, then re-insert from current ref_facts.
    """
    if not file_ids:
        return 0

    with db.session() as session:
        ph = ",".join(f":f{i}" for i in range(len(file_ids)))
        params: dict = {f"f{i}": fid for i, fid in enumerate(file_ids)}

        # Delete edges where caller is in changed files
        session.execute(
            sa_text(
                f"DELETE FROM call_edges WHERE caller_def_uid IN ("
                f"  SELECT def_uid FROM def_facts WHERE file_id IN ({ph})"
                f")"
            ),
            params,
        )

        # Also delete edges TO defs in changed files (they may have moved/gone)
        session.execute(
            sa_text(
                f"DELETE FROM call_edges WHERE callee_def_uid IN ("
                f"  SELECT def_uid FROM def_facts WHERE file_id IN ({ph})"
                f")"
            ),
            params,
        )

        # Re-insert resolved edges for defs in changed files
        session.execute(
            sa_text(f"""\
                INSERT OR IGNORE INTO call_edges (caller_def_uid, callee_def_uid, edge_kind)
                SELECT DISTINCT d.def_uid, r.target_def_uid, 'resolved'
                FROM def_facts d
                JOIN ref_facts r
                  ON r.file_id = d.file_id
                  AND r.start_line >= d.start_line
                  AND r.start_line <= d.end_line
                  AND r.target_def_uid IS NOT NULL
                  AND r.role != 'DEFINITION'
                  AND r.target_def_uid != d.def_uid
                WHERE d.file_id IN ({ph})
                  AND EXISTS (SELECT 1 FROM def_facts df2 WHERE df2.def_uid = r.target_def_uid)
            """),
            params,
        )

        # Re-insert top-level ref edges for test files in changed set
        session.execute(
            sa_text(f"""\
                INSERT OR IGNORE INTO call_edges (caller_def_uid, callee_def_uid, edge_kind)
                SELECT DISTINCT proxy.def_uid, r.target_def_uid, 'resolved'
                FROM ref_facts r
                JOIN files f ON f.id = r.file_id
                JOIN (
                    SELECT file_id, MIN(def_uid) as def_uid
                    FROM def_facts
                    GROUP BY file_id
                ) proxy ON proxy.file_id = r.file_id
                WHERE f.is_test = 1
                  AND r.file_id IN ({ph})
                  AND r.target_def_uid IS NOT NULL
                  AND r.role != 'DEFINITION'
                  AND r.target_def_uid != proxy.def_uid
                  AND NOT EXISTS (
                    SELECT 1 FROM def_facts d
                    WHERE d.file_id = r.file_id
                      AND r.start_line >= d.start_line
                      AND r.start_line <= d.end_line
                      AND d.kind IN ('function', 'method')
                  )
                  AND EXISTS (
                    SELECT 1 FROM def_facts df2
                    WHERE df2.def_uid = r.target_def_uid
                  )
            """),
            params,
        )

        _prune_minified_file_edges(session, worktree_id=worktree_id)

        count = session.execute(
            sa_text("SELECT COUNT(*) FROM call_edges")
        ).scalar() or 0
        session.commit()

    return count


# ═══════════════════════════════════════════════════════════════════════════
# Phase 2: Iterative BFS reachability via call_edges
# ═══════════════════════════════════════════════════════════════════════════


def compute_reachability_full(db: Database, epoch: int, *, worktree_id: int) -> int:
    """Compute static reachability for ALL test defs in a worktree via iterative BFS.

    Uses layer-by-layer expansion with a visited set (temp table) to avoid
    the exponential re-expansion problem of SQLite recursive CTEs where the
    same (test, target) pair at different depths generates duplicate work.

    Requires call_edges to be populated (call materialize_call_edges first).
    Returns the number of TestReachabilityFact rows inserted.
    """
    t0 = time.time()
    with db.session() as session:
        edge_count = session.execute(
            sa_text(
                "SELECT COUNT(*) FROM call_edges WHERE caller_def_uid IN ("
                "  SELECT d.def_uid FROM def_facts d"
                "  JOIN files f ON f.id = d.file_id"
                "  WHERE f.worktree_id = :wt"
                ")"
            ),
            {"wt": worktree_id},
        ).scalar() or 0
        if edge_count == 0:
            log.info("reachability.full.no_call_edges")
            return 0

        test_count = session.execute(
            sa_text(
                "SELECT COUNT(*) FROM def_facts d "
                "JOIN files f ON f.id = d.file_id "
                "WHERE f.is_test = 1 AND f.worktree_id = :wt"
            ),
            {"wt": worktree_id},
        ).scalar() or 0
        if test_count == 0:
            log.info("reachability.full.no_test_defs")
            return 0

        # Wipe old static edges for this worktree's test defs
        session.execute(
            sa_text(
                "DELETE FROM test_reachability_facts WHERE source = 'static'"
                " AND test_def_uid IN ("
                "  SELECT d.def_uid FROM def_facts d"
                "  JOIN files f ON f.id = d.file_id"
                "  WHERE f.worktree_id = :wt"
                ")"
            ),
            {"wt": worktree_id},
        )

        # Create temp tables for BFS
        session.execute(sa_text(
            "CREATE TEMP TABLE IF NOT EXISTS _reach_visited "
            "(test_def_uid TEXT, target_def_uid TEXT, depth INTEGER, "
            " PRIMARY KEY (test_def_uid, target_def_uid))"
        ))
        session.execute(sa_text(
            "CREATE TEMP TABLE IF NOT EXISTS _reach_frontier "
            "(test_def_uid TEXT, target_def_uid TEXT)"
        ))
        session.execute(sa_text("DELETE FROM _reach_visited"))
        session.execute(sa_text("DELETE FROM _reach_frontier"))

        # Seed: depth 1 — direct callees of test defs in this worktree
        session.execute(sa_text("""\
            INSERT INTO _reach_visited (test_def_uid, target_def_uid, depth)
            SELECT DISTINCT ce.caller_def_uid, ce.callee_def_uid, 1
            FROM call_edges ce
            WHERE ce.caller_def_uid IN (
                SELECT d.def_uid FROM def_facts d
                JOIN files f ON f.id = d.file_id
                WHERE f.is_test = 1 AND f.worktree_id = :wt
            )
            AND ce.callee_def_uid != ce.caller_def_uid
        """), {"wt": worktree_id})

        # Iterative BFS: expand frontier layer by layer
        for depth in range(2, _MAX_DEPTH + 1):
            # Frontier = callees of nodes reached at previous depth,
            # excluding already-visited pairs
            session.execute(sa_text("DELETE FROM _reach_frontier"))
            session.execute(sa_text(f"""\
                INSERT INTO _reach_frontier (test_def_uid, target_def_uid)
                SELECT DISTINCT v.test_def_uid, ce.callee_def_uid
                FROM _reach_visited v
                JOIN call_edges ce ON ce.caller_def_uid = v.target_def_uid
                WHERE v.depth = :prev_depth
                  AND ce.callee_def_uid != v.test_def_uid
                  AND NOT EXISTS (
                    SELECT 1 FROM _reach_visited rv
                    WHERE rv.test_def_uid = v.test_def_uid
                      AND rv.target_def_uid = ce.callee_def_uid
                  )
            """), {"prev_depth": depth - 1})

            added = session.execute(
                sa_text("SELECT COUNT(*) FROM _reach_frontier")
            ).scalar() or 0
            if added == 0:
                break

            session.execute(sa_text(f"""\
                INSERT OR IGNORE INTO _reach_visited
                    (test_def_uid, target_def_uid, depth)
                SELECT test_def_uid, target_def_uid, :depth
                FROM _reach_frontier
            """), {"depth": depth})

        # Write all visited pairs as reachability facts
        session.execute(sa_text("""\
            INSERT OR IGNORE INTO test_reachability_facts
                (test_def_uid, target_def_uid, source, depth, stale, epoch)
            SELECT test_def_uid, target_def_uid, 'static', depth, 0, :epoch
            FROM _reach_visited
        """), {"epoch": epoch})

        written = session.execute(
            sa_text(
                "SELECT COUNT(*) FROM test_reachability_facts WHERE source = 'static'"
            )
        ).scalar() or 0

        # Cleanup
        session.execute(sa_text("DROP TABLE IF EXISTS _reach_frontier"))
        session.execute(sa_text("DROP TABLE IF EXISTS _reach_visited"))
        session.commit()

    elapsed = time.time() - t0
    log.info(
        "reachability.full.complete",
        extra={
            "test_defs": test_count,
            "call_edges": edge_count,
            "reachability_facts": written,
            "elapsed_sec": round(elapsed, 1),
        },
    )
    return written


def compute_reachability_incremental(
    db: Database, file_ids: list[int], epoch: int, *, worktree_id: int
) -> int:
    """Recompute reachability for test defs affected by changed files.

    1. Re-materializes call_edges for changed files.
    2. Finds affected test def UIDs (in changed files + reaching into them).
    3. Deletes their old static edges.
    4. Runs iterative BFS seeded from affected test defs only.

    Returns the number of TestReachabilityFact rows inserted.
    """
    if not file_ids:
        return 0

    # Step 1: Update call_edges for changed files
    rematerialize_call_edges_for_files(db, file_ids, worktree_id=worktree_id)

    # Step 2: Find affected test defs
    affected_uids = _get_affected_test_uids(db, file_ids)
    if not affected_uids:
        return 0

    with db.session() as session:
        # Step 3: Delete old static edges for affected test defs
        ph = ",".join(f":u{i}" for i in range(len(affected_uids)))
        params: dict = {f"u{i}": uid for i, uid in enumerate(affected_uids)}
        session.execute(
            sa_text(
                f"DELETE FROM test_reachability_facts "
                f"WHERE test_def_uid IN ({ph}) AND source = 'static'"
            ),
            params,
        )

        # Step 4: Create temp table with affected UIDs for BFS seed
        session.execute(sa_text(
            "CREATE TEMP TABLE IF NOT EXISTS _affected_test_uids "
            "(uid TEXT PRIMARY KEY)"
        ))
        session.execute(sa_text("DELETE FROM _affected_test_uids"))
        session.execute(
            sa_text("INSERT INTO _affected_test_uids (uid) VALUES (:uid)"),
            [{"uid": uid} for uid in affected_uids],
        )

        # Step 5: Iterative BFS for affected test defs
        session.execute(sa_text(
            "CREATE TEMP TABLE IF NOT EXISTS _reach_visited "
            "(test_def_uid TEXT, target_def_uid TEXT, depth INTEGER, "
            " PRIMARY KEY (test_def_uid, target_def_uid))"
        ))
        session.execute(sa_text(
            "CREATE TEMP TABLE IF NOT EXISTS _reach_frontier "
            "(test_def_uid TEXT, target_def_uid TEXT)"
        ))
        session.execute(sa_text("DELETE FROM _reach_visited"))
        session.execute(sa_text("DELETE FROM _reach_frontier"))

        # Seed: depth 1
        session.execute(sa_text("""\
            INSERT INTO _reach_visited (test_def_uid, target_def_uid, depth)
            SELECT DISTINCT ce.caller_def_uid, ce.callee_def_uid, 1
            FROM call_edges ce
            WHERE ce.caller_def_uid IN (SELECT uid FROM _affected_test_uids)
              AND ce.callee_def_uid != ce.caller_def_uid
        """))

        # BFS layers
        for depth in range(2, _MAX_DEPTH + 1):
            session.execute(sa_text("DELETE FROM _reach_frontier"))
            session.execute(sa_text("""\
                INSERT INTO _reach_frontier (test_def_uid, target_def_uid)
                SELECT DISTINCT v.test_def_uid, ce.callee_def_uid
                FROM _reach_visited v
                JOIN call_edges ce ON ce.caller_def_uid = v.target_def_uid
                WHERE v.depth = :prev_depth
                  AND ce.callee_def_uid != v.test_def_uid
                  AND NOT EXISTS (
                    SELECT 1 FROM _reach_visited rv
                    WHERE rv.test_def_uid = v.test_def_uid
                      AND rv.target_def_uid = ce.callee_def_uid
                  )
            """), {"prev_depth": depth - 1})

            added = session.execute(
                sa_text("SELECT COUNT(*) FROM _reach_frontier")
            ).scalar() or 0
            if added == 0:
                break

            session.execute(sa_text("""\
                INSERT OR IGNORE INTO _reach_visited
                    (test_def_uid, target_def_uid, depth)
                SELECT test_def_uid, target_def_uid, :depth
                FROM _reach_frontier
            """), {"depth": depth})

        # Write all visited pairs as reachability facts
        session.execute(sa_text("""\
            INSERT OR IGNORE INTO test_reachability_facts
                (test_def_uid, target_def_uid, source, depth, stale, epoch)
            SELECT test_def_uid, target_def_uid, 'static', depth, 0, :epoch
            FROM _reach_visited
        """), {"epoch": epoch})

        # Count what was written for affected defs
        written = session.execute(
            sa_text(
                f"SELECT COUNT(*) FROM test_reachability_facts "
                f"WHERE test_def_uid IN ({ph}) AND source = 'static'"
            ),
            params,
        ).scalar() or 0

        session.execute(sa_text("DROP TABLE IF EXISTS _reach_frontier"))
        session.execute(sa_text("DROP TABLE IF EXISTS _reach_visited"))
        session.execute(sa_text("DROP TABLE IF EXISTS _affected_test_uids"))
        session.commit()

    log.debug(
        "reachability.incremental.complete",
        extra={"test_defs": len(affected_uids), "edges": written},
    )
    return written


def mark_reachability_stale(db: Database, file_ids: list[int]) -> None:
    """Mark reachability edges TO defs in changed files as stale."""
    if not file_ids:
        return
    with db.session() as session:
        ph = ",".join(f":f{i}" for i in range(len(file_ids)))
        params = {f"f{i}": fid for i, fid in enumerate(file_ids)}
        session.execute(
            sa_text(
                f"UPDATE test_reachability_facts SET stale = 1 "
                f"WHERE target_def_uid IN ("
                f"  SELECT def_uid FROM def_facts WHERE file_id IN ({ph})"
                f")"
            ),
            params,
        )
        session.commit()


def calibrate_with_coverage(db: Database, epoch: int, *, worktree_id: int) -> int:
    """Calibrate static reachability edges using runtime coverage data.

    Uses SQL JOINs to:
      1. Upgrade static→"both" where coverage confirms the edge.
      2. Insert "coverage"-only edges for dynamic dispatch paths.
      3. Demote static-only edges for test defs that have coverage data.

    Returns the number of rows modified/inserted.
    """
    with db.session() as session:
        upgraded = session.execute(
            sa_text("""\
                UPDATE test_reachability_facts
                SET source = 'both', stale = 0, epoch = :epoch
                WHERE source = 'static'
                  AND id IN (
                    SELECT trf.id
                    FROM test_reachability_facts trf
                    JOIN def_facts td ON td.def_uid = trf.test_def_uid
                    JOIN files tf ON tf.id = td.file_id
                    JOIN test_coverage_facts tcf
                      ON tcf.target_def_uid = trf.target_def_uid
                      AND tcf.stale = 0
                      AND tcf.line_rate > 0
                      AND tcf.test_id LIKE tf.path || '::%'
                    WHERE tf.worktree_id = :wt
                      AND REPLACE(
                        SUBSTR(tcf.test_id, LENGTH(tf.path) + 3),
                        '::', '.'
                      ) = td.lexical_path
                  )
            """),
            {"epoch": epoch, "wt": worktree_id},
        )
        upgraded_count = upgraded.rowcount

        count_before = session.execute(
            sa_text("SELECT COUNT(*) FROM test_reachability_facts")
        ).scalar() or 0
        session.execute(
            sa_text("""\
                INSERT OR IGNORE INTO test_reachability_facts
                  (test_def_uid, target_def_uid, source, depth, stale, epoch)
                SELECT
                  td.def_uid,
                  tcf.target_def_uid,
                  'coverage',
                  1,
                  0,
                  :epoch
                FROM test_coverage_facts tcf
                JOIN files tf ON tcf.test_id LIKE tf.path || '::%'
                JOIN def_facts td ON td.file_id = tf.id
                  AND td.kind IN ('function', 'method')
                  AND REPLACE(
                    SUBSTR(tcf.test_id, LENGTH(tf.path) + 3),
                    '::', '.'
                  ) = td.lexical_path
                WHERE tcf.stale = 0
                  AND tcf.line_rate > 0
                  AND tf.worktree_id = :wt
                  AND NOT EXISTS (
                    SELECT 1 FROM test_reachability_facts trf
                    WHERE trf.test_def_uid = td.def_uid
                      AND trf.target_def_uid = tcf.target_def_uid
                  )
            """),
            {"epoch": epoch, "wt": worktree_id},
        )
        count_after = session.execute(
            sa_text("SELECT COUNT(*) FROM test_reachability_facts")
        ).scalar() or 0
        inserted_count = count_after - count_before

        demoted = session.execute(
            sa_text("""\
                UPDATE test_reachability_facts
                SET epoch = :epoch
                WHERE source = 'static'
                  AND test_def_uid IN (
                    SELECT DISTINCT td.def_uid
                    FROM test_coverage_facts tcf
                    JOIN files tf ON tcf.test_id LIKE tf.path || '::%'
                    JOIN def_facts td ON td.file_id = tf.id
                      AND td.kind IN ('function', 'method')
                    WHERE tcf.stale = 0
                      AND tf.worktree_id = :wt
                  )
            """),
            {"epoch": epoch, "wt": worktree_id},
        )
        demoted_count = demoted.rowcount

        session.commit()

    total = upgraded_count + inserted_count + demoted_count
    log.info(
        "reachability.calibrate.complete",
        extra={
            "upgraded": upgraded_count,
            "inserted": inserted_count,
            "demoted": demoted_count,
        },
    )
    return total


# ─── Internal helpers ──────────────────────────────────────────────────────


def _get_affected_test_uids(db: Database, file_ids: list[int]) -> list[str]:
    """Get test_def_uids affected by changes in the given files.

    Affected = test defs IN those files + test defs with existing edges TO defs
    in those files.
    """
    with db.session() as session:
        ph = ",".join(f":f{i}" for i in range(len(file_ids)))
        params: dict = {f"f{i}": fid for i, fid in enumerate(file_ids)}

        # Test defs directly in changed files
        direct = session.execute(
            sa_text(
                f"SELECT d.def_uid FROM def_facts d "
                f"JOIN files f ON f.id = d.file_id "
                f"WHERE f.is_test = 1 "
                f"AND d.file_id IN ({ph})"
            ),
            params,
        ).fetchall()
        direct_uids = {row[0] for row in direct}

        # Test defs that reach defs in changed files
        reaching = session.execute(
            sa_text(
                f"SELECT DISTINCT trf.test_def_uid "
                f"FROM test_reachability_facts trf "
                f"WHERE trf.target_def_uid IN ("
                f"  SELECT def_uid FROM def_facts WHERE file_id IN ({ph})"
                f")"
            ),
            params,
        ).fetchall()
        reaching_uids = {row[0] for row in reaching}

    return list(direct_uids | reaching_uids)
