"""CodeRecon Review SDK — lightweight structural analysis without heavy ML/search.

Usage::

    from coderecon.review import ReviewKit

    kit = ReviewKit("/path/to/repo")
    kit.ensure_indexed(worktree="main")

    diff = kit.semantic_diff(base="HEAD", worktree="main")
    cycles = kit.graph_cycles(worktree="main")
    communities = kit.graph_communities(worktree="main")
    health = kit.check_structural_health(worktree="main")
    orientation = kit.understand(worktree="main")
    refs = kit.impact("MyClass", worktree="main")

For checkpoint (diff + lint + affected tests)::

    result = kit.checkpoint(["src/foo.py", "src/bar.py"], worktree="main")
    print(result.passed, result.summary)

For SCIP enrichment (requires Docker or native toolchains)::

    result = kit.enrich_scip(worktree="main")
    print(result.total_refs_matched)

For multi-worktree workflows::

    kit = ReviewKit("/path/to/repo")
    kit.register_worktree("feature-x", "/path/to/worktree")
    kit.ensure_indexed(worktree="feature-x")

    diff = kit.semantic_diff(base="main", worktree="feature-x")
    cycles = kit.graph_cycles(worktree="feature-x")
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from coderecon.review.diff import structural_diff
from coderecon.review.graph import (
    CommunitiesResult,
    CyclesResult,
    StructuralHealthResult,
    check_structural_health,
    graph_communities,
    graph_cycles,
)
from coderecon.review.impact import ImpactReference, ImpactResult, impact
from coderecon.review.checkpoint import CheckpointResult, DiffPhaseResult
from coderecon.review.indexer import (
    index_structural,
    init_review_db,
    reindex_structural,
)
from coderecon.review.understand import UnderstandResult, understand

if TYPE_CHECKING:
    from collections.abc import Callable

    from coderecon.index.analysis.code_graph import CycleCluster
    from coderecon.index.diff.models import SemanticDiffResult
    from coderecon.index.scip.runner import ScipImportResult

__all__ = [
    "ReviewKit",
    "CheckpointResult",
    "CommunitiesResult",
    "CyclesResult",
    "DiffPhaseResult",
    "ImpactReference",
    "ImpactResult",
    "StructuralHealthResult",
    "UnderstandResult",
]


class ReviewKit:
    """Lightweight in-process review SDK.

    Provides structural diff, cycle detection, and community analysis
    without SPLADE, Tantivy, or the daemon process.  Optional SCIP
    enrichment is available via ``enrich_scip()`` when Docker or native
    language toolchains are present.

    One instance per repository. Supports multiple worktrees via
    register_worktree() and worktree= parameters.
    """

    def __init__(
        self,
        repo_root: str | Path,
        *,
        db_path: str | Path | None = None,
    ) -> None:
        """Initialize ReviewKit.

        Args:
            repo_root: Path to the git repository root.
            db_path: Path to the SQLite database. Defaults to
                ``<repo_root>/.recon/review.db``.
        """
        self._repo_root = Path(repo_root).resolve()
        if db_path is None:
            from coderecon._core.recon_dir import ensure_recon_dir
            db_dir = ensure_recon_dir(self._repo_root)
            self._db_path = db_dir / "review.db"
        else:
            self._db_path = Path(db_path)

        self._db = None
        self._structural = None
        self._git_ops_cache: dict[str, object] = {}
        self._worktrees: dict[str, Path] = {"main": self._repo_root}
        self._indexed_worktrees: set[str] = set()
        self._worktree_id_cache: dict[str, int] = {}

    @property
    def repo_root(self) -> Path:
        return self._repo_root

    def _resolve_worktree_id(self, worktree: str) -> int:
        """Look up the worktree DB id by name. Raises if not found."""
        if worktree in self._worktree_id_cache:
            return self._worktree_id_cache[worktree]
        self._ensure_initialized()
        from sqlmodel import Session, select
        from coderecon.index.models import Worktree
        with Session(self._db.engine) as session:
            row = session.exec(
                select(Worktree).where(Worktree.name == worktree)
            ).first()
            if row is None or row.id is None:
                msg = f"Worktree {worktree!r} not found in index. Call ensure_indexed() first."
                raise ValueError(msg)
            self._worktree_id_cache[worktree] = row.id
            return row.id

    def _ensure_initialized(self) -> None:
        """Lazily initialize DB and structural indexer."""
        if self._db is not None:
            return
        self._db, self._structural = init_review_db(self._repo_root, self._db_path)

    def _get_git_ops(self, worktree: str):
        """Get or create GitOps for a worktree."""
        from coderecon.adapters.git.ops import GitOps

        if worktree not in self._git_ops_cache:
            root = self._worktrees.get(worktree, self._repo_root)
            self._git_ops_cache[worktree] = GitOps(root)
        return self._git_ops_cache[worktree]

    def register_worktree(self, name: str, path: str | Path) -> None:
        """Register a git worktree for multi-worktree analysis.

        Args:
            name: Logical name for this worktree (e.g. branch name).
            path: Filesystem path to the worktree checkout.
        """
        wt_path = Path(path).resolve()
        if not wt_path.exists():
            msg = f"Worktree path does not exist: {wt_path}"
            raise FileNotFoundError(msg)
        self._worktrees[name] = wt_path
        # Invalidate git ops cache for this worktree
        self._git_ops_cache.pop(name, None)

    def ensure_indexed(
        self,
        *,
        worktree: str,
        on_progress: Callable[[int, int], None] | None = None,
    ) -> int:
        """Ensure the repository is structurally indexed.

        Runs tree-sitter extraction + import resolution on first call.
        Subsequent calls for the same worktree are no-ops unless
        reindex() is called explicitly.

        Args:
            worktree: Which worktree to index.
            on_progress: Optional callback(indexed, total).

        Returns:
            Number of files indexed (0 if already indexed).
        """
        self._ensure_initialized()
        if worktree in self._indexed_worktrees:
            return 0

        wt_root = self._worktrees.get(worktree, self._repo_root)
        count = index_structural(
            self._db,
            self._structural,
            self._repo_root,
            worktree_name=worktree,
            worktree_root=wt_root if worktree != "main" else None,
            on_progress=on_progress,
        )
        self._indexed_worktrees.add(worktree)
        return count

    def reindex(
        self,
        changed_paths: list[str | Path],
        *,
        worktree: str,
    ) -> int:
        """Incrementally reindex changed files.

        Args:
            changed_paths: Files that have changed since last index.
            worktree: Which worktree these changes belong to.

        Returns:
            Number of files reindexed.
        """
        self._ensure_initialized()
        wt_root = self._worktrees.get(worktree, self._repo_root)
        paths = [Path(p) for p in changed_paths]
        return reindex_structural(
            self._db,
            self._structural,
            self._repo_root,
            paths,
            worktree_name=worktree,
            worktree_root=wt_root if worktree != "main" else None,
        )

    def semantic_diff(
        self,
        *,
        base: str = "HEAD",
        target: str | None = None,
        paths: list[str] | None = None,
        worktree: str,
    ) -> SemanticDiffResult:
        """Compute structural diff between two git states.

        Args:
            base: Base ref (commit, branch, tag).
            target: Target ref (None = working tree).
            paths: Limit to specific paths.
            worktree: Which worktree to run the diff against.

        Returns:
            SemanticDiffResult with classified structural changes.
        """
        self._ensure_initialized()
        git_ops = self._get_git_ops(worktree)
        wt_root = self._worktrees.get(worktree, self._repo_root)
        wt_id = self._resolve_worktree_id(worktree)
        return structural_diff(
            self._db,
            git_ops,
            wt_root,
            worktree_id=wt_id,
            base=base,
            target=target,
            paths=paths,
        )

    def graph_cycles(
        self,
        *,
        level: str = "file",
        worktree: str,
    ) -> CyclesResult:
        """Detect dependency cycles.

        Args:
            level: "file" (import graph) or "def" (reference graph).
            worktree: Which worktree's index to analyze.

        Returns:
            CyclesResult with all strongly connected components.
        """
        self._ensure_initialized()
        wt_id = self._resolve_worktree_id(worktree)
        return graph_cycles(self._db.engine, worktree_id=wt_id, level=level)

    def graph_communities(
        self,
        *,
        level: str = "file",
        resolution: float = 1.0,
        worktree: str,
    ) -> CommunitiesResult:
        """Detect module communities via Louvain.

        Args:
            level: "file" or "def".
            resolution: Higher values produce more communities.
            worktree: Which worktree's index to analyze.

        Returns:
            CommunitiesResult with community assignments.
        """
        self._ensure_initialized()
        wt_id = self._resolve_worktree_id(worktree)
        return graph_communities(self._db.engine, worktree_id=wt_id, level=level, resolution=resolution)

    def check_structural_health(
        self,
        *,
        baseline_cycles: list[CycleCluster] | None = None,
        worktree: str,
    ) -> StructuralHealthResult:
        """Check structural health (new cycles, community overview).

        Args:
            baseline_cycles: Baseline to compare against. If provided,
                only newly-introduced cycles are flagged.
            worktree: Which worktree to check.

        Returns:
            StructuralHealthResult with health status.
        """
        self._ensure_initialized()
        wt_id = self._resolve_worktree_id(worktree)
        return check_structural_health(self._db.engine, worktree_id=wt_id, baseline_cycles=baseline_cycles)

    def understand(
        self,
        *,
        scope: str | None = None,
        worktree: str,
    ) -> UnderstandResult:
        """Get full codebase orientation (top files, symbols, cycles, etc.).

        Equivalent to the ``recon_understand`` MCP tool.

        Args:
            scope: Optional path prefix to zoom into a subtree.
            worktree: Which worktree's index to analyze.

        Returns:
            UnderstandResult with orientation data.
        """
        self._ensure_initialized()
        wt_id = self._resolve_worktree_id(worktree)
        return understand(self._db.engine, worktree_id=wt_id, scope=scope)

    def impact(
        self,
        target: str,
        *,
        worktree: str,
    ) -> ImpactResult:
        """Find all structural references to a symbol or file.

        Equivalent to the ``recon_impact`` MCP tool (structural-only,
        no tantivy lexical fallback).

        Args:
            target: Symbol name (e.g. 'MyClass') or file path
                (e.g. 'src/foo/bar.py').
            worktree: Which worktree's index to analyze.

        Returns:
            ImpactResult with categorized reference sites.
        """
        self._ensure_initialized()
        wt_id = self._resolve_worktree_id(worktree)
        return impact(self._db.engine, target, worktree_id=wt_id, repo_root=self._repo_root)

    def enrich_scip(
        self,
        *,
        worktree: str,
    ) -> ScipImportResult:
        """Run SCIP indexers and import compiler-grade cross-references.

        Detects applicable SCIP tools for the repo, auto-provisions them
        (falling back to Docker when native runtimes are absent), and
        imports the resulting ref_facts into the database.

        Best-effort: individual tool failures are logged and skipped.
        Call after ``ensure_indexed()`` so the structural layer is
        already populated.

        Args:
            worktree: Which worktree to enrich.

        Returns:
            ScipImportResult with per-tool success/failure details.
        """
        import asyncio

        from coderecon.index.scip.runner import ensure_scip_current

        self._ensure_initialized()
        wt_id = self._resolve_worktree_id(worktree)
        wt_root = self._worktrees.get(worktree, self._repo_root)
        return asyncio.run(ensure_scip_current(self._db, wt_root, worktree_id=wt_id))

    def checkpoint(
        self,
        changed_files: list[str],
        *,
        diff: bool = True,
        lint: bool = True,
        autofix: bool = True,
        tests: bool = True,
        test_filter: str | None = None,
        max_test_hops: int = 0,
        worktree: str,
    ) -> CheckpointResult:
        """Run diff, lint, and affected tests for changed files.

        Chains semantic-diff → lint → import-graph test discovery → tiered
        test execution.  No commit or push — purely verification.

        The diff result (``result.diff.raw``) is the full
        ``SemanticDiffResult`` dataclass.  Callers that need agent-friendly
        text can pass it through ``_result_to_text`` from
        ``coderecon.mcp.tools.diff_formatting`` — the same formatter the
        MCP layer already uses.

        Args:
            changed_files: Paths (relative to repo root) that changed.
            diff: Include semantic diff phase.
            lint: Run linting.
            autofix: Apply lint auto-fixes (only if lint=True).
            tests: Run affected tests.
            test_filter: Filter test names (passed to pytest -k / jest --testNamePattern).
            max_test_hops: Max import-graph hop depth. 0 = direct tests only.
            worktree: Which worktree to check against.

        Returns:
            CheckpointResult with diff, lint, and test phase outcomes.
        """
        from coderecon.review.checkpoint import run_checkpoint

        self._ensure_initialized()
        wt_id = self._resolve_worktree_id(worktree)
        git_ops = self._get_git_ops(worktree) if diff else None
        return run_checkpoint(
            self._db,
            self._worktrees.get(worktree, self._repo_root),
            wt_id,
            changed_files,
            diff=diff,
            git_ops=git_ops,
            lint=lint,
            autofix=autofix,
            tests=tests,
            test_filter=test_filter,
            max_test_hops=max_test_hops,
        )

    def close(self) -> None:
        """Release database resources."""
        if self._db is not None:
            self._db.engine.dispose()
            self._db = None
        self._structural = None
        self._git_ops_cache.clear()
        self._indexed_worktrees.clear()

    def __enter__(self) -> ReviewKit:
        return self

    def __exit__(self, *_exc) -> None:
        self.close()
