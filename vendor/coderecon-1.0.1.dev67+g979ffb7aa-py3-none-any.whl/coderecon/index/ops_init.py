"""Initialization operations for the index coordinator.

Standalone functions extracted from IndexCoordinatorEngine. Each takes
``engine`` as its first parameter.
"""

from __future__ import annotations

import json
import time
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING

import structlog

from coderecon.index.db import (
    EpochManager,
    Reconciler,
    create_additional_indexes,
)
from coderecon.index.discovery import (
    ContextDiscovery,
    ContextProbe,
    ContextRouter,
    MembershipResolver,
    Tier1AuthorityFilter,
)
from coderecon.index.search.lexical import LexicalIndex
from coderecon.index.structural.structural import StructuralIndexer
from coderecon.index.parsing.service import tree_sitter_service
from coderecon.index._state import FileStateService
from coderecon.index.models import (
    CandidateContext,
    Context,
    ContextMarker,
    ProbeStatus,
)
from coderecon.index.ops_types import InitResult

if TYPE_CHECKING:
    from coderecon.index.ops import IndexCoordinatorEngine

log = structlog.get_logger(__name__)


async def initialize(
    engine: IndexCoordinatorEngine,
    on_index_progress: Callable[[int, int, dict[str, int], str], None],
) -> InitResult:
    """Full initialization: discover, probe, index."""
    errors: list[str] = []
    # Step 1-2: Database setup
    engine.db.create_all()
    create_additional_indexes(engine.db.engine)
    engine._get_or_create_worktree_id("main")
    # Initialize components
    engine._parser = tree_sitter_service.parser
    engine._lexical = LexicalIndex(engine.tantivy_path)
    engine._epoch_manager = EpochManager(engine.db, engine._lexical)
    # Step 3: Discover contexts
    discovery = ContextDiscovery(engine.repo_root)
    discovery_result = discovery.discover_all()
    all_candidates = discovery_result.candidates
    root_fallback = next(
        (c for c in all_candidates if getattr(c, "is_root_fallback", False)),
        None,
    )
    regular_candidates = [
        c for c in all_candidates if not getattr(c, "is_root_fallback", False)
    ]
    # Step 4: Apply authority filter
    authority = Tier1AuthorityFilter(engine.repo_root)
    authority_result = authority.apply(regular_candidates)
    pending_candidates = authority_result.pending
    detached_candidates = authority_result.detached
    # Step 5: Resolve membership
    membership = MembershipResolver()
    membership_result = membership.resolve(pending_candidates)
    resolved_candidates = membership_result.contexts
    # Step 6: Probe contexts
    probe = ContextProbe(engine.repo_root, parser=engine._parser)
    probed_candidates: list[CandidateContext] = []
    for candidate in resolved_candidates:
        probe_result = probe.validate(candidate)
        if probe_result.valid:
            candidate.probe_status = ProbeStatus.VALID
        elif probe_result.reason and "empty" in probe_result.reason.lower():
            candidate.probe_status = ProbeStatus.EMPTY
        else:
            candidate.probe_status = ProbeStatus.FAILED
        probed_candidates.append(candidate)
    if root_fallback is not None:
        probed_candidates.append(root_fallback)
    # Step 7: Persist contexts
    contexts_valid = 0
    contexts_failed = 0
    with engine.db.session() as session:
        for candidate in probed_candidates:
            if getattr(candidate, "is_root_fallback", False):
                name = "_root"
            else:
                name = candidate.root_path or "root"
            context = Context(
                name=name,
                language_family=candidate.language_family.value,
                root_path=candidate.root_path,
                tier=candidate.tier,
                probe_status=candidate.probe_status.value,
                include_spec=json.dumps(candidate.include_spec)
                if candidate.include_spec
                else None,
                exclude_spec=json.dumps(candidate.exclude_spec)
                if candidate.exclude_spec
                else None,
            )
            session.add(context)
            session.flush()
            for marker_path in candidate.markers:
                marker = ContextMarker(
                    context_id=context.id,
                    marker_path=marker_path,
                    marker_tier="tier1" if candidate.tier == 1 else "tier2",
                    detected_at=time.time(),
                )
                session.add(marker)
            if candidate.probe_status == ProbeStatus.VALID:
                contexts_valid += 1
            elif candidate.probe_status == ProbeStatus.FAILED:
                contexts_failed += 1
        for candidate in detached_candidates:
            context = Context(
                name=candidate.root_path or "root",
                language_family=candidate.language_family.value,
                root_path=candidate.root_path,
                tier=candidate.tier,
                probe_status=ProbeStatus.DETACHED.value,
            )
            session.add(context)
        session.commit()
    # Step 7.4-7.7: Runtimes, test targets, lint tools, coverage
    await engine._resolve_context_runtimes()
    await engine._discover_test_targets()
    await engine._discover_lint_tools()
    await engine._discover_coverage_capabilities()
    # Step 8: Initialize router and remaining components
    engine._router = ContextRouter()
    engine._structural = StructuralIndexer(engine.db, engine.repo_root)
    engine._state = FileStateService(engine.db)
    engine._reconciler = Reconciler(engine.db, engine.repo_root)
    engine._reconciler.reconcile(
        paths=[],
        worktree_id=engine._get_or_create_worktree_id("main"),
    )
    engine._facts = None
    # Step 9: Index all files (main worktree)
    files_indexed, indexed_paths, files_by_ext = await engine._index_all_files(
        on_progress=on_index_progress
    )
    if engine._lexical is not None:
        engine._lexical.reload()

    # Step 9b: Discover and index linked git worktrees
    # Set _initialized early — all components are ready, reindex_incremental checks it.
    engine._initialized = True
    files_indexed = await _index_linked_worktrees(
        engine, files_indexed, indexed_paths, files_by_ext, on_index_progress
    )

    # Step 10: Publish initial epoch
    if engine._epoch_manager is not None:
        engine._epoch_manager.publish_epoch(
            files_indexed=files_indexed,
            indexed_paths=indexed_paths,
        )

    # Step 11: Ingest existing coverage artifacts (best-effort)
    await _ingest_existing_coverage(engine)

    return InitResult(
        contexts_discovered=len(all_candidates),
        contexts_valid=contexts_valid,
        contexts_failed=contexts_failed,
        contexts_detached=len(detached_candidates),
        files_indexed=files_indexed,
        errors=errors,
        files_by_ext=files_by_ext,
    )


async def _ingest_existing_coverage(engine: IndexCoordinatorEngine) -> None:
    """Ingest pre-existing coverage artifacts from the repo root. Best-effort."""
    try:
        repo_root = engine.repo_root
        coverage_db = repo_root / ".coverage"
        if not coverage_db.exists():
            return

        # Verify it's a valid coverage.py SQLite DB with contexts
        import sqlite3

        conn = sqlite3.connect(str(coverage_db))
        try:
            tables = {
                r[0]
                for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
            }
            if "context" not in tables or "arc" not in tables:
                log.debug("init.existing_coverage_no_contexts", path=str(coverage_db))
                return
            context_count = conn.execute("SELECT COUNT(*) FROM context WHERE context != ''").fetchone()[0]
            if context_count < 2:
                log.debug("init.existing_coverage_no_per_test", contexts=context_count)
                return
        finally:
            conn.close()

        from coderecon.testing.coverage.parsers.coveragepy_context import (
            parse_coveragepy_context,
        )
        from coderecon.index.analysis.coverage_ingestion import ingest_coverage_per_test

        per_test_reports = parse_coveragepy_context(coverage_db, base_path=repo_root)
        if not per_test_reports:
            return

        epoch = engine.current_epoch
        written = ingest_coverage_per_test(engine.db.engine, per_test_reports, epoch)
        log.info("init.existing_coverage_ingested", facts=written)
    except Exception:
        log.debug("init.existing_coverage_failed", exc_info=True)


async def _index_linked_worktrees(
    engine: IndexCoordinatorEngine,
    files_indexed: int,
    indexed_paths: list[str],
    files_by_ext: dict[str, int],
    on_progress: Callable[[int, int, dict[str, int], str], None],
) -> int:
    """Discover linked git worktrees and index files that differ from main.

    For each non-main worktree found via ``git worktree list``:
    1. Register worktree_id in the database.
    2. Compute files that differ from the default branch.
    3. Reconcile and index only those changed files (leveraging content-hash
       dedup from the main worktree index).

    Returns updated total files_indexed count.
    """
    from coderecon.adapters.git.ops import GitOps
    from coderecon.adapters.git.errors import GitError

    try:
        git_ops = GitOps(engine.repo_root)
        worktrees = git_ops.worktrees()
    except (GitError, OSError):
        log.debug("init.worktree_discovery_failed", exc_info=True)
        return files_indexed

    linked = [wt for wt in worktrees if not wt.is_main]
    if not linked:
        return files_indexed

    try:
        base_branch = git_ops.default_branch()
    except (GitError, OSError):
        base_branch = "main"

    log.info("init.indexing_linked_worktrees", count=len(linked))

    for wt in linked:
        wt_path = Path(wt.path)
        if not wt_path.exists():
            log.debug("init.worktree_path_missing", worktree=wt.name, path=str(wt_path))
            continue

        # Use branch ref as the canonical worktree identifier (matches daemon activation)
        wt_key = wt.head_ref if wt.head_ref and wt.head_ref != "HEAD" else wt.name

        # Register worktree in DB
        wt_id = engine._get_or_create_worktree_id(wt_key, root_path=str(wt_path))
        engine._worktree_root_cache[wt_key] = wt_path

        # Find files that differ from default branch
        try:
            wt_git = GitOps(wt_path)
            diff_paths = wt_git.files_changed_from(base_branch)
        except GitError:
            log.debug("init.worktree_diff_failed", worktree=wt_key, exc_info=True)
            continue

        if not diff_paths:
            log.debug("init.worktree_no_changes", worktree=wt_key)
            continue

        # Reconcile changed files for this worktree
        abs_paths = [wt_path / p for p in diff_paths]
        existing_abs = [p for p in abs_paths if p.exists()]
        if not existing_abs:
            continue

        if engine._reconciler is not None:
            engine._reconciler.reconcile(
                existing_abs,
                worktree_id=wt_id,
                worktree_root=wt_path,
            )

        # Reindex the changed files
        try:
            stats = await engine.reindex_incremental(existing_abs, worktree=wt_key)
            files_indexed += stats.files_updated + stats.files_added
            log.info(
                "init.worktree_indexed",
                worktree=wt_key,
                diff_files=len(diff_paths),
                indexed=stats.files_updated + stats.files_added,
            )
        except Exception:
            log.warning("init.worktree_index_failed", worktree=wt_key, exc_info=True)

    if engine._lexical is not None:
        engine._lexical.reload()

    return files_indexed


async def collect_initial_coverage(
    engine: IndexCoordinatorEngine,
    *,
    parallelism: int | None = None,
    memory_reserve_mb: int = 1024,
    subprocess_memory_limit_mb: int | None = None,
    timeout_sec: int = 600,
) -> int:
    """Run the full test suite with coverage and ingest results.
    Best-effort: returns 0 and logs on failure.  Never raises.
    """
    try:
        from coderecon.testing.ops import TestOps
        test_ops = TestOps(
            engine.repo_root,
            engine,
            memory_reserve_mb=memory_reserve_mb,
            subprocess_memory_limit_mb=subprocess_memory_limit_mb,
            timeout_sec=timeout_sec,
        )
        result = await test_ops.run(
            targets=None,
            coverage=True,
            fail_fast=False,
            parallelism=parallelism,
        )
        if not result.run_status or not result.run_status.coverage:
            log.debug("initial_coverage.no_artifacts")
            return 0
        from coderecon.testing.coverage import (
            CoverageParseError,
            merge,
            parse_artifact,
        )
        reports = []
        for cov in result.run_status.coverage:
            cov_path = cov.get("path", "")
            if not cov_path:
                continue
            try:
                fmt = cov.get("format")
                report = parse_artifact(
                    Path(cov_path),
                    format_id=fmt if fmt and fmt != "unknown" else None,
                    base_path=engine.repo_root,
                )
                reports.append(report)
            except (CoverageParseError, ValueError, KeyError, OSError):
                log.debug("initial_coverage.parse_failed", extra={"path": cov_path}, exc_info=True)
        if not reports:
            log.debug("initial_coverage.no_reports")
            return 0
        from coderecon.index.analysis.coverage_ingestion import (
            ingest_coverage,
        )
        merged = merge(*reports) if len(reports) > 1 else reports[0]
        failed_ids: set[str] | None = None
        if result.run_status and result.run_status.failures:
            failed_ids = {
                f"{f.path}::{f.name}"
                for f in result.run_status.failures
            }
        written = ingest_coverage(
            engine.db.engine, merged, engine.current_epoch,
            failed_test_ids=failed_ids,
        )
        log.info("initial_coverage.ingested", extra={"facts": written})
        return written
    except (OSError, ValueError, RuntimeError):
        log.debug("initial_coverage.failed", exc_info=True)
        return 0
